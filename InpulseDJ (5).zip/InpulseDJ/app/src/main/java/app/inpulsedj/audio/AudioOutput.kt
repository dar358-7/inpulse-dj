package app.inpulsedj.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import kotlin.math.max

/** Hilo de audio: pide bloques al DjEngine y los escribe en un AudioTrack float de baja latencia. */
class AudioOutput(private val ctx: android.content.Context, private val engine: DjEngine, private val block: Int) {
    /** Descripcion de la salida activa, para mostrarla en Ajustes. */
    @Volatile var description = "Salida estereo"

    private fun findMultiChannelUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            val usb = d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE ||
                d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
            if (usb && d.channelCounts.any { it >= 4 }) return d
        }
        return null
    }

    private fun buildTrack(sr: Int, quad: Boolean, dev: android.media.AudioDeviceInfo?): AudioTrack {
        val mask = if (quad) AudioFormat.CHANNEL_OUT_QUAD else AudioFormat.CHANNEL_OUT_STEREO
        val ch = if (quad) 4 else 2
        val minBuf = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_FLOAT)
        val bufBytes = max(minBuf, block * ch * 4 * 3)
        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .setChannelMask(mask)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
        if (Build.VERSION.SDK_INT >= 26) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }
        val t = builder.build()
        if (quad && dev != null && Build.VERSION.SDK_INT >= 23) t.setPreferredDevice(dev)
        return t
    }

    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        val t = Thread({ loop() }, "dj-audio")
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        thread?.join(800)
        thread = null
    }

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sr = engine.sampleRate
        var quad = false
        var track: AudioTrack? = null
        val dev = findMultiChannelUsb()
        if (dev != null) {
            try {
                val t = buildTrack(sr, true, dev)
                t.play()
                track = t
                quad = true
                description = "USB 4 canales: master 1-2, auriculares 3-4"
            } catch (_: Exception) {
                track = null
            }
        }
        if (track == null) {
            track = buildTrack(sr, false, null)
            track.play()
            description = "Salida estereo"
        }
        val tk: AudioTrack = track!!
        val buf = FloatArray(block * (if (quad) 4 else 2))
        while (running) {
            if (quad) engine.renderBlock4(buf, block) else engine.renderBlock(buf, block)
            val w = tk.write(buf, 0, buf.size, AudioTrack.WRITE_BLOCKING)
            if (w < 0) break
        }
        try {
            tk.stop()
        } catch (_: IllegalStateException) {
        }
        tk.release()
    }
}
