package app.inpulsedj.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DeckUi
import app.inpulsedj.DjUi
import app.inpulsedj.DjViewModel

@Composable
fun MixerPanel(s: DjUi, vm: DjViewModel, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(10.dp)).background(Pal.panel).padding(5.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Channel(s.a, 0, vm, Pal.deckA)
            Channel(s.b, 1, vm, Pal.deckB)
        }
        PressButton(
            if (s.cueQuad) "AUDIF: CONTROLADOR" else if (s.cueSplit) "AUDIF: DIVIDIDO" else "AUDIF: NORMAL",
            Modifier.fillMaxWidth().height(24.dp), active = s.cueQuad || s.cueSplit, color = Pal.warn,
            onPress = { if (!s.cueQuad) vm.toggleCueSplit() }
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text("CROSSFADER", color = Pal.dim, fontSize = 8.sp, modifier = Modifier.padding(end = 6.dp))
            PressButton(
                "FX: " + app.inpulsedj.audio.XfKinds.names[(if (s.xfFxOn) s.xfFxKind else 0).coerceIn(0, 4)],
                Modifier.width(96.dp).height(18.dp), active = s.xfFxOn, color = Pal.deckB,
                onPress = { vm.xfxVisible.value = true }
            )
        }
        Fader(
            value = s.crossfader, onChange = { vm.knob("crossfader", -1, it) },
            modifier = Modifier.fillMaxWidth().height(46.dp), vertical = false,
            color = Pal.text, centerMark = true
        )
    }
}

@Composable
private fun Channel(d: DeckUi, deck: Int, vm: DjViewModel, color: Color) {
    Row(Modifier.fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
            Knob(d.gain, { vm.knob("gain", deck, it) }, "GAIN", color, size = 28.dp)
            Knob(d.eqHigh, { vm.knob("eqHigh", deck, it) }, "HI", color, size = 28.dp, center = true)
            Knob(d.eqMid, { vm.knob("eqMid", deck, it) }, "MID", color, size = 28.dp, center = true)
            Knob(d.eqLow, { vm.knob("eqLow", deck, it) }, "LOW", color, size = 28.dp, center = true)
            Knob(d.filter, { vm.knob("filter", deck, it) }, "FILTER", color, size = 28.dp, center = true)
        }
        VuMeter(d.level, Modifier.width(10.dp).fillMaxHeight())
        Fader(
            value = d.volume, onChange = { vm.knob("volume", deck, it) },
            modifier = Modifier.width(44.dp).fillMaxHeight(), vertical = true, color = color
        )
    }
}
