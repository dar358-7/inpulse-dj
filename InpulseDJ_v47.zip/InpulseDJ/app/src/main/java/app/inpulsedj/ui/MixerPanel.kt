package app.inpulsedj.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DeckUi
import app.inpulsedj.DjUi
import app.inpulsedj.DjViewModel

@Composable
fun MixerPanel(s: DjUi, vm: DjViewModel, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp))
        .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Pal.panel2, Pal.panel, Pal.bg)))
        .border(1.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.03f))), RoundedCornerShape(14.dp)).padding(5.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("MIXER", color = Pal.dim, fontSize = 15.sp, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            PressButton("AUTO-MIX", Modifier.width(64.dp).fillMaxHeight(), active = s.autoMix, outline = !s.autoMix, color = Pal.deckB,
                onPress = { vm.toggleAutoMix() })
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Channel(s.a, 0, vm, Pal.deckA)
            Channel(s.b, 1, vm, Pal.deckB)
        }
        Row(Modifier.fillMaxWidth().height(28.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton("\u223F", Modifier.width(34.dp).fillMaxHeight(), onPress = { vm.xfxVisible.value = true })
            PressButton(
                if (s.cueQuad) "AUDIF: CONTROLADOR" else if (s.cueSplit) "AUDIF: DIVIDIDO" else "AUDIF: NORMAL",
                Modifier.weight(1f).fillMaxHeight(), active = s.cueQuad || s.cueSplit, color = Pal.warn,
                onPress = { if (!s.cueQuad) vm.toggleCueSplit() }
            )
            PressButton("\u2699", Modifier.width(30.dp).fillMaxHeight(), onPress = { vm.xfxVisible.value = true })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("FADES\nCURVE", color = Pal.dim, fontSize = 8.sp, lineHeight = 9.sp)
            PressButton(
                "FX: " + app.inpulsedj.audio.XfKinds.names[(if (s.xfFxOn) s.xfFxKind else 0).coerceIn(0, 4)],
                Modifier.weight(1f).height(24.dp), active = s.xfFxOn, color = Pal.deckB,
                onPress = { vm.xfxVisible.value = true }
            )
        }
        Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("\u25C0", color = Pal.dim, fontSize = 11.sp)
            Fader(
                value = s.crossfader, onChange = { vm.knob("crossfader", -1, it) },
                modifier = Modifier.weight(1f).fillMaxHeight(), vertical = false,
                color = Pal.text, centerMark = true
            )
            Text("\u25B6", color = Pal.dim, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Channel(d: DeckUi, deck: Int, vm: DjViewModel, color: Color) {
    Row(Modifier.fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
            Knob(d.gain, { vm.knob("gain", deck, it) }, "GAIN", color, size = 28.dp)
            Knob(d.eqHigh, { vm.knob("eqHigh", deck, it) }, "HI", color, size = 28.dp, center = true)
            Knob(d.eqMid, { vm.knob("eqMid", deck, it) }, "MID", color, size = 28.dp, center = true)
            Knob(d.eqLow, { vm.knob("eqLow", deck, it) }, "LOW", color, size = 28.dp, center = true)
            Knob(d.filter, { vm.knob("filter", deck, it) }, "FILTER", color, size = 28.dp, center = true)
        }
        VuMeter(d.level, Modifier.width(10.dp).fillMaxHeight())
        Fader(
            value = d.volume, onChange = { vm.knob("volume", deck, it) },
            modifier = Modifier.width(44.dp).fillMaxHeight(), vertical = true, color = color
        )
    }
}
