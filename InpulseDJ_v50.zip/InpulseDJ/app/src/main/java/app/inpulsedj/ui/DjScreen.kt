package app.inpulsedj.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.inpulsedj.DjViewModel
import kotlinx.coroutines.delay

@Composable
fun DjScreen(vm: DjViewModel) {
    MaterialTheme(colorScheme = if (Pal.day) androidx.compose.material3.lightColorScheme() else darkColorScheme()) {
        val ctx = LocalContext.current
        val ui by vm.ui.collectAsState()
        val libVisible by vm.libraryVisible.collectAsState()
        val xfxVisible by vm.xfxVisible.collectAsState()
        val simple by vm.simpleMode.collectAsState()
        val vertical by vm.verticalView.collectAsState()
        val zoom by vm.waveZoom.collectAsState()
        val win = doubleArrayOf(3.0, 6.0, 12.0)[zoom]
        val midiStatus by vm.usb.status.collectAsState()
        val connected by vm.usb.connectedName.collectAsState()
        val msg by vm.message.collectAsState()
        var showSettings by remember { mutableStateOf(false) }
        var showAudioInfo by remember { mutableStateOf(false) }
        var shownMsg by remember { mutableStateOf("") }
        var splash by rememberSaveable { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(2400); splash = false }

        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            vm.refreshLibrary()
        }
        val pickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.addFiles(uris)
        }
        val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) vm.addFolder(uri)
        }
        val rescan = {
            if (ContextCompat.checkSelfPermission(ctx, perm) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                vm.refreshLibrary()
            } else {
                permLauncher.launch(perm)
            }
        }
        LaunchedEffect(Unit) { rescan() }
        LaunchedEffect(msg) {
            if (msg.isNotEmpty()) {
                shownMsg = msg
                delay(4000)
                shownMsg = ""
            }
        }

        Box(Modifier.fillMaxSize().background(Pal.bg)) {
            if (vertical) {
                VerticalView(
                    ui, vm, shownMsg,
                    onLibrary = { vm.libraryVisible.value = !libVisible },
                    onSettings = { showSettings = true },
                    onClose = { vm.setVerticalView(false) },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
            Column(Modifier.fillMaxSize().padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // ---- barra superior
                Row(
                    Modifier.fillMaxWidth().height(32.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LogoMark(26.dp)
                    Column(Modifier.clickable { showAudioInfo = !showAudioInfo }.padding(end = 4.dp)) {
                        Text3D("INPULSE DJ BY DARVI'S", 12.sp, Modifier, depth = 4)
                    }
                    ConnChip("USB", ui.audioInfo.contains("USB:") && !ui.audioInfo.contains("USB: NO DETECTADO"))
                    ConnChip("BT", ui.audioInfo.contains("Bluetooth:") && !ui.audioInfo.contains("Bluetooth: NO DETECTADO"))
                    Box(
                        Modifier.width(8.dp).height(8.dp)
                            .background(if (connected != null) Pal.ok else Pal.red, androidx.compose.foundation.shape.CircleShape)
                    )
                    Text(
                        if (shownMsg.isNotEmpty()) shownMsg else midiStatus,
                        color = if (shownMsg.isNotEmpty()) Pal.warn else Pal.dim, fontSize = 10.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    Text("VOL ${(ui.master / 0.7f * 100).toInt()}%", color = Pal.dim, fontSize = 9.sp, maxLines = 1)
                    Fader(
                        value = ui.master, onChange = { vm.setMaster(it) },
                        modifier = Modifier.width(70.dp).height(28.dp), vertical = false, color = Pal.ok
                    )
                    PressButton(if (Pal.day) "NOCHE" else "DIA", Modifier.width(48.dp).height(28.dp),
                        onPress = { vm.setDayMode(!Pal.day) })
                    WaveToggleButton(false, { vm.setVerticalView(true) }, Modifier.width(36.dp).height(28.dp))
                    PressButton("MIXER", Modifier.width(56.dp).height(28.dp), active = simple, color = Pal.warn,
                        onPress = { vm.setSimpleMode(!simple) })
                    PressButton("AUTO-MIX", Modifier.width(68.dp).height(28.dp), active = ui.autoMix, color = Pal.ok,
                        onPress = { vm.toggleAutoMix() })
                    PressButton("BIBLIOTECA", Modifier.width(80.dp).height(28.dp), active = libVisible,
                        onPress = { vm.libraryVisible.value = !libVisible })
                    PressButton("AJUSTES", Modifier.width(66.dp).height(28.dp),
                        onPress = { showSettings = true })
                }

                if (showAudioInfo) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "VERSION $APP_BUILD | AUDIO: " + ui.audioInfo, color = Pal.dim, fontSize = 9.sp, lineHeight = 10.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                }

                if (simple) {
                    SimpleMixer(ui, vm, Modifier.weight(1f).fillMaxWidth())
                } else {
                // ---- ondas
                Row(Modifier.fillMaxWidth().height(52.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        WaveStrip(ui.a, Pal.deckA, Modifier.weight(1f).fillMaxWidth(), win, { vm.cycleZoom() })
                        WaveStrip(ui.b, Pal.deckB, Modifier.weight(1f).fillMaxWidth(), win, { vm.cycleZoom() })
                    }
                }

                // ---- decks + mezclador
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    DeckPanel(ui.a, 0, ui.samplerMask, vm, Pal.deckA, Modifier.weight(1f).fillMaxHeight())
                    MixerPanel(ui, vm, Modifier.width(210.dp).fillMaxHeight())
                    DeckPanel(ui.b, 1, ui.samplerMask, vm, Pal.deckB, Modifier.weight(1f).fillMaxHeight())
                }
                }
            }
            }

            if (libVisible) {
                LibrarySheet(
                    vm, onRescan = { rescan() }, onPickFiles = { pickLauncher.launch(arrayOf("audio/*")) },
                    onPickFolder = { folderLauncher.launch(null) },
                    onClose = { vm.libraryVisible.value = false },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxSize()
                )
            }
            if (xfxVisible) XfxDialog(ui, vm) { vm.xfxVisible.value = false }
            if (showSettings) SettingsDialog(vm) { showSettings = false }
            if (splash) SplashOverlay()
        }
    }
}

/** Numero de version visible en pantalla: sirve para comprobar que se instalo el APK nuevo. */
const val APP_BUILD = "v50"

/** Indicador de conexion: punto verde si el dispositivo esta detectado. */
@androidx.compose.runtime.Composable
fun ConnChip(label: String, on: Boolean) {
    androidx.compose.foundation.layout.Row(
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(3.dp)
    ) {
        androidx.compose.foundation.layout.Box(
            androidx.compose.ui.Modifier.size(7.dp)
                .background(if (on) Pal.ok else Pal.track, androidx.compose.foundation.shape.CircleShape)
        )
        Text(label, color = if (on) Pal.text else Pal.dim, fontSize = 9.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
    }
}
