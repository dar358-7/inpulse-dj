#!/usr/bin/env python3
"""Genera app/src/main/assets/mappings/inpulse200.json y MIDI_MAP.md.
Fuente: preset oficial de Mixxx (DJ Phatso / Hercules Technical Support),
Hercules_DJControl_Inpulse_200.midi.xml + Hercules-DJControl-Inpulse-200-script.js
"""
import json, pathlib

b = []
def add(kind, status, d1, action, deck="", idx=0, note=""):
    b.append({"kind": kind, "status": f"0x{status:02X}", "data1": f"0x{d1:02X}",
              "action": action, "deck": deck, "idx": idx, "note": note})

# ---- Global (canal 1 / 4) ----
add("note", 0x90, 0x00, "browseClick", note="Encoder del navegador: pulsar")
add("note", 0x90, 0x03, "autoMix", note="Boton Assistant (Auto-mix)")
add("rel",  0xB0, 0x01, "browseTurn", note="Encoder del navegador: girar")
add("cc",   0xB0, 0x00, "crossfader", note="Crossfader")
add("note", 0x93, 0x00, "browseClickShift", note="SHIFT + encoder: pulsar (maximizar biblioteca)")
add("rel",  0xB3, 0x01, "browseTurnShift", note="SHIFT + encoder: girar (scroll rapido)")

for deck, ch, sh_ch, pad_ch in (("A", 1, 4, 6), ("B", 2, 5, 7)):
    n = 0x90 + ch   # 0x91 / 0x92
    s = 0x90 + sh_ch  # 0x94 / 0x95
    p = 0x90 + pad_ch  # 0x96 / 0x97
    c = 0xB0 + ch
    cs = 0xB0 + sh_ch
    # transporte
    add("note", n, 0x07, "play", deck, note="Play/Pause")
    add("note", n, 0x06, "cue", deck, note="Cue")
    add("note", n, 0x05, "sync", deck, note="Sync")
    add("note", n, 0x0C, "pfl", deck, note="Cue de auriculares (PFL)")
    add("note", n, 0x0D, "load", deck, note="Cargar la pista seleccionada")
    add("note", n, 0x03, "vinyl", deck, note="Boton Vinyl (scratch on/off)")
    add("note", n, 0x08, "jogTouch", deck, note="Toque en la parte superior del jog")
    add("note", n, 0x09, "loopIn", deck, note="Loop In (loop de 4 tiempos)")
    add("note", n, 0x0A, "loopOut", deck, note="Loop Out (reloop on/off)")
    # shift
    add("note", s, 0x08, "jogTouchShift", deck, note="SHIFT + toque del jog (seek)")
    add("note", s, 0x07, "playStutter", deck, note="SHIFT + Play: stutter")
    add("note", s, 0x06, "startPlay", deck, note="SHIFT + Cue: ir al inicio y reproducir")
    add("note", s, 0x05, "syncLeader", deck, note="SHIFT + Sync: Sync master")
    add("note", s, 0x09, "loopHalve", deck, note="SHIFT + Loop In: loop /2")
    add("note", s, 0x0A, "loopDouble", deck, note="SHIFT + Loop Out: loop x2")
    # pads
    for i in range(4):
        add("note", p, 0x00 + i, "hotcue", deck, i + 1, f"Pad {i+1} Hot Cue")
        add("note", p, 0x08 + i, "hotcueClear", deck, i + 1, f"SHIFT + Pad {i+1}: borrar Hot Cue")
        add("note", p, 0x10 + i, "roll", deck, i + 1, f"Pad {i+1} Roll ({[1,2,4,8][i]} tiempos)")
        add("note", p, 0x30 + i, "sampler", deck, i + 1, f"Pad {i+1} Sampler")
    for i in range(3):
        add("note", p, 0x20 + i, "fxSlot", deck, i + 1, f"Pad {i+1} FX {['Echo','Flanger','Reverb'][i]}")
        add("note", p, 0x28 + i, "fxSlot", deck, i + 1, f"SHIFT + Pad {i+1} FX")
    add("note", p, 0x23, "fxUnit", deck, 0, "Pad 4 FX: unidad de efectos on/off")
    add("note", p, 0x2B, "fxUnit", deck, 0, "SHIFT + Pad 4 FX: unidad on/off")
    # CCs
    add("cc",   c, 0x00, "volume", deck, note="Fader de canal")
    add("cc",   c, 0x01, "filter", deck, note="Filtro")
    add("cc",   c, 0x02, "eqLow", deck, note="EQ graves")
    add("cc",   c, 0x04, "eqHigh", deck, note="EQ agudos")
    add("cc",   c, 0x05, "gain", deck, note="Ganancia")
    add("cc14msb", c, 0x08, "pitch", deck, note="Fader de pitch (MSB)")
    add("cc14lsb", c, 0x28, "pitch", deck, note="Fader de pitch (LSB)")
    add("rel",  c, 0x0A, "jogScratch", deck, note="Jog: giro (scratch / bend)")
    add("rel",  c, 0x09, "jogBend", deck, note="Jog: borde (pitch bend)")
    add("rel",  cs, 0x0A, "jogScratchShift", deck, note="SHIFT + jog: seek rapido")

doc = {
    "device": "Hercules DJControl Inpulse 200",
    "nameHints": ["inpulse", "hercules", "djcontrol"],
    "init": ["B0 7F 7F"],
    "shutdown": ["B0 7F 7E", "90 04 00"],
    "bindings": b,
}
root = pathlib.Path(__file__).resolve().parent.parent
out = root / "app/src/main/assets/mappings/inpulse200.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(doc, indent=1))

# markdown
lines = ["# Mapa MIDI - Hercules DJControl Inpulse 200", "",
         "| Estado | Dato1 | Tipo | Accion | Deck | Descripcion |", "|---|---|---|---|---|---|"]
for x in b:
    lines.append(f"| {x['status']} | {x['data1']} | {x['kind']} | {x['action']}{'' if not x['idx'] else ' '+str(x['idx'])} | {x['deck']} | {x['note']} |")
(root / "MIDI_MAP.md").write_text("\n".join(lines) + "\n")
print(len(b), "bindings ->", out)
