# Inpulse DJ - app de DJ para Android (estilo edjing) con Hercules DJControl Inpulse 200

App de DJ de 2 decks hecha con Kotlin + Jetpack Compose. Se maneja con la pantalla o con una
**Hercules DJControl Inpulse 200 por USB-MIDI** (class-compliant, sin drivers).

## Compilar
1. Instala Android Studio (Koala o posterior) y abre la carpeta `InpulseDJ`.
2. Deja que sincronice Gradle (si falta el wrapper: `gradle wrapper --gradle-version 8.9`).
3. Run en un movil Android 7.0+ (minSdk 24). Se usa en horizontal.
4. Concede el permiso de audio para ver tu musica o usa "ARCHIVOS..." para elegir pistas.

## Conectar la Inpulse 200
1. Cable USB-C/OTG entre el movil y el puerto USB de la Inpulse.
2. Abre la app: se conecta sola (aparece el punto verde y el nombre arriba).
   Si no, "MIDI / AJUSTES" -> CONECTAR.
3. Al conectar, la app envia el mensaje de arranque del script oficial (B0 7F 7F) para que el
   controlador mande la posicion de faders y perillas, y enciende los LEDs del vinilo y del navegador.

## Mapeo de la Inpulse 200 (completo, tomado del preset oficial de Mixxx)
Ver `MIDI_MAP.md` (104 asignaciones) y `app/src/main/assets/mappings/inpulse200.json`.
Resumen:
- Deck A canal 2 (0x91/0xB1), deck B canal 3 (0x92/0xB2); SHIFT usa canales 5/6 (0x94/0x95), jog shift 0xB4/0xB5.
- Botones: Play, Cue, Sync, PFL, Load, Vinyl, Loop In/Out, toque del jog.
- SHIFT: Play = stutter, Cue = inicio y play, Sync = master, Loop In/Out = loop /2 y x2, jog = seek x4.
- Pads (0x96 / 0x97): Hot Cue 1-4 (SHIFT = borrar), Roll 1/2/4/8 tiempos, FX (Echo, Flanger, Reverb + unidad),
  Sampler 1-4 (deck A) y 5-8 (deck B).
- Faders/perillas: crossfader, volumen de canal, ganancia, EQ graves/agudos, filtro, pitch (14 bits, MSB 0x08 + LSB 0x28).
- Jog: giro de la parte superior (scratch / bend), borde (pitch bend); el boton Vinyl decide scratch o bend durante la reproduccion.
- Encoder del navegador: girar = mover seleccion, pulsar = abrir/cerrar biblioteca; SHIFT = salto de 8 pistas.
- Boton Assistant = Auto-mix.
- LEDs de retorno: Play, Cue, Sync, Loop, PFL, Vinyl, pads (hot cues, rolls, FX, samplers), aviso de fin de pista, Assistant.
- Los mandos MASTER y HEADPHONES de la Inpulse son analogicos (tarjeta de sonido interna): no envian nada que la app use.
- MIDI Learn en Ajustes para reasignar cualquier control; el monitor MIDI muestra lo que llega.

## Funciones de la app
Decodificacion de mp3/aac/flac/wav/ogg, deteccion automatica de BPM y rejilla, onda desplazable,
pitch +-4..50%, sync de tempo y fase, cue/hot cues, loops, rolls (slip), scratch, EQ 3 bandas + filtro,
efectos (echo, flanger, reverb), 8 samplers sinteticos, crossfader, VU, cue dividido para auriculares, auto-mix.

## Limitaciones conocidas (honestas)
- El codigo no pudo compilarse en el entorno donde se escribio (sin SDK de Android). La logica de audio, DSP,
  deteccion de BPM y parser MIDI si se compilo y probo en JVM; la capa Android/Compose no se ha ejecutado:
  espera algun ajuste menor al primer build.
- El mapeo viene del preset oficial de Mixxx. Direccion del fader de pitch: si va al reves, activa "Invertir" en Ajustes.
- Cada pista se descomprime a memoria (maximo 10 min por pista).
- La salida de audio va por la tarjeta que Android tenga activa (estereo). La tarjeta de 4 canales de la
  Inpulse no se usa; para cuear usa el modo "cue dividido" con un cable en Y.

## Compilar sin PC (solo con el celular)
1. Crea una cuenta gratis en github.com y un repositorio nuevo.
2. Sube el contenido de esta carpeta (en el navegador: Add file > Upload files; incluye la carpeta .github).
3. Pestaña Actions > "Build APK" > Run workflow. Tarda unos minutos.
4. Entra en la ejecución terminada, baja a Artifacts y descarga "InpulseDJ-apk" (zip con el .apk).
5. Abre el .apk en el celular (permite "instalar apps desconocidas") y conecta la Inpulse 200 con un cable/adaptador OTG.
