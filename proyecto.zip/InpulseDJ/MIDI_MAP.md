# Mapa MIDI - Hercules DJControl Inpulse 200

| Estado | Dato1 | Tipo | Accion | Deck | Descripcion |
|---|---|---|---|---|---|
| 0x90 | 0x00 | note | browseClick |  | Encoder del navegador: pulsar |
| 0x90 | 0x03 | note | autoMix |  | Boton Assistant (Auto-mix) |
| 0xB0 | 0x01 | rel | browseTurn |  | Encoder del navegador: girar |
| 0xB0 | 0x00 | cc | crossfader |  | Crossfader |
| 0x93 | 0x00 | note | browseClickShift |  | SHIFT + encoder: pulsar (maximizar biblioteca) |
| 0xB3 | 0x01 | rel | browseTurnShift |  | SHIFT + encoder: girar (scroll rapido) |
| 0x91 | 0x07 | note | play | A | Play/Pause |
| 0x91 | 0x06 | note | cue | A | Cue |
| 0x91 | 0x05 | note | sync | A | Sync |
| 0x91 | 0x0C | note | pfl | A | Cue de auriculares (PFL) |
| 0x91 | 0x0D | note | load | A | Cargar la pista seleccionada |
| 0x91 | 0x03 | note | vinyl | A | Boton Vinyl (scratch on/off) |
| 0x91 | 0x08 | note | jogTouch | A | Toque en la parte superior del jog |
| 0x91 | 0x09 | note | loopIn | A | Loop In (loop de 4 tiempos) |
| 0x91 | 0x0A | note | loopOut | A | Loop Out (reloop on/off) |
| 0x94 | 0x08 | note | jogTouchShift | A | SHIFT + toque del jog (seek) |
| 0x94 | 0x07 | note | playStutter | A | SHIFT + Play: stutter |
| 0x94 | 0x06 | note | startPlay | A | SHIFT + Cue: ir al inicio y reproducir |
| 0x94 | 0x05 | note | syncLeader | A | SHIFT + Sync: Sync master |
| 0x94 | 0x09 | note | loopHalve | A | SHIFT + Loop In: loop /2 |
| 0x94 | 0x0A | note | loopDouble | A | SHIFT + Loop Out: loop x2 |
| 0x96 | 0x00 | note | hotcue 1 | A | Pad 1 Hot Cue |
| 0x96 | 0x08 | note | hotcueClear 1 | A | SHIFT + Pad 1: borrar Hot Cue |
| 0x96 | 0x10 | note | roll 1 | A | Pad 1 Roll (1 tiempos) |
| 0x96 | 0x30 | note | sampler 1 | A | Pad 1 Sampler |
| 0x96 | 0x01 | note | hotcue 2 | A | Pad 2 Hot Cue |
| 0x96 | 0x09 | note | hotcueClear 2 | A | SHIFT + Pad 2: borrar Hot Cue |
| 0x96 | 0x11 | note | roll 2 | A | Pad 2 Roll (2 tiempos) |
| 0x96 | 0x31 | note | sampler 2 | A | Pad 2 Sampler |
| 0x96 | 0x02 | note | hotcue 3 | A | Pad 3 Hot Cue |
| 0x96 | 0x0A | note | hotcueClear 3 | A | SHIFT + Pad 3: borrar Hot Cue |
| 0x96 | 0x12 | note | roll 3 | A | Pad 3 Roll (4 tiempos) |
| 0x96 | 0x32 | note | sampler 3 | A | Pad 3 Sampler |
| 0x96 | 0x03 | note | hotcue 4 | A | Pad 4 Hot Cue |
| 0x96 | 0x0B | note | hotcueClear 4 | A | SHIFT + Pad 4: borrar Hot Cue |
| 0x96 | 0x13 | note | roll 4 | A | Pad 4 Roll (8 tiempos) |
| 0x96 | 0x33 | note | sampler 4 | A | Pad 4 Sampler |
| 0x96 | 0x20 | note | fxSlot 1 | A | Pad 1 FX Echo |
| 0x96 | 0x28 | note | fxSlot 1 | A | SHIFT + Pad 1 FX |
| 0x96 | 0x21 | note | fxSlot 2 | A | Pad 2 FX Flanger |
| 0x96 | 0x29 | note | fxSlot 2 | A | SHIFT + Pad 2 FX |
| 0x96 | 0x22 | note | fxSlot 3 | A | Pad 3 FX Reverb |
| 0x96 | 0x2A | note | fxSlot 3 | A | SHIFT + Pad 3 FX |
| 0x96 | 0x23 | note | fxUnit | A | Pad 4 FX: unidad de efectos on/off |
| 0x96 | 0x2B | note | fxUnit | A | SHIFT + Pad 4 FX: unidad on/off |
| 0xB1 | 0x00 | cc | volume | A | Fader de canal |
| 0xB1 | 0x01 | cc | filter | A | Filtro |
| 0xB1 | 0x02 | cc | eqLow | A | EQ graves |
| 0xB1 | 0x04 | cc | eqHigh | A | EQ agudos |
| 0xB1 | 0x05 | cc | gain | A | Ganancia |
| 0xB1 | 0x08 | cc14msb | pitch | A | Fader de pitch (MSB) |
| 0xB1 | 0x28 | cc14lsb | pitch | A | Fader de pitch (LSB) |
| 0xB1 | 0x0A | rel | jogScratch | A | Jog: giro (scratch / bend) |
| 0xB1 | 0x09 | rel | jogBend | A | Jog: borde (pitch bend) |
| 0xB4 | 0x0A | rel | jogScratchShift | A | SHIFT + jog: seek rapido |
| 0x92 | 0x07 | note | play | B | Play/Pause |
| 0x92 | 0x06 | note | cue | B | Cue |
| 0x92 | 0x05 | note | sync | B | Sync |
| 0x92 | 0x0C | note | pfl | B | Cue de auriculares (PFL) |
| 0x92 | 0x0D | note | load | B | Cargar la pista seleccionada |
| 0x92 | 0x03 | note | vinyl | B | Boton Vinyl (scratch on/off) |
| 0x92 | 0x08 | note | jogTouch | B | Toque en la parte superior del jog |
| 0x92 | 0x09 | note | loopIn | B | Loop In (loop de 4 tiempos) |
| 0x92 | 0x0A | note | loopOut | B | Loop Out (reloop on/off) |
| 0x95 | 0x08 | note | jogTouchShift | B | SHIFT + toque del jog (seek) |
| 0x95 | 0x07 | note | playStutter | B | SHIFT + Play: stutter |
| 0x95 | 0x06 | note | startPlay | B | SHIFT + Cue: ir al inicio y reproducir |
| 0x95 | 0x05 | note | syncLeader | B | SHIFT + Sync: Sync master |
| 0x95 | 0x09 | note | loopHalve | B | SHIFT + Loop In: loop /2 |
| 0x95 | 0x0A | note | loopDouble | B | SHIFT + Loop Out: loop x2 |
| 0x97 | 0x00 | note | hotcue 1 | B | Pad 1 Hot Cue |
| 0x97 | 0x08 | note | hotcueClear 1 | B | SHIFT + Pad 1: borrar Hot Cue |
| 0x97 | 0x10 | note | roll 1 | B | Pad 1 Roll (1 tiempos) |
| 0x97 | 0x30 | note | sampler 1 | B | Pad 1 Sampler |
| 0x97 | 0x01 | note | hotcue 2 | B | Pad 2 Hot Cue |
| 0x97 | 0x09 | note | hotcueClear 2 | B | SHIFT + Pad 2: borrar Hot Cue |
| 0x97 | 0x11 | note | roll 2 | B | Pad 2 Roll (2 tiempos) |
| 0x97 | 0x31 | note | sampler 2 | B | Pad 2 Sampler |
| 0x97 | 0x02 | note | hotcue 3 | B | Pad 3 Hot Cue |
| 0x97 | 0x0A | note | hotcueClear 3 | B | SHIFT + Pad 3: borrar Hot Cue |
| 0x97 | 0x12 | note | roll 3 | B | Pad 3 Roll (4 tiempos) |
| 0x97 | 0x32 | note | sampler 3 | B | Pad 3 Sampler |
| 0x97 | 0x03 | note | hotcue 4 | B | Pad 4 Hot Cue |
| 0x97 | 0x0B | note | hotcueClear 4 | B | SHIFT + Pad 4: borrar Hot Cue |
| 0x97 | 0x13 | note | roll 4 | B | Pad 4 Roll (8 tiempos) |
| 0x97 | 0x33 | note | sampler 4 | B | Pad 4 Sampler |
| 0x97 | 0x20 | note | fxSlot 1 | B | Pad 1 FX Echo |
| 0x97 | 0x28 | note | fxSlot 1 | B | SHIFT + Pad 1 FX |
| 0x97 | 0x21 | note | fxSlot 2 | B | Pad 2 FX Flanger |
| 0x97 | 0x29 | note | fxSlot 2 | B | SHIFT + Pad 2 FX |
| 0x97 | 0x22 | note | fxSlot 3 | B | Pad 3 FX Reverb |
| 0x97 | 0x2A | note | fxSlot 3 | B | SHIFT + Pad 3 FX |
| 0x97 | 0x23 | note | fxUnit | B | Pad 4 FX: unidad de efectos on/off |
| 0x97 | 0x2B | note | fxUnit | B | SHIFT + Pad 4 FX: unidad on/off |
| 0xB2 | 0x00 | cc | volume | B | Fader de canal |
| 0xB2 | 0x01 | cc | filter | B | Filtro |
| 0xB2 | 0x02 | cc | eqLow | B | EQ graves |
| 0xB2 | 0x04 | cc | eqHigh | B | EQ agudos |
| 0xB2 | 0x05 | cc | gain | B | Ganancia |
| 0xB2 | 0x08 | cc14msb | pitch | B | Fader de pitch (MSB) |
| 0xB2 | 0x28 | cc14lsb | pitch | B | Fader de pitch (LSB) |
| 0xB2 | 0x0A | rel | jogScratch | B | Jog: giro (scratch / bend) |
| 0xB2 | 0x09 | rel | jogBend | B | Jog: borde (pitch bend) |
| 0xB5 | 0x0A | rel | jogScratchShift | B | SHIFT + jog: seek rapido |
