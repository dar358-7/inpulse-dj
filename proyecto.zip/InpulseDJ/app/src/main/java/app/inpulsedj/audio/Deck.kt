package app.inpulsedj.audio

import java.util.Arrays
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.pow

/**
 * Un deck. Los metodos `cmd*` SOLO se llaman desde el hilo de audio (via DjEngine.post);
 * los campos @Volatile pueden leerse/escribirse desde cualquier hilo.
 */
class Deck(val index: Int, private val outRate: Int) {
    @Volatile var track: Track? = null
        private set
    @Volatile var pos = 0.0          // fotogramas de la pista original
    @Volatile var playing = false
    @Volatile var tempo = 1.0        // 1.0 = velocidad original
    @Volatile var nudge = 1.0        // correccion fina de fase (sync), ~1.0
    @Volatile var bpm = 0.0          // BPM base de la pista
    @Volatile var anchorSec = 0.0    // posicion de un tiempo "1"
    @Volatile var volume = 1f
    @Volatile var gain = 0.5f
    @Volatile var pfl = false
    @Volatile var vinyl = true
    @Volatile var sync = false
    @Volatile var leader = false
    @Volatile var cuePoint = 0.0
    @Volatile var cuePreview = false
    @Volatile var hotcuePreview = 0
    @Volatile var loopStart = -1.0
    @Volatile var loopEnd = -1.0
    @Volatile var loopActive = false
    @Volatile var rollIdx = 0
    @Volatile var scratching = false
    @Volatile var level = 0f
    @Volatile var fxUnitOn = true
    @Volatile var jogSensitivity = 1.0

    val fxSlotOn = BooleanArray(3)
    val hotcues = DoubleArray(4) { -1.0 }

    val eq = Eq3(outRate.toDouble())
    val filter = DjFilter(outRate.toDouble())
    val echo = EchoFx(outRate)
    val flanger = FlangerFx(outRate)
    val reverb = ReverbFx(outRate)

    private val jogTicks = AtomicInteger(0)
    private var seekMul = 1.0
    private var bend = 0.0
    private var scratchVel = 0.0
    private var curSpeed = 0.0
    private var slipPos = 0.0
    private var slipActive = false
    private var rollPrevStart = -1.0
    private var rollPrevEnd = -1.0
    private var rollPrevActive = false

    /** Hilo seguro: acumula ticks del jog (+ horario / - antihorario). */
    fun addJog(ticks: Int) {
        jogTicks.addAndGet(ticks)
    }

    // ---------------------------------------------------------------- render

    fun render(out: FloatArray, frames: Int) {
        val n2 = frames * 2
        val t = track
        if (t == null) {
            Arrays.fill(out, 0, n2, 0f)
        } else {
            val sr = t.sampleRate
            val srcPerOut = sr.toDouble() / outRate
            val ticks = jogTicks.getAndSet(0)
            val target: Double
            var slew = 0.004
            if (scratching) {
                val fpt = sr * 1.8 / 248.0 * jogSensitivity * seekMul
                val inst = ticks * fpt / frames
                scratchVel = scratchVel * 0.5 + inst * 0.5
                target = scratchVel
                slew = 0.08
            } else {
                scratchVel = 0.0
                bend = (bend * 0.92 + ticks * 0.03 * jogSensitivity).coerceIn(-0.6, 0.6)
                target = if (playing) srcPerOut * tempo * nudge * (1.0 + bend) else 0.0
            }
            val normalStep = srcPerOut * tempo * nudge
            val data = t.pcm
            val n = t.frames
            val ls = loopStart
            val le = loopEnd
            val la = loopActive && ls >= 0.0 && le > ls
            val slip = slipActive
            var p = pos
            var sp = curSpeed
            val inv = 1f / 32768f
            for (i in 0 until frames) {
                sp += (target - sp) * slew
                if (p >= 0.0 && p < n - 1) {
                    val ip = p.toInt()
                    val fr = (p - ip).toFloat()
                    val j = ip * 2
                    val l0 = data[j].toFloat()
                    val r0 = data[j + 1].toFloat()
                    out[2 * i] = (l0 + (data[j + 2] - l0) * fr) * inv
                    out[2 * i + 1] = (r0 + (data[j + 3] - r0) * fr) * inv
                } else {
                    out[2 * i] = 0f
                    out[2 * i + 1] = 0f
                }
                val prev = p
                p += sp
                if (la && sp > 0.0 && prev < le && p >= le) p = ls + (p - le)
                if (slip) slipPos += normalStep
            }
            curSpeed = sp
            if (p < 0.0) p = 0.0
            if (p >= n - 1) {
                p = (n - 1).toDouble()
                if (!scratching && playing) {
                    playing = false
                    cuePreview = false
                    hotcuePreview = 0
                    curSpeed = 0.0
                }
            }
            pos = p

            val trim = 10.0.pow(((gain - 0.5f) * 24f / 20f).toDouble()).toFloat()
            if (trim != 1f) for (i in 0 until n2) out[i] *= trim
        }

        val unit = fxUnitOn
        echo.enabled = unit && fxSlotOn[0]
        flanger.enabled = unit && fxSlotOn[1]
        reverb.enabled = unit && fxSlotOn[2]
        if (bpm > 0.0) echo.beatSeconds = 60.0 / (bpm * max(0.25, tempo))
        eq.process(out, frames)
        filter.process(out, frames)
        echo.process(out, frames)
        flanger.process(out, frames)
        reverb.process(out, frames)

        var pk = 0f
        for (i in 0 until n2) {
            val a = abs(out[i])
            if (a > pk) pk = a
        }
        level = max(pk, level * 0.97f)
    }

    // ---------------------------------------------------------------- comandos

    fun cmdLoad(t: Track?) {
        playing = false
        cuePreview = false
        hotcuePreview = 0
        scratching = false
        track = t
        pos = 0.0
        curSpeed = 0.0
        cuePoint = 0.0
        for (i in 0..3) hotcues[i] = -1.0
        loopStart = -1.0
        loopEnd = -1.0
        loopActive = false
        rollIdx = 0
        slipActive = false
        bpm = t?.bpm ?: 0.0
        anchorSec = t?.anchorSec ?: 0.0
    }

    fun cmdTogglePlay() {
        if (track == null) return
        if (cuePreview || hotcuePreview != 0) {
            cuePreview = false
            hotcuePreview = 0
            return
        }
        playing = !playing
    }

    fun cmdCuePress() {
        val t = track ?: return
        if (playing) {
            if (cuePreview) {
                cuePreview = false
                return
            }
            playing = false
            pos = cuePoint
        } else {
            val atCue = abs(pos - cuePoint) < t.sampleRate * 0.02
            if (atCue) {
                cuePreview = true
                playing = true
            } else {
                cuePoint = pos
            }
        }
    }

    fun cmdCueRelease() {
        if (cuePreview) {
            cuePreview = false
            playing = false
            pos = cuePoint
        }
    }

    fun cmdPlayStutter() {
        if (track == null) return
        pos = cuePoint
        playing = true
    }

    fun cmdStartPlay() {
        if (track == null) return
        pos = 0.0
        playing = true
    }

    fun cmdSeekFrames(f: Double) {
        val t = track ?: return
        pos = f.coerceIn(0.0, (t.frames - 1).toDouble())
    }

    fun cmdHotcuePress(i: Int) {
        if (track == null || i !in 0..3) return
        val h = hotcues[i]
        if (h < 0.0) {
            hotcues[i] = pos
        } else {
            val was = playing
            pos = h
            if (!was) {
                playing = true
                hotcuePreview = i + 1
            }
        }
    }

    fun cmdHotcueRelease(i: Int) {
        if (hotcuePreview == i + 1) {
            hotcuePreview = 0
            playing = false
            pos = hotcues[i].coerceAtLeast(0.0)
        }
    }

    fun cmdHotcueClear(i: Int) {
        if (i in 0..3) hotcues[i] = -1.0
    }

    private fun beatFrames(): Double {
        val t = track ?: return 0.0
        return if (bpm > 0.0) 60.0 / bpm * t.sampleRate else 0.5 * t.sampleRate
    }

    private fun snap(p: Double): Double {
        val t = track ?: return p
        if (bpm <= 0.0) return p
        val bf = beatFrames()
        val anchor = anchorSec * t.sampleRate
        return anchor + Math.round((p - anchor) / bf) * bf
    }

    fun cmdLoopIn() {
        if (track == null) return
        if (loopActive) {
            loopActive = false
            return
        }
        val s = snap(pos)
        loopStart = s
        loopEnd = s + 4.0 * beatFrames()
        loopActive = true
    }

    fun cmdReloop() {
        if (loopStart < 0.0 || loopEnd <= loopStart) return
        loopActive = !loopActive
    }

    fun cmdLoopHalve() {
        val t = track ?: return
        if (loopEnd <= loopStart) return
        val len = (loopEnd - loopStart) / 2.0
        if (len > t.sampleRate / 100.0) loopEnd = loopStart + len
    }

    fun cmdLoopDouble() {
        val t = track ?: return
        if (loopEnd <= loopStart) return
        val len = (loopEnd - loopStart) * 2.0
        if (loopStart + len < t.frames - 1) loopEnd = loopStart + len
    }

    fun cmdRollPress(i: Int, beats: Double) {
        if (track == null || !playing) return
        if (rollIdx == 0) {
            rollPrevStart = loopStart
            rollPrevEnd = loopEnd
            rollPrevActive = loopActive
            slipPos = pos
        }
        loopStart = pos
        loopEnd = pos + beats * beatFrames()
        loopActive = true
        rollIdx = i
        slipActive = true
    }

    fun cmdRollRelease(i: Int) {
        if (rollIdx != i) return
        rollIdx = 0
        slipActive = false
        loopStart = rollPrevStart
        loopEnd = rollPrevEnd
        loopActive = rollPrevActive
        val t = track ?: return
        pos = slipPos.coerceIn(0.0, (t.frames - 1).toDouble())
    }

    fun cmdJogTouch(down: Boolean, shift: Boolean) {
        if (down) {
            if (shift) {
                scratching = true
                seekMul = 4.0
            } else if (!playing || vinyl) {
                scratching = true
                seekMul = 1.0
            } else {
                scratching = false
            }
            scratchVel = 0.0
        } else {
            scratching = false
            seekMul = 1.0
        }
        jogTicks.set(0)
    }

    fun cmdSetBpm(v: Double) {
        bpm = v.coerceIn(40.0, 250.0)
    }

    fun cmdSetAnchorHere() {
        val t = track ?: return
        anchorSec = pos / t.sampleRate
    }

    /** true si el usuario esta tocando el jog (scratch o bend): el sync no debe interferir. */
    fun isNudged(): Boolean = scratching || abs(bend) > 0.01

    /** Fase dentro del tiempo (0..1) o null si no hay rejilla. */
    fun phase(): Double? {
        val t = track ?: return null
        if (bpm <= 0.0) return null
        val bf = beatFrames()
        val a = anchorSec * t.sampleRate
        var x = ((pos - a) / bf) % 1.0
        if (x < 0.0) x += 1.0
        return x
    }

    fun cmdShiftBeats(d: Double) {
        val t = track ?: return
        pos = (pos + d * beatFrames()).coerceIn(0.0, (t.frames - 1).toDouble())
    }

    val effectiveBpm: Double get() = bpm * tempo
}
