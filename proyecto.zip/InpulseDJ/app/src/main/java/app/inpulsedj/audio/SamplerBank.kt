package app.inpulsedj.audio

import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 8 samplers (pads 1-4 del deck A = 1-4, pads 1-4 del deck B = 5-8).
 * Los sonidos se sintetizan al arrancar, asi la app no necesita archivos extra.
 */
class SamplerBank(private val sr: Int) {
    val names = listOf("Kick", "Snare", "Clap", "Hat", "Air horn", "Siren", "Laser", "Crash")

    private val data: Array<FloatArray> = arrayOf(
        stereo(kick()), stereo(snare()), stereo(clap()), stereo(hat()),
        stereo(airHorn()), stereo(siren()), stereo(laser()), stereo(crash())
    )
    private val pos = IntArray(8) { -1 }

    fun trigger(i: Int) {
        if (i in 0..7) pos[i] = 0
    }

    fun isPlaying(i: Int): Boolean = pos[i] >= 0

    fun playingMask(): Int {
        var m = 0
        for (i in 0..7) if (pos[i] >= 0) m = m or (1 shl i)
        return m
    }

    /** Suma (+=) en [out] estereo intercalado. */
    fun render(out: FloatArray, frames: Int) {
        for (v in 0..7) {
            var p = pos[v]
            if (p < 0) continue
            val d = data[v]
            val total = d.size / 2
            var i = 0
            while (i < frames && p < total) {
                out[2 * i] += d[2 * p]
                out[2 * i + 1] += d[2 * p + 1]
                i++
                p++
            }
            pos[v] = if (p >= total) -1 else p
        }
    }

    // ---------- sintesis ----------
    private fun n(sec: Double) = (sec * sr).toInt()

    private fun stereo(m: FloatArray): FloatArray {
        var pk = 0f
        for (x in m) pk = max(pk, abs(x))
        val g = if (pk > 0f) 0.8f / pk else 1f
        val o = FloatArray(m.size * 2)
        for (i in m.indices) {
            o[2 * i] = m[i] * g
            o[2 * i + 1] = m[i] * g
        }
        return o
    }

    private fun kick(): FloatArray {
        val len = n(0.45)
        val o = FloatArray(len)
        var ph = 0.0
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            val f = 45.0 + 120.0 * exp(-t * 30.0)
            ph += 2.0 * PI * f / sr
            o[i] = (sin(ph) * exp(-t * 8.0)).toFloat()
        }
        return o
    }

    private fun snare(): FloatArray {
        val rnd = Random(11)
        val len = n(0.3)
        val o = FloatArray(len)
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            val noise = (rnd.nextFloat() * 2f - 1f) * exp(-t * 18.0).toFloat() * 0.6f
            val tone = (sin(2.0 * PI * 185.0 * t) * exp(-t * 22.0)).toFloat() * 0.5f
            o[i] = noise + tone
        }
        return o
    }

    private fun clap(): FloatArray {
        val rnd = Random(22)
        val len = n(0.35)
        val o = FloatArray(len)
        val bursts = doubleArrayOf(0.0, 0.012, 0.024, 0.038)
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            var env = 0.0
            for (b in bursts) if (t >= b) env += exp(-(t - b) * (if (b == 0.038) 20.0 else 90.0))
            o[i] = (rnd.nextFloat() * 2f - 1f) * min(1.0, env).toFloat()
        }
        return o
    }

    private fun hat(): FloatArray {
        val rnd = Random(33)
        val len = n(0.12)
        val o = FloatArray(len)
        var prev = 0f
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            val x = rnd.nextFloat() * 2f - 1f
            o[i] = (x - prev) * exp(-t * 45.0).toFloat()
            prev = x
        }
        return o
    }

    private fun airHorn(): FloatArray {
        val len = n(1.1)
        val o = FloatArray(len)
        var ph = 0.0
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            val vib = 1.0 + 0.004 * sin(2.0 * PI * 6.0 * t)
            ph += 2.0 * PI * 466.0 * vib / sr
            var s = 0.0
            for (h in 1..6) s += sin(ph * h) / h
            val env = min(1.0, t / 0.02) * (if (t > 0.9) max(0.0, (1.1 - t) / 0.2) else 1.0)
            o[i] = (s * env).toFloat()
        }
        return o
    }

    private fun siren(): FloatArray {
        val len = n(1.6)
        val o = FloatArray(len)
        var ph = 0.0
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            val f = 800.0 + 350.0 * sin(2.0 * PI * 1.25 * t)
            ph += 2.0 * PI * f / sr
            val env = min(1.0, t / 0.03) * (if (t > 1.4) max(0.0, (1.6 - t) / 0.2) else 1.0)
            o[i] = (sin(ph) * env).toFloat()
        }
        return o
    }

    private fun laser(): FloatArray {
        val len = n(0.4)
        val o = FloatArray(len)
        var ph = 0.0
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            val f = 300.0 + 4200.0 * exp(-t * 9.0)
            ph += 2.0 * PI * f / sr
            o[i] = (sin(ph) * exp(-t * 5.0)).toFloat()
        }
        return o
    }

    private fun crash(): FloatArray {
        val rnd = Random(44)
        val len = n(1.8)
        val o = FloatArray(len)
        var prev = 0f
        for (i in 0 until len) {
            val t = i.toDouble() / sr
            val x = rnd.nextFloat() * 2f - 1f
            o[i] = (x - prev * 0.6f) * exp(-t * 2.4).toFloat()
            prev = x
        }
        return o
    }
}
