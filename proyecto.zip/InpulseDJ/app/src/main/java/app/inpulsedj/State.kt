package app.inpulsedj

import android.net.Uri

data class LibTrack(
    val uri: Uri, val title: String, val artist: String, val durationMs: Long,
    val folder: String = "", val bpm: Double = 0.0, val key: String = ""
)

data class DeckUi(
    val loaded: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val posSec: Double = 0.0,
    val durSec: Double = 0.0,
    val playing: Boolean = false,
    val baseBpm: Double = 0.0,
    val effBpm: Double = 0.0,
    val tempoPct: Double = 0.0,
    val tempo: Double = 1.0,
    val sync: Boolean = false,
    val leader: Boolean = false,
    val pfl: Boolean = false,
    val vinyl: Boolean = true,
    val cuePoint: Double = 0.0,
    val cuePreview: Boolean = false,
    val hotcues: List<Double> = listOf(-1.0, -1.0, -1.0, -1.0),
    val loopStart: Double = -1.0,
    val loopEnd: Double = -1.0,
    val loopActive: Boolean = false,
    val rollIdx: Int = 0,
    val fxUnit: Boolean = true,
    val fx: List<Boolean> = listOf(false, false, false),
    val level: Float = 0f,
    val volume: Float = 1f,
    val gain: Float = 0.5f,
    val eqLow: Float = 0.5f,
    val eqMid: Float = 0.5f,
    val eqHigh: Float = 0.5f,
    val filter: Float = 0.5f,
    val loading: Float = -1f,
    val peaks: FloatArray? = null,
    val bands: FloatArray? = null,
    val key: String = "",
    val bar: Int = 0,
    val beat: Int = 0,
    val anchorSec: Double = 0.0,
    val platterDeg: Float = 0f
)

data class DjUi(
    val a: DeckUi = DeckUi(),
    val b: DeckUi = DeckUi(),
    val crossfader: Float = 0.5f,
    val master: Float = 0.85f,
    val masterLevel: Float = 0f,
    val samplerMask: Int = 0,
    val autoMix: Boolean = false
)
