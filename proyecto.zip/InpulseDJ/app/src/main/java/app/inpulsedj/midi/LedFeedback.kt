package app.inpulsedj.midi

import app.inpulsedj.DeckUi
import app.inpulsedj.DjUi

/**
 * Enciende los LEDs de la Inpulse 200 segun el estado de la app.
 * Solo envia cambios (diferencial). Valores segun el preset oficial:
 * botones 0x7F, pads hot cue 0x7E, LED del encoder 0x05 (azul).
 */
class LedFeedback(private val midi: UsbMidi) {
    private val last = HashMap<Int, Int>()

    fun reset() {
        last.clear()
    }

    private fun set(status: Int, note: Int, value: Int) {
        val k = (status shl 8) or note
        if (last[k] == value) return
        last[k] = value
        midi.send3(status, note, value)
    }

    fun update(s: DjUi, blink: Boolean) {
        if (!midi.isConnected) return
        deck(0x91, 0x96, s.a, blink)
        deck(0x92, 0x97, s.b, blink)
        set(0x90, 0x03, if (s.autoMix) 0x7F else 0)
        set(0x90, 0x04, 0x05)
        // samplers: deck A = 1-4, deck B = 5-8
        for (i in 0..3) {
            set(0x96, 0x30 + i, if ((s.samplerMask shr i) and 1 == 1) 0x7F else 0)
            set(0x97, 0x30 + i, if ((s.samplerMask shr (i + 4)) and 1 == 1) 0x7F else 0)
        }
    }

    private fun deck(n: Int, p: Int, d: DeckUi, blink: Boolean) {
        val atCue = d.loaded && !d.playing && kotlin.math.abs(d.posSec - d.cuePoint) < 0.03
        set(n, 0x07, if (d.playing) 0x7F else 0)
        set(n, 0x06, if (atCue || d.cuePreview) 0x7F else 0)
        set(n, 0x05, if (d.sync) 0x7F else 0)
        set(n, 0x09, if (d.loopActive) 0x7F else 0)
        set(n, 0x0C, if (d.pfl) 0x7F else 0)
        set(n, 0x03, if (d.vinyl) 0x7F else 0)
        val warn = d.loaded && d.playing && (d.durSec - d.posSec) < 30.0 && blink
        set(n, 0x1C, if (warn) 0x7F else 0)
        set(n, 0x1D, if (warn) 0x7F else 0)
        for (i in 0..3) {
            val hot = if (d.hotcues[i] >= 0.0) 0x7E else 0
            set(p, i, hot)
            set(p, 0x08 + i, hot)
            set(p, 0x10 + i, if (d.rollIdx == i + 1) 0x7F else 0)
        }
        for (i in 0..2) {
            val on = if (d.fx[i]) 0x7F else 0
            set(p, 0x20 + i, on)
            set(p, 0x28 + i, on)
        }
        val u = if (d.fxUnit) 0x7F else 0
        set(p, 0x23, u)
        set(p, 0x2B, u)
    }
}
