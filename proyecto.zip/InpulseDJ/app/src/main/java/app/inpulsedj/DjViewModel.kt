package app.inpulsedj

import android.app.Application
import android.content.ContentUris
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.inpulsedj.audio.AudioOutput
import app.inpulsedj.audio.DjEngine
import app.inpulsedj.audio.Track
import app.inpulsedj.audio.TrackDecoder
import app.inpulsedj.midi.ActionSink
import app.inpulsedj.midi.Binding
import app.inpulsedj.midi.LedFeedback
import app.inpulsedj.midi.MappingEngine
import app.inpulsedj.midi.UsbMidi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

class DjViewModel(app: Application) : AndroidViewModel(app), ActionSink {
    private val ctx = app.applicationContext
    val settings = Settings(ctx)

    val engine: DjEngine
    private val audio: AudioOutput
    val mapping = MappingEngine(ctx)
    val usb: UsbMidi
    private val leds: LedFeedback

    val ui = MutableStateFlow(DjUi())
    val library = MutableStateFlow<List<LibTrack>>(emptyList())
    val selected = MutableStateFlow(0)
    val libraryVisible = MutableStateFlow(false)
    val midiLog = MutableStateFlow<List<String>>(emptyList())
    val learnStatus = MutableStateFlow("")
    val message = MutableStateFlow("")

    private val titles = arrayOf("", "")
    private val artists = arrayOf("", "")
    private val loading = floatArrayOf(-1f, -1f)
    private val loadedUri = arrayOf<Uri?>(null, null)
    private val tracks = arrayOfNulls<Track>(2)
    private val rollBeats = doubleArrayOf(1.0, 2.0, 4.0, 8.0)

    private val autoMix = MutableStateFlow(false)
    private var autoMixJobBusy = false

    init {
        val am = ctx.getSystemService(AudioManager::class.java)
        val sr = am?.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        val fpb = max(64, am?.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256)
        val block = fpb * ((256 + fpb - 1) / fpb)
        engine = DjEngine(sr, block)
        audio = AudioOutput(engine, block)
        applySettings()
        audio.start()

        mapping.load()
        mapping.onRaw = { s, d1, d2 ->
            val line = "%02X %02X %02X".format(s, d1, d2)
            midiLog.value = (listOf(line) + midiLog.value).take(14)
        }
        mapping.onLearned = { b ->
            learnStatus.value = "Asignado: ${b.label} <- %02X %02X".format(b.status, b.data1)
        }
        usb = UsbMidi(
            ctx, mapping.nameHints,
            onMessage = { s, a, b -> mapping.onMessage(s, a, b, this) },
            onConnected = { onControllerConnected() }
        )
        leds = LedFeedback(usb)
        usb.start()

        viewModelScope.launch(Dispatchers.Default) {
            var tick = 0
            while (isActive) {
                val s = snapshot()
                ui.value = s
                leds.update(s, (tick / 8) % 2 == 0)
                tick++
                runAutoMix(s)
                delay(33)
            }
        }
        refreshLibrary()
    }

    fun applySettings() {
        engine.cueSplit = settings.cueSplit
        engine.cueVolume = settings.cueVolume
        for (d in engine.decks) d.jogSensitivity = settings.jogSens.toDouble()
    }

    private fun onControllerConnected() {
        leds.reset()
        // Mensajes de arranque del script oficial: pide a la Inpulse que envie la posicion de todos
        // los faders y perillas para que la app quede sincronizada con el hardware.
        for (m in mapping.initMessages) usb.send(m)
        usb.send3(0x91, 0x03, 0x7F)
        usb.send3(0x92, 0x03, 0x7F)
        usb.send3(0x90, 0x04, 0x05)
    }

    // --------------------------------------------------------------- estado

    private fun deckUi(i: Int): DeckUi {
        val d = engine.decks[i]
        val t = tracks[i]
        val sr = t?.sampleRate ?: 44100
        val posSec = d.pos / sr
        return DeckUi(
            loaded = t != null,
            title = titles[i],
            artist = artists[i],
            posSec = posSec,
            durSec = t?.durationSec ?: 0.0,
            playing = d.playing,
            baseBpm = d.bpm,
            effBpm = d.bpm * d.tempo,
            tempoPct = (d.tempo - 1.0) * 100.0,
            tempo = d.tempo,
            sync = d.sync,
            leader = d.leader,
            pfl = d.pfl,
            vinyl = d.vinyl,
            cuePoint = d.cuePoint / sr,
            cuePreview = d.cuePreview,
            hotcues = d.hotcues.map { if (it < 0) -1.0 else it / sr },
            loopStart = if (d.loopStart < 0) -1.0 else d.loopStart / sr,
            loopEnd = if (d.loopEnd < 0) -1.0 else d.loopEnd / sr,
            loopActive = d.loopActive,
            rollIdx = d.rollIdx,
            fxUnit = d.fxUnitOn,
            fx = d.fxSlotOn.toList(),
            level = d.level,
            volume = d.volume,
            gain = d.gain,
            eqLow = d.eq.low,
            eqMid = d.eq.mid,
            eqHigh = d.eq.high,
            filter = d.filter.value,
            loading = loading[i],
            peaks = t?.peaks,
            anchorSec = d.anchorSec,
            platterDeg = ((posSec * 200.0) % 360.0).toFloat()
        )
    }

    private fun snapshot() = DjUi(
        a = deckUi(0), b = deckUi(1),
        crossfader = engine.crossfader,
        master = engine.master,
        masterLevel = engine.masterLevel,
        samplerMask = engine.sampler.playingMask(),
        autoMix = autoMix.value
    )

    // --------------------------------------------------------------- biblioteca

    fun refreshLibrary() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = ArrayList<LibTrack>()
            try {
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
                )
                val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
                val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                ctx.contentResolver.query(base, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")
                    ?.use { c ->
                        while (c.moveToNext()) {
                            list.add(
                                LibTrack(
                                    ContentUris.withAppendedId(base, c.getLong(0)),
                                    c.getString(1) ?: "Sin titulo",
                                    c.getString(2)?.takeIf { it != "<unknown>" } ?: "",
                                    c.getLong(3)
                                )
                            )
                        }
                    }
            } catch (_: SecurityException) {
            }
            val extra = library.value.filter { it.uri.authority != "media" }
            library.value = list + extra
        }
    }

    fun addFiles(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val add = ArrayList<LibTrack>()
            for (u in uris) {
                var title = u.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Archivo"
                var artist = ""
                var dur = 0L
                try {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(ctx, u)
                    r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.let { title = it }
                    r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.let { artist = it }
                    dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    r.release()
                } catch (_: Exception) {
                }
                add.add(LibTrack(u, title, artist, dur))
            }
            library.value = library.value + add
        }
    }

    fun loadTrack(deck: Int, t: LibTrack) {
        if (loading[deck] >= 0f) return
        loading[deck] = 0f
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val tr = TrackDecoder.decode(ctx, t.uri, t.uri.toString(), t.title, t.artist) { loading[deck] = it }
                tracks[deck] = tr
                titles[deck] = t.title
                artists[deck] = t.artist
                loadedUri[deck] = t.uri
                engine.post { engine.decks[deck].cmdLoad(tr) }
                message.value = if (tr.bpm > 0) "Deck ${"AB"[deck]}: ${t.title} (${"%.1f".format(tr.bpm)} BPM)"
                else "Deck ${"AB"[deck]}: ${t.title} (BPM no detectado: ajustalo a mano)"
            } catch (e: Exception) {
                message.value = "No se pudo cargar: ${e.message}"
            } finally {
                loading[deck] = -1f
            }
        }
    }

    fun loadSelected(deck: Int) {
        val l = library.value
        val i = selected.value
        if (i in l.indices) loadTrack(deck, l[i])
    }

    // --------------------------------------------------------------- acciones (MIDI + tactil)

    private fun dk(deck: Int) = engine.decks[deck.coerceIn(0, 1)]

    override fun button(action: String, deck: Int, idx: Int, pressed: Boolean) {
        if (deck in 0..1) deckButton(action, deck, idx, pressed) else globalButton(action, pressed)
    }

    private fun globalButton(action: String, pressed: Boolean) {
        if (!pressed) return
        when (action) {
            "browseClick", "browseClickShift" -> libraryVisible.value = !libraryVisible.value
            "autoMix" -> autoMix.value = !autoMix.value
        }
    }

    private fun deckButton(action: String, deck: Int, idx: Int, pressed: Boolean) {
        val d = dk(deck)
        when (action) {
            "play" -> if (pressed) engine.post { d.cmdTogglePlay() }
            "cue" -> engine.post { if (pressed) d.cmdCuePress() else d.cmdCueRelease() }
            "sync" -> if (pressed) engine.setSync(deck, !d.sync)
            "syncLeader" -> if (pressed) engine.setLeader(deck)
            "pfl" -> if (pressed) d.pfl = !d.pfl
            "vinyl" -> if (pressed) d.vinyl = !d.vinyl
            "load" -> if (pressed) loadSelected(deck)
            "jogTouch" -> engine.post { d.cmdJogTouch(pressed, false) }
            "jogTouchShift" -> engine.post { d.cmdJogTouch(pressed, true) }
            "loopIn" -> if (pressed) engine.post { d.cmdLoopIn() }
            "loopOut" -> if (pressed) engine.post { d.cmdReloop() }
            "loopHalve" -> if (pressed) engine.post { d.cmdLoopHalve() }
            "loopDouble" -> if (pressed) engine.post { d.cmdLoopDouble() }
            "playStutter" -> if (pressed) engine.post { d.cmdPlayStutter() }
            "startPlay" -> if (pressed) engine.post { d.cmdStartPlay() }
            "hotcue" -> engine.post { if (pressed) d.cmdHotcuePress(idx - 1) else d.cmdHotcueRelease(idx - 1) }
            "hotcueClear" -> if (pressed) engine.post { d.cmdHotcueClear(idx - 1) }
            "roll" -> engine.post {
                if (pressed) d.cmdRollPress(idx, rollBeats[(idx - 1).coerceIn(0, 3)]) else d.cmdRollRelease(idx)
            }
            "fxSlot" -> if (pressed && idx in 1..3) d.fxSlotOn[idx - 1] = !d.fxSlotOn[idx - 1]
            "fxUnit" -> if (pressed) d.fxUnitOn = !d.fxUnitOn
            "sampler" -> if (pressed) engine.post { engine.sampler.trigger(deck * 4 + idx - 1) }
        }
    }

    override fun knob(action: String, deck: Int, value: Float) {
        val v = value.coerceIn(0f, 1f)
        if (action == "crossfader") {
            engine.crossfader = v
            return
        }
        if (deck !in 0..1) return
        val d = dk(deck)
        when (action) {
            "volume" -> d.volume = v
            "gain" -> d.gain = v
            "eqLow" -> d.eq.low = v
            "eqHigh" -> d.eq.high = v
            "eqMid" -> d.eq.mid = v
            "filter" -> d.filter.value = v
            "pitch" -> setPitchFromFader(deck, v)
        }
    }

    fun pitchFaderValue(tempo: Double): Float {
        val range = settings.pitchRange / 100.0
        var x = ((tempo - 1.0) / (2.0 * range) + 0.5).toFloat().coerceIn(0f, 1f)
        if (settings.invertPitch) x = 1f - x
        return x
    }

    /** Fader de pitch del hardware o de pantalla (0..1, 0.5 = 0%). */
    fun setPitchFromFader(deck: Int, v: Float) {
        val d = dk(deck)
        var x = if (abs(v - 0.5f) < 0.004f) 0.5f else v
        if (settings.invertPitch) x = 1f - x
        val range = settings.pitchRange / 100.0
        // Si es seguidor de sync, mover el pitch rompe el sync (como en Mixxx)
        val o = engine.decks[1 - deck]
        val isLeader = d.leader || (o.sync && deck == 0 && !o.leader)
        if (d.sync && !isLeader) engine.setSync(deck, false)
        d.tempo = 1.0 + (x - 0.5) * 2.0 * range
    }

    override fun rel(action: String, deck: Int, ticks: Int) {
        when (action) {
            "jogScratch", "jogBend", "jogScratchShift" -> if (deck in 0..1) dk(deck).addJog(ticks)
            "browseTurn" -> moveSelection(ticks)
            "browseTurnShift" -> moveSelection(ticks * 8)
        }
    }

    private fun moveSelection(n: Int) {
        val size = library.value.size
        if (size == 0) return
        selected.value = (selected.value + n).coerceIn(0, size - 1)
    }

    // --------------------------------------------------------------- UI helpers

    fun setMaster(v: Float) { engine.master = v }
    fun setBpm(deck: Int, bpm: Double) { val d = dk(deck); engine.post { d.cmdSetBpm(bpm) } }
    fun setBeatHere(deck: Int) { val d = dk(deck); engine.post { d.cmdSetAnchorHere() } }
    fun seekFraction(deck: Int, f: Double) {
        val t = tracks[deck] ?: return
        val d = dk(deck)
        engine.post { d.cmdSeekFrames(f * t.frames) }
    }

    fun startLearn(b: Binding) {
        mapping.learnTarget = b
        learnStatus.value = "Mueve o pulsa el control para: ${b.label}"
    }

    fun resetMappings() {
        mapping.resetUser()
        learnStatus.value = "Mapeo restablecido al de fabrica"
    }

    fun toggleAutoMix() { autoMix.value = !autoMix.value }

    // --------------------------------------------------------------- Auto-mix (boton Assistant)

    private fun runAutoMix(s: DjUi) {
        if (!autoMix.value || autoMixJobBusy) return
        val lib = library.value
        if (lib.isEmpty()) return
        val fade = 10.0
        val cur = when {
            s.a.playing && !s.b.playing -> 0
            s.b.playing && !s.a.playing -> 1
            else -> -1
        }
        if (cur < 0) return
        val c = if (cur == 0) s.a else s.b
        val other = 1 - cur
        val o = if (cur == 0) s.b else s.a
        if (c.durSec - c.posSec > fade + 1.0) return
        autoMixJobBusy = true
        viewModelScope.launch(Dispatchers.Default) {
            try {
                if (!o.loaded || o.posSec > 1.0) {
                    val idx = lib.indexOfFirst { it.uri == loadedUri[cur] }
                    val next = lib[(if (idx < 0) 0 else idx + 1) % lib.size]
                    loadTrack(other, next)
                    var guard = 0
                    while (loading[other] >= 0f && guard < 600) { delay(100); guard++ }
                }
                val od = dk(other)
                val cd = dk(cur)
                engine.setSync(other, true)
                engine.post { od.cmdTogglePlay() }
                val from = engine.crossfader
                val to = if (other == 1) 1f else 0f
                val steps = (fade * 20).toInt()
                for (k in 1..steps) {
                    engine.crossfader = from + (to - from) * k / steps
                    delay(50)
                }
                engine.post { if (cd.playing) cd.cmdTogglePlay() }
                engine.setSync(other, false)
            } finally {
                autoMixJobBusy = false
            }
        }
    }

    override fun onCleared() {
        for (m in mapping.shutdownMessages) usb.send(m)
        usb.stop()
        audio.stop()
        super.onCleared()
    }
}
