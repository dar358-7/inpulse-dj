package app.inpulsedj.midi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Una asignacion MIDI -> accion. */
data class Binding(
    val kind: String,      // note | cc | rel | cc14msb | cc14lsb
    val status: Int,       // p.ej. 0x91
    val data1: Int,        // nota o numero de CC
    val action: String,
    val deck: Int,         // -1 = global, 0 = A, 1 = B
    val idx: Int,
    val note: String
) {
    val key: Int get() = (status shl 8) or data1
    val actionKey: String get() = "$action|$deck|$idx"
    val label: String
        get() = (if (deck == 0) "Deck A" else if (deck == 1) "Deck B" else "Global") + " - " + note
}

/** Receptor de las acciones resueltas (lo implementa el ViewModel). */
interface ActionSink {
    fun button(action: String, deck: Int, idx: Int, pressed: Boolean)
    fun knob(action: String, deck: Int, value: Float)
    fun rel(action: String, deck: Int, ticks: Int)
}

/**
 * Motor de mapeo: carga el JSON del controlador (assets/mappings/inpulse200.json),
 * aplica las asignaciones del usuario (MIDI Learn) y despacha los mensajes entrantes.
 */
class MappingEngine(private val ctx: Context) {
    private val byKey = HashMap<Int, Binding>()
    val defaults = ArrayList<Binding>()
    val nameHints = ArrayList<String>()
    val initMessages = ArrayList<ByteArray>()
    val shutdownMessages = ArrayList<ByteArray>()
    var deviceName = ""
        private set

    private val msb = IntArray(2)
    private val lsb = IntArray(2)

    @Volatile var learnTarget: Binding? = null
    var onLearned: ((Binding) -> Unit)? = null
    var onRaw: ((status: Int, d1: Int, d2: Int) -> Unit)? = null

    private val userFile: File get() = File(ctx.filesDir, "user_bindings.json")

    fun load() {
        defaults.clear()
        byKey.clear()
        nameHints.clear()
        initMessages.clear()
        shutdownMessages.clear()
        val txt = ctx.assets.open("mappings/inpulse200.json").bufferedReader().use { it.readText() }
        val root = JSONObject(txt)
        deviceName = root.optString("device")
        root.optJSONArray("nameHints")?.let { for (i in 0 until it.length()) nameHints.add(it.getString(i)) }
        root.optJSONArray("init")?.let { for (i in 0 until it.length()) initMessages.add(hex(it.getString(i))) }
        root.optJSONArray("shutdown")?.let { for (i in 0 until it.length()) shutdownMessages.add(hex(it.getString(i))) }
        defaults.addAll(parseBindings(root.getJSONArray("bindings")))
        for (b in defaults) byKey[b.key] = b
        if (userFile.exists()) {
            try {
                val arr = JSONArray(userFile.readText())
                for (b in parseBindings(arr)) applyUser(b)
            } catch (_: Exception) {
            }
        }
    }

    private fun hex(s: String): ByteArray =
        s.trim().split(" ").filter { it.isNotEmpty() }.map { it.toInt(16).toByte() }.toByteArray()

    private fun parseBindings(arr: JSONArray): List<Binding> {
        val out = ArrayList<Binding>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val d = o.optString("deck", "")
            out.add(
                Binding(
                    kind = o.getString("kind"),
                    status = Integer.decode(o.getString("status")),
                    data1 = Integer.decode(o.getString("data1")),
                    action = o.getString("action"),
                    deck = when (d) { "A" -> 0; "B" -> 1; else -> -1 },
                    idx = o.optInt("idx", 0),
                    note = o.optString("note", "")
                )
            )
        }
        return out
    }

    private fun applyUser(b: Binding) {
        // una accion = un control: se elimina lo anterior asignado a esa accion
        val it = byKey.entries.iterator()
        while (it.hasNext()) if (it.next().value.actionKey == b.actionKey) it.remove()
        byKey[b.key] = b
    }

    private fun saveUser(list: List<Binding>) {
        val arr = JSONArray()
        for (b in list) {
            arr.put(
                JSONObject()
                    .put("kind", b.kind)
                    .put("status", "0x%02X".format(b.status))
                    .put("data1", "0x%02X".format(b.data1))
                    .put("action", b.action)
                    .put("deck", when (b.deck) { 0 -> "A"; 1 -> "B"; else -> "" })
                    .put("idx", b.idx)
                    .put("note", b.note)
            )
        }
        userFile.writeText(arr.toString())
    }

    fun resetUser() {
        userFile.delete()
        load()
    }

    fun userBindings(): List<Binding> =
        if (userFile.exists()) {
            try { parseBindings(JSONArray(userFile.readText())) } catch (_: Exception) { emptyList() }
        } else emptyList()

    /** Controles que se pueden reasignar (uno por accion). Los pares de 14 bits se ofrecen como CC de 7 bits. */
    fun learnables(): List<Binding> {
        val seen = HashSet<String>()
        val out = ArrayList<Binding>()
        for (b in defaults) {
            if (b.kind == "cc14lsb") continue
            if (b.action.endsWith("Shift") || b.action == "hotcueClear") continue
            if (seen.add(b.actionKey)) out.add(b)
        }
        return out
    }

    // ------------------------------------------------------------------ entrada

    fun onMessage(statusIn: Int, d1: Int, d2In: Int, sink: ActionSink) {
        var status = statusIn
        var d2 = d2In
        val hi = status and 0xF0
        if (hi == 0x80) { // note off -> note on con velocidad 0
            status = 0x90 or (status and 0x0F)
            d2 = 0
        }
        onRaw?.invoke(status, d1, d2)

        val target = learnTarget
        if (target != null) {
            val isNote = (status and 0xF0) == 0x90
            val isCc = (status and 0xF0) == 0xB0
            val pressOrMove = if (target.kind == "note") (isNote && d2 > 0) else isCc
            if (pressOrMove) {
                val kind = when {
                    (status and 0xF0) == 0x90 -> "note"
                    target.kind == "rel" -> "rel"
                    else -> "cc"
                }
                val nb = Binding(kind, status, d1, target.action, target.deck, target.idx, target.note)
                applyUser(nb)
                val list = userBindings().filter { it.actionKey != nb.actionKey } + nb
                saveUser(list)
                learnTarget = null
                onLearned?.invoke(nb)
            }
            return
        }

        val b = byKey[(status shl 8) or d1] ?: return
        when (b.kind) {
            "note" -> sink.button(b.action, b.deck, b.idx, d2 > 0)
            "cc" -> sink.knob(b.action, b.deck, d2 / 127f)
            "rel" -> sink.rel(b.action, b.deck, if (d2 < 0x40) d2 else d2 - 128)
            "cc14msb" -> {
                val i = b.deck.coerceIn(0, 1)
                msb[i] = d2
                sink.knob(b.action, b.deck, ((msb[i] shl 7) or lsb[i]) / 16383f)
            }
            "cc14lsb" -> {
                val i = b.deck.coerceIn(0, 1)
                lsb[i] = d2
                sink.knob(b.action, b.deck, ((msb[i] shl 7) or lsb[i]) / 16383f)
            }
        }
    }
}
