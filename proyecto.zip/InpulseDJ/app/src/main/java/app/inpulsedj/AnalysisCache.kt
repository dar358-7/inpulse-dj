package app.inpulsedj

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Cache en disco de BPM y tonalidad por pista, para no volver a analizarlas. */
class AnalysisCache(ctx: Context) {
    class Entry(val bpm: Double, val key: String)

    private val file = File(ctx.filesDir, "analysis_cache.json")
    private val map = HashMap<String, Entry>()

    init {
        try {
            if (file.exists()) {
                val o = JSONObject(file.readText())
                for (k in o.keys()) {
                    val e = o.getJSONObject(k)
                    map[k] = Entry(e.optDouble("b", 0.0), e.optString("k", ""))
                }
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized fun get(uri: String): Entry? = map[uri]

    @Synchronized fun put(uri: String, bpm: Double, key: String) {
        map[uri] = Entry(bpm, key)
    }

    @Synchronized fun save() {
        try {
            val o = JSONObject()
            for ((k, v) in map) o.put(k, JSONObject().put("b", v.bpm).put("k", v.key))
            file.writeText(o.toString())
        } catch (_: Exception) {
        }
    }
}
