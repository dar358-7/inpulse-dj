package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import app.inpulsedj.DeckUi
import app.inpulsedj.audio.PEAKS_PER_SEC
import kotlin.math.ceil
import kotlin.math.floor

/** Onda desplazable (ventana de 8 s) con rejilla de tiempos, hot cues, loop y cabezal central. */
@Composable
fun WaveStrip(d: DeckUi, color: Color, modifier: Modifier) {
    Canvas(modifier.background(Color(0xFF07090D))) {
        val w = size.width
        val h = size.height
        val peaks = d.peaks
        val window = 8.0
        val pxPerSec = (w / window).toFloat()
        val center = w / 2f
        val t0 = d.posSec - center / pxPerSec
        val t1 = d.posSec + (w - center) / pxPerSec

        // loop
        if (d.loopStart >= 0 && d.loopEnd > d.loopStart) {
            val x0 = (center + (d.loopStart - d.posSec) * pxPerSec).toFloat()
            val x1 = (center + (d.loopEnd - d.posSec) * pxPerSec).toFloat()
            drawRect(
                Pal.ok.copy(alpha = if (d.loopActive) 0.30f else 0.10f),
                Offset(x0.coerceIn(0f, w), 0f),
                Size((x1.coerceIn(0f, w) - x0.coerceIn(0f, w)).coerceAtLeast(0f), h)
            )
        }

        if (peaks != null) {
            var x = 0f
            while (x < w) {
                val t = d.posSec + (x - center) / pxPerSec
                val idx = floor(t * PEAKS_PER_SEC).toInt()
                if (idx >= 0 && idx < peaks.size) {
                    val a = (peaks[idx] * 0.95f).coerceIn(0.02f, 1f)
                    val col = if (x < center) color.copy(alpha = 0.45f) else color
                    drawLine(col, Offset(x, h / 2 - a * h / 2), Offset(x, h / 2 + a * h / 2), strokeWidth = 2f)
                }
                x += 2f
            }
        }

        // rejilla
        if (d.baseBpm > 0) {
            val beat = 60.0 / d.baseBpm
            var k = ceil((t0 - d.anchorSec) / beat).toLong()
            while (true) {
                val t = d.anchorSec + k * beat
                if (t > t1) break
                val x = (center + (t - d.posSec) * pxPerSec).toFloat()
                val strong = Math.floorMod(k, 4L) == 0L
                drawLine(
                    Color.White.copy(alpha = if (strong) 0.45f else 0.18f),
                    Offset(x, if (strong) 0f else h * 0.7f), Offset(x, h), strokeWidth = 1.5f
                )
                k++
            }
        }

        // hot cues y cue
        for (i in 0..3) {
            val hc = d.hotcues[i]
            if (hc >= 0 && hc in t0..t1) {
                val x = (center + (hc - d.posSec) * pxPerSec).toFloat()
                drawLine(Pal.hot[i], Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
                drawRect(Pal.hot[i], Offset(x, 0f), Size(10f, 10f))
            }
        }
        if (d.cuePoint in t0..t1) {
            val x = (center + (d.cuePoint - d.posSec) * pxPerSec).toFloat()
            drawLine(Pal.warn, Offset(x, h - 12f), Offset(x, h), strokeWidth = 3f)
        }

        // cabezal
        drawLine(Color.White, Offset(center, 0f), Offset(center, h), strokeWidth = 2f)
    }
}
