package app.inpulsedj.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DeckUi
import app.inpulsedj.DjViewModel

fun fmtTime(sec: Double): String {
    val s = sec.coerceAtLeast(0.0).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun DeckPanel(
    d: DeckUi, deck: Int, samplerMask: Int, vm: DjViewModel, color: Color, modifier: Modifier
) {
    var mode by rememberSaveable("pad$deck") { mutableIntStateOf(0) }
    var clearMode by rememberSaveable("clr$deck") { mutableStateOf(false) }
    var showRemaining by rememberSaveable("rem$deck") { mutableStateOf(true) }
    val letter = if (deck == 0) "A" else "B"

    Column(
        modifier.clip(RoundedCornerShape(10.dp)).background(Pal.panel).padding(5.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // ---- info
        Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(letter, color = color, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Column(Modifier.weight(1f).clickable { showRemaining = !showRemaining }.padding(horizontal = 6.dp)) {
                Text(
                    when {
                        d.loading >= 0f -> "Cargando ${(d.loading * 100).toInt()}%..."
                        d.loaded -> d.title
                        else -> "Sin pista - abre la biblioteca"
                    },
                    color = Pal.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (d.loaded) "${d.artist}  ${fmtTime(d.posSec)} / -${fmtTime(d.durSec - d.posSec)}" else "",
                    color = Pal.dim, fontSize = 9.sp, maxLines = 1
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    if (d.effBpm > 0) "%.1f".format(d.effBpm) else "--",
                    color = Pal.text, fontSize = 16.sp, fontWeight = FontWeight.Bold
                )
                Text("%+.1f%%".format(d.tempoPct), color = Pal.dim, fontSize = 9.sp)
            }
        }

        // ---- plato + transporte
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Column(
                Modifier.width(30.dp).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("PITCH", color = Pal.dim, fontSize = 8.sp)
                Fader(
                    value = vm.pitchFaderValue(d.tempo),
                    onChange = { vm.setPitchFromFader(deck, it) },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    vertical = true, color = color, centerMark = true
                )
            }
            Platter(
                angleDeg = d.platterDeg, color = color,
                centerText = if (!d.loaded) "--:--" else if (showRemaining) "-" + fmtTime(d.durSec - d.posSec) else fmtTime(d.posSec),
                subText = if (d.vinyl) "VINYL" else "",
                onTouch = { vm.button("jogTouch", deck, 0, it) },
                onTicks = { vm.rel("jogScratch", deck, it) },
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            Column(Modifier.width(62.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                PressButton(
                    "CUE", Modifier.fillMaxWidth().weight(1f), active = d.cuePreview, color = Pal.warn,
                    onPress = { vm.button("cue", deck, 0, true) },
                    onRelease = { vm.button("cue", deck, 0, false) }
                )
                PressButton(
                    if (d.playing) "II" else "PLAY", Modifier.fillMaxWidth().weight(1.3f),
                    active = d.playing, color = color,
                    onPress = { vm.button("play", deck, 0, true) }
                )
                PressButton(
                    "SYNC", Modifier.fillMaxWidth().weight(1f), active = d.sync, color = Pal.ok,
                    onPress = { vm.button("sync", deck, 0, true) }
                )
                Row(Modifier.fillMaxWidth().height(22.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    PressButton("-", Modifier.weight(1f).fillMaxHeight(),
                        onPress = { vm.setBpm(deck, (d.baseBpm - 0.1).coerceAtLeast(40.0)) })
                    PressButton("+", Modifier.weight(1f).fillMaxHeight(),
                        onPress = { vm.setBpm(deck, d.baseBpm + 0.1) })
                    PressButton("|", Modifier.weight(1f).fillMaxHeight(), color = Pal.warn,
                        onPress = { vm.setBeatHere(deck) })
                }
            }
        }

        // ---- pestanas de pads
        Row(Modifier.fillMaxWidth().height(20.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            val tabs = listOf("HOT CUE", "ROLL", "FX", "SAMPLER")
            for (i in tabs.indices) {
                PressButton(tabs[i], Modifier.weight(1f).fillMaxHeight(), active = mode == i, color = color,
                    onPress = { mode = i })
            }
        }
        Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            when (mode) {
                0 -> {
                    for (i in 0..3) {
                        PressButton(
                            if (d.hotcues[i] >= 0) fmtTime(d.hotcues[i]) else "${i + 1}",
                            Modifier.weight(1f).fillMaxHeight(), active = d.hotcues[i] >= 0, color = Pal.hot[i],
                            onPress = { vm.button(if (clearMode) "hotcueClear" else "hotcue", deck, i + 1, true) },
                            onRelease = { if (!clearMode) vm.button("hotcue", deck, i + 1, false) }
                        )
                    }
                    PressButton("DEL", Modifier.width(34.dp).fillMaxHeight(), active = clearMode, color = Pal.red,
                        onPress = { clearMode = !clearMode })
                }
                1 -> {
                    val beats = listOf("1", "2", "4", "8")
                    for (i in 0..3) {
                        PressButton(
                            beats[i], Modifier.weight(1f).fillMaxHeight(), active = d.rollIdx == i + 1, color = color,
                            onPress = { vm.button("roll", deck, i + 1, true) },
                            onRelease = { vm.button("roll", deck, i + 1, false) }
                        )
                    }
                }
                2 -> {
                    val names = listOf("ECHO", "FLANGER", "REVERB")
                    for (i in 0..2) {
                        PressButton(names[i], Modifier.weight(1f).fillMaxHeight(), active = d.fx[i], color = color,
                            onPress = { vm.button("fxSlot", deck, i + 1, true) })
                    }
                    PressButton("FX ON", Modifier.weight(1f).fillMaxHeight(), active = d.fxUnit, color = Pal.ok,
                        onPress = { vm.button("fxUnit", deck, 0, true) })
                }
                else -> {
                    val names = vm.engine.sampler.names
                    for (i in 0..3) {
                        val n = deck * 4 + i
                        PressButton(names[n], Modifier.weight(1f).fillMaxHeight(),
                            active = (samplerMask shr n) and 1 == 1, color = color,
                            onPress = { vm.button("sampler", deck, i + 1, true) })
                    }
                }
            }
        }

        // ---- loops y utilidades
        Row(Modifier.fillMaxWidth().height(28.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            PressButton("LOOP", Modifier.weight(1.2f).fillMaxHeight(), active = d.loopActive, color = Pal.ok,
                onPress = { vm.button("loopIn", deck, 0, true) })
            PressButton("RELOOP", Modifier.weight(1.4f).fillMaxHeight(),
                onPress = { vm.button("loopOut", deck, 0, true) })
            PressButton("1/2", Modifier.weight(1f).fillMaxHeight(),
                onPress = { vm.button("loopHalve", deck, 0, true) })
            PressButton("x2", Modifier.weight(1f).fillMaxHeight(),
                onPress = { vm.button("loopDouble", deck, 0, true) })
            PressButton("PFL", Modifier.weight(1f).fillMaxHeight(), active = d.pfl, color = Pal.warn,
                onPress = { vm.button("pfl", deck, 0, true) })
            PressButton("VINYL", Modifier.weight(1.3f).fillMaxHeight(), active = d.vinyl, color = color,
                onPress = { vm.button("vinyl", deck, 0, true) })
            PressButton("CARGAR", Modifier.weight(1.5f).fillMaxHeight(), color = color,
                onPress = { vm.button("load", deck, 0, true) })
        }
    }
}
