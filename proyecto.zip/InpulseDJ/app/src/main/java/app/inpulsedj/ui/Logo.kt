package app.inpulsedj.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.R

/** Texto con efecto 3D: capas de extrusion (violeta -> azul oscuro) bajo una cara clara con brillo. */
@Composable
fun Text3D(text: String, fontSize: TextUnit, modifier: Modifier = Modifier, depth: Int = 6) {
    val step = fontSize.value / 22f
    Box(modifier) {
        for (i in depth downTo 1) {
            val t = i / depth.toFloat()
            Text(
                text, color = lerp(Color(0xFF7C5CFF), Color(0xFF140C3C), t),
                fontSize = fontSize, fontWeight = FontWeight.Black,
                modifier = Modifier.offset(x = (i * step).dp, y = (i * step).dp)
            )
        }
        Text(
            text, color = Color(0xFFF4F8FF), fontSize = fontSize, fontWeight = FontWeight.Black,
            style = TextStyle(shadow = Shadow(Color(0xAA27D3FF), Offset(0f, 0f), fontSize.value * 0.9f))
        )
    }
}

@Composable
fun LogoMark(size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.logo_mark), contentDescription = "Darvis",
        modifier = modifier.size(size)
    )
}

/** Pantalla de bienvenida con el logotipo y el nombre en 3D. */
@Composable
fun SplashOverlay() {
    Box(Modifier.fillMaxSize().background(Color(0xFF171E31)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.logo_darvis), contentDescription = "Darvis Live DJ App",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxHeight(0.62f)
            )
            Text3D("INPULSE DJ", 30.sp, depth = 8)
            Text3D("BY DARVI'S", 18.sp, depth = 6, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
