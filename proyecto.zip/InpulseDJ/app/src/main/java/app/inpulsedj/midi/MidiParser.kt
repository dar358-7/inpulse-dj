package app.inpulsedj.midi

/** Convierte un flujo de bytes MIDI (con running status) en mensajes de canal (status, d1, d2). */
class MidiParser(private val onMessage: (status: Int, d1: Int, d2: Int) -> Unit) {
    private var status = 0
    private val data = IntArray(2)
    private var n = 0
    private var need = 0
    private var inSysex = false

    fun feed(buf: ByteArray, offset: Int, count: Int) {
        for (i in offset until offset + count) {
            val v = buf[i].toInt() and 0xFF
            if (v >= 0xF8) continue // mensajes de tiempo real
            if (v >= 0x80) {
                when {
                    v == 0xF0 -> { inSysex = true; status = 0 }
                    v == 0xF7 -> { inSysex = false; status = 0 }
                    v >= 0xF0 -> status = 0
                    else -> {
                        inSysex = false
                        status = v
                        n = 0
                        val hi = v and 0xF0
                        need = if (hi == 0xC0 || hi == 0xD0) 1 else 2
                    }
                }
            } else {
                if (inSysex || status == 0) continue
                data[n++] = v
                if (n == need) {
                    onMessage(status, data[0], if (need == 2) data[1] else 0)
                    n = 0
                }
            }
        }
    }
}
