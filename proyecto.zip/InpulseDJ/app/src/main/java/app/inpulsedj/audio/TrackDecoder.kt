package app.inpulsedj.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.max

/** Decodifica cualquier audio soportado por Android (mp3, aac, flac, wav, ogg...) a PCM en memoria. */
object TrackDecoder {
    private const val MAX_SECONDS = 600 // 10 min por pista (~106 MB a 44.1 kHz)

    class Analysis(val bpm: Double, val key: String)

    /** Analisis rapido para la biblioteca: solo los primeros ~110 s, sin onda. */
    fun analyze(ctx: Context, uri: Uri): Analysis {
        val t = decode(ctx, uri, uri.toString(), "", "", { }, maxSeconds = 110, analysisOnly = true)
        return Analysis(t.bpm, t.key)
    }

    fun decode(
        ctx: Context, uri: Uri, id: String, title: String, artist: String,
        onProgress: (Float) -> Unit, maxSeconds: Int = MAX_SECONDS, analysisOnly: Boolean = false
    ): Track {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var ti = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                ti = i
                fmt = f
                break
            }
        }
        if (ti < 0 || fmt == null) {
            ex.release()
            throw IllegalStateException("El archivo no contiene audio")
        }
        ex.selectTrack(ti)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        val maxFrames = maxSeconds * sr
        val estFrames = if (durUs > 0) (durUs / 1e6 * sr).toInt() else 180 * sr
        var pcm = ShortArray(minOf(estFrames, maxFrames) * 2 + 8192)

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        var frames = 0
        try {
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        val size = ex.readSampleData(ib, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val nShorts = sb.remaining()
                        val c = max(1, ch)
                        val nFr = nShorts / c
                        if ((frames + nFr) * 2 > pcm.size) {
                            pcm = pcm.copyOf(max(pcm.size / 4 * 5, (frames + nFr) * 2 + 8192))
                        }
                        val tmp = ShortArray(nShorts)
                        sb.get(tmp)
                        for (f in 0 until nFr) {
                            val l = tmp[f * c]
                            val r = if (c > 1) tmp[f * c + 1] else l
                            pcm[(frames + f) * 2] = l
                            pcm[(frames + f) * 2 + 1] = r
                        }
                        frames += nFr
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                    if (frames >= maxFrames) outDone = true
                    if (durUs > 0) onProgress((frames.toDouble() / (durUs / 1e6 * sr)).toFloat().coerceIn(0f, 1f))
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            ex.release()
        }
        if (frames < sr) throw IllegalStateException("No se pudo decodificar el archivo")
        val out = if (pcm.size == frames * 2) pcm else pcm.copyOf(frames * 2)
        val res = BpmDetector.analyze(out, frames, sr)
        val key = try { KeyDetector.analyze(out, frames, sr) ?: "" } catch (_: Exception) { "" }
        if (analysisOnly) {
            return Track(id, title, artist, sr, frames, out, FloatArray(0), res?.bpm ?: 0.0, res?.anchorSec ?: 0.0, key = key)
        }
        val peaks = Track.buildPeaks(out, frames, sr)
        val bands = Track.buildBands(out, frames, sr)
        return Track(id, title, artist, sr, frames, out, peaks, res?.bpm ?: 0.0, res?.anchorSec ?: 0.0, bands, key)
    }
}
