package app.inpulsedj.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DjViewModel

@Composable
fun LibrarySheet(
    vm: DjViewModel, onRescan: () -> Unit, onPickFiles: () -> Unit, onClose: () -> Unit, modifier: Modifier
) {
    val lib by vm.library.collectAsState()
    val sel by vm.selected.collectAsState()
    var query by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val shown = remember(lib, query) {
        lib.withIndex().filter {
            query.isBlank() || it.value.title.contains(query, true) || it.value.artist.contains(query, true)
        }.toList()
    }
    LaunchedEffect(sel, shown) {
        val pos = shown.indexOfFirst { it.index == sel }
        if (pos >= 0) listState.animateScrollToItem(pos)
    }
    Column(
        modifier.clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)).background(Pal.panel).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("BIBLIOTECA (${lib.size})", color = Pal.text, fontSize = 13.sp)
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Buscar...", fontSize = 11.sp) },
                modifier = Modifier.weight(1f).height(48.dp)
            )
            PressButton("ESCANEAR", Modifier.width(78.dp).height(34.dp), onPress = onRescan)
            PressButton("ARCHIVOS...", Modifier.width(88.dp).height(34.dp), onPress = onPickFiles)
            PressButton("CERRAR", Modifier.width(66.dp).height(34.dp), color = Pal.red, onPress = onClose)
        }
        if (lib.isEmpty()) {
            Text(
                "No hay musica. Concede el permiso de audio y pulsa ESCANEAR, o usa ARCHIVOS... para elegir pistas.",
                color = Pal.dim, fontSize = 11.sp
            )
        }
        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            itemsIndexed(shown, key = { _, item -> item.value.uri.toString() }) { _, row ->
                val t = row.value
                Row(
                    Modifier.fillMaxWidth().height(38.dp)
                        .background(if (row.index == sel) Pal.panel2 else Pal.panel)
                        .clickable { vm.selected.value = row.index }
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(t.title, color = Pal.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, color = Pal.dim, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(fmtTime(t.durationMs / 1000.0), color = Pal.dim, fontSize = 10.sp)
                    PressButton("A", Modifier.width(36.dp).height(28.dp), color = Pal.deckA,
                        onPress = { vm.selected.value = row.index; vm.loadTrack(0, t) })
                    PressButton("B", Modifier.width(36.dp).height(28.dp), color = Pal.deckB,
                        onPress = { vm.selected.value = row.index; vm.loadTrack(1, t) })
                }
            }
        }
    }
}
