package app.inpulsedj.audio

import kotlin.math.abs
import kotlin.math.max

const val PEAKS_PER_SEC = 100

/** Pista decodificada: PCM 16-bit estereo intercalado en memoria. */
class Track(
    val id: String,
    val title: String,
    val artist: String,
    val sampleRate: Int,
    val frames: Int,
    val pcm: ShortArray,
    val peaks: FloatArray,
    val bpm: Double,
    val anchorSec: Double,
    val bands: FloatArray = FloatArray(0),   // 3 valores por pico: graves, medios, agudos
    val key: String = ""                    // codigo Camelot, p.ej. "8A"
) {
    val durationSec: Double get() = frames.toDouble() / sampleRate

    companion object {
        /** Energia por banda (graves < 200 Hz, medios < 2.5 kHz, agudos) para colorear la onda. */
        fun buildBands(pcm: ShortArray, frames: Int, sr: Int): FloatArray {
            val per = max(1, sr / PEAKS_PER_SEC)
            val n = frames / per + 1
            val out = FloatArray(n * 3)
            val a1 = (1.0 - Math.exp(-2.0 * Math.PI * 200.0 / sr)).toFloat()
            val a2 = (1.0 - Math.exp(-2.0 * Math.PI * 2500.0 / sr)).toFloat()
            var lp1 = 0f
            var lp2 = 0f
            var idx = 0
            for (p in 0 until n) {
                var lo = 0f
                var mi = 0f
                var hi = 0f
                var k = 0
                while (k < per && idx < frames) {
                    val m = (pcm[idx * 2] + pcm[idx * 2 + 1]) * (0.5f / 32768f)
                    lp1 += a1 * (m - lp1)
                    lp2 += a2 * (m - lp2)
                    val l = abs(lp1)
                    val md = abs(lp2 - lp1)
                    val h = abs(m - lp2)
                    if (l > lo) lo = l
                    if (md > mi) mi = md
                    if (h > hi) hi = h
                    idx++
                    k++
                }
                out[p * 3] = lo
                out[p * 3 + 1] = mi
                out[p * 3 + 2] = hi
            }
            return out
        }

        fun buildPeaks(pcm: ShortArray, frames: Int, sr: Int): FloatArray {
            val per = max(1, sr / PEAKS_PER_SEC)
            val n = frames / per + 1
            val out = FloatArray(n)
            var idx = 0
            for (p in 0 until n) {
                var m = 0
                var k = 0
                while (k < per && idx < frames) {
                    val l = abs(pcm[idx * 2].toInt())
                    val r = abs(pcm[idx * 2 + 1].toInt())
                    val v = if (l > r) l else r
                    if (v > m) m = v
                    idx++
                    k++
                }
                out[p] = m / 32768f
            }
            return out
        }
    }
}
