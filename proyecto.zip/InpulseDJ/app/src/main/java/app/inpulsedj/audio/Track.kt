package app.inpulsedj.audio

import kotlin.math.abs
import kotlin.math.max

const val PEAKS_PER_SEC = 100

/** Pista decodificada: PCM 16-bit estereo intercalado en memoria. */
class Track(
    val id: String,
    val title: String,
    val artist: String,
    val sampleRate: Int,
    val frames: Int,
    val pcm: ShortArray,
    val peaks: FloatArray,
    val bpm: Double,
    val anchorSec: Double
) {
    val durationSec: Double get() = frames.toDouble() / sampleRate

    companion object {
        fun buildPeaks(pcm: ShortArray, frames: Int, sr: Int): FloatArray {
            val per = max(1, sr / PEAKS_PER_SEC)
            val n = frames / per + 1
            val out = FloatArray(n)
            var idx = 0
            for (p in 0 until n) {
                var m = 0
                var k = 0
                while (k < per && idx < frames) {
                    val l = abs(pcm[idx * 2].toInt())
                    val r = abs(pcm[idx * 2 + 1].toInt())
                    val v = if (l > r) l else r
                    if (v > m) m = v
                    idx++
                    k++
                }
                out[p] = m / 32768f
            }
            return out
        }
    }
}
