package app.inpulsedj.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow

/** Dispositivo MIDI visible para el usuario. */
data class MidiDev(val info: MidiDeviceInfo, val name: String, val usb: Boolean)

/**
 * Conexion MIDI por USB usando android.media.midi (la Inpulse 200 es class-compliant,
 * Android la expone como dispositivo MIDI sin drivers ni permisos USB).
 */
class UsbMidi(
    ctx: Context,
    private val hints: List<String>,
    private val onMessage: (status: Int, d1: Int, d2: Int) -> Unit,
    private val onConnected: () -> Unit
) {
    private val mm: MidiManager? = ctx.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private val main = Handler(Looper.getMainLooper())

    val devices = MutableStateFlow<List<MidiDev>>(emptyList())
    val status = MutableStateFlow("MIDI: sin conexion")
    val connectedName = MutableStateFlow<String?>(null)

    private var device: MidiDevice? = null
    private var outPort: MidiOutputPort? = null
    private var inPort: MidiInputPort? = null
    private var currentId = -1
    private var userDisconnected = false

    private val parser = MidiParser { s, a, b -> onMessage(s, a, b) }
    private val receiver = object : MidiReceiver() {
        override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
            parser.feed(data, offset, count)
        }
    }

    private val callback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            refresh()
            if (device == null && !userDisconnected) autoConnect()
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (info.id == currentId) closeCurrent("MIDI: controlador desconectado")
            refresh()
        }
    }

    fun start() {
        val m = mm
        if (m == null) {
            status.value = "Este dispositivo no soporta MIDI"
            return
        }
        m.registerDeviceCallback(callback, main)
        refresh()
        autoConnect()
    }

    fun stop() {
        mm?.unregisterDeviceCallback(callback)
        closeCurrent("MIDI: sin conexion")
    }

    private fun nameOf(info: MidiDeviceInfo): String {
        val p = info.properties
        val n = p.getString(MidiDeviceInfo.PROPERTY_NAME)
        if (!n.isNullOrBlank()) return n
        val prod = p.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
        return if (!prod.isNullOrBlank()) prod else "Dispositivo MIDI ${info.id}"
    }

    fun refresh() {
        val m = mm ?: return
        devices.value = m.devices
            .filter { it.outputPortCount > 0 || it.inputPortCount > 0 }
            .map { MidiDev(it, nameOf(it), it.type == MidiDeviceInfo.TYPE_USB) }
    }

    private fun autoConnect() {
        val list = devices.value
        val match = list.firstOrNull { d -> hints.any { d.name.lowercase().contains(it) } }
            ?: list.firstOrNull { it.usb && it.info.outputPortCount > 0 }
        if (match != null) connect(match)
    }

    fun connect(dev: MidiDev) {
        val m = mm ?: return
        userDisconnected = false
        closeCurrent(null)
        status.value = "MIDI: conectando a ${dev.name}..."
        m.openDevice(dev.info, MidiManager.OnDeviceOpenedListener { d ->
            if (d == null) {
                status.value = "MIDI: no se pudo abrir ${dev.name}"
                return@OnDeviceOpenedListener
            }
            device = d
            currentId = dev.info.id
            if (dev.info.outputPortCount > 0) {
                outPort = d.openOutputPort(0)
                outPort?.connect(receiver)
            }
            if (dev.info.inputPortCount > 0) {
                inPort = d.openInputPort(0)
            }
            connectedName.value = dev.name
            status.value = "MIDI: ${dev.name}"
            onConnected()
        }, main)
    }

    fun disconnect() {
        userDisconnected = true
        closeCurrent("MIDI: sin conexion")
    }

    private fun closeCurrent(msg: String?) {
        try { outPort?.disconnect(receiver) } catch (_: Exception) {}
        try { outPort?.close() } catch (_: Exception) {}
        try { inPort?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        outPort = null
        inPort = null
        device = null
        currentId = -1
        connectedName.value = null
        if (msg != null) status.value = msg
    }

    val isConnected: Boolean get() = device != null

    /** Envia bytes crudos al controlador (LEDs, init...). */
    fun send(bytes: ByteArray) {
        val p = inPort ?: return
        try {
            p.send(bytes, 0, bytes.size)
        } catch (_: Exception) {
        }
    }

    fun send3(status: Int, d1: Int, d2: Int) {
        send(byteArrayOf(status.toByte(), d1.toByte(), d2.toByte()))
    }
}
