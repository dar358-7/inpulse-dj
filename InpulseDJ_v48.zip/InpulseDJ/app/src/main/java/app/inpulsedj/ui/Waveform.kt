package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import app.inpulsedj.DeckUi
import app.inpulsedj.audio.PEAKS_PER_SEC
import kotlin.math.ceil
import kotlin.math.floor

/** Onda desplazable (ventana de 8 s) con rejilla de tiempos, hot cues, loop y cabezal central. */
@Composable
fun WaveStrip(d: DeckUi, color: Color, modifier: Modifier, window: Double = 6.0, onTap: () -> Unit = {}) {
    val peakMax = remember(d.peaks) {
        var m = 0.05f
        d.peaks?.let { for (v in it) if (v > m) m = v }
        m
    }
    val tap by rememberUpdatedState(onTap)
    val barsLeft = if (d.loaded && d.effBpm > 0) ((d.durSec - d.posSec) / (240.0 / d.effBpm)).coerceAtLeast(0.0) else -1.0
    androidx.compose.foundation.layout.Box(modifier.background(Color(0xFF080D14))) {
    Canvas(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { tap() } }) {
        val w = size.width
        val h = size.height
        val peaks = d.peaks
        // la ventana va en tiempo REAL: con tempo distinto cada onda se estira igual y los golpes casan al empatar
        val pxPerSec = (w / window / d.tempo.coerceIn(0.5, 2.0)).toFloat()
        val center = w / 2f
        val t0 = d.posSec - center / pxPerSec
        val t1 = d.posSec + (w - center) / pxPerSec

        // loop
        if (d.loopStart >= 0 && d.loopEnd > d.loopStart) {
            val x0 = (center + (d.loopStart - d.posSec) * pxPerSec).toFloat()
            val x1 = (center + (d.loopEnd - d.posSec) * pxPerSec).toFloat()
            drawRect(
                Pal.ok.copy(alpha = if (d.loopActive) 0.30f else 0.10f),
                Offset(x0.coerceIn(0f, w), 0f),
                Size((x1.coerceIn(0f, w) - x0.coerceIn(0f, w)).coerceAtLeast(0f), h)
            )
        }

        if (peaks != null) {
            val fallback = Color(0xFF1EA0F0)
            val cy = h / 2
            var x = 0f
            while (x < w) {
                val t = d.posSec + (x - center) / pxPerSec
                val idx = floor(t * PEAKS_PER_SEC).toInt()
                if (idx >= 1 && idx < peaks.size - 1) {
                    val played = x < center
                    // envolvente suavizada (promedio de vecinos)
                    val pk = (peaks[idx - 1] * 0.25f + peaks[idx] * 0.5f + peaks[idx + 1] * 0.25f) / peakMax
                    val a = Math.pow(pk.coerceIn(0f, 1f).toDouble(), 1.1).toFloat().coerceAtLeast(0.02f) * 0.95f
                    // degradado del color del deck hacia violeta (cian a la izquierda, violeta a la derecha)
                    val mix = (x / w) * (if (color == Pal.deckA) 1f else 0.25f)
                    val col = androidx.compose.ui.graphics.lerp(color, Pal.deckB, mix)
                    val al = if (played) 0.55f else 1f
                    // capa exterior suave + nucleo mas claro y estrecho: onda densa con volumen
                    drawLine(col.copy(alpha = al * 0.55f), Offset(x, cy - a * cy), Offset(x, cy + a * cy), strokeWidth = 2f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    val ca = a * 0.62f
                    drawLine(androidx.compose.ui.graphics.lerp(col, Color.White, 0.45f).copy(alpha = al), Offset(x, cy - ca * cy), Offset(x, cy + ca * cy), strokeWidth = 1.2f)
                }
                x += 1.5f
            }
        }

        // rejilla: cada pulso = linea cian con triangulos grises arriba y abajo; cada compas = triangulos rojos grandes
        if (d.baseBpm > 0) {
            val beat = 60.0 / d.baseBpm
            var k = ceil((t0 - d.anchorSec) / beat).toLong()
            val line = Color(0xFF46C8FF)
            val red = Color(0xFFFF2D3F)
            val grey = Color(0xFFC8CDD8)
            while (true) {
                val t = d.anchorSec + k * beat
                if (t > t1) break
                if (t < 0.0 || (d.durSec > 0.0 && t > d.durSec)) { k++; continue }
                val x = (center + (t - d.posSec) * pxPerSec).toFloat()
                val strong = Math.floorMod(k, 4L) == 0L
                drawLine(line.copy(alpha = if (strong) 0.95f else 0.75f), Offset(x, 0f), Offset(x, h), strokeWidth = if (strong) 3f else 2f)
                val tri = if (strong) 7f else 5f
                val up = androidx.compose.ui.graphics.Path().apply {
                    moveTo(x - tri, 0f); lineTo(x + tri, 0f); lineTo(x, tri * 1.5f); close()
                }
                val dn = androidx.compose.ui.graphics.Path().apply {
                    moveTo(x - tri, h); lineTo(x + tri, h); lineTo(x, h - tri * 1.5f); close()
                }
                drawPath(up, if (strong) red else grey)
                drawPath(dn, if (strong) red else grey)
                k++
            }
        }

        // hot cues y cue
        for (i in 0..3) {
            val hc = d.hotcues[i]
            if (hc >= 0 && hc in t0..t1) {
                val x = (center + (hc - d.posSec) * pxPerSec).toFloat()
                drawLine(Pal.hot[i], Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
                drawRect(Pal.hot[i], Offset(x, 0f), Size(10f, 10f))
            }
        }
        if (d.cuePoint in t0..t1) {
            val x = (center + (d.cuePoint - d.posSec) * pxPerSec).toFloat()
            drawLine(Pal.warn, Offset(x, h - 12f), Offset(x, h), strokeWidth = 3f)
        }

        // cabezal
        drawLine(Color.White.copy(alpha = 0.22f), Offset(center, 0f), Offset(center, h), strokeWidth = 8f)
        drawLine(Color.White, Offset(center, 0f), Offset(center, h), strokeWidth = 2.5f)
    }
    if (barsLeft >= 0) {
        val bars = barsLeft.toInt()
        val beats = ((barsLeft - bars) * 4).toInt()
        androidx.compose.material3.Text(
            "$bars.${beats + 1} Bars", color = Color.White.copy(alpha = 0.92f), fontSize = 12.sp,
            style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black, Offset(1f, 1f), 3f)),
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd).padding(end = 4.dp, top = 6.dp)
                .background(Color.Black.copy(alpha = 0.6f), androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                .padding(horizontal = 5.dp, vertical = 1.dp)
        )
    }
    }
}

/**
 * Color "RGB" por pico: graves -> rojo, medios -> verde/cian, agudos -> azul. Cada banda se normaliza con su
 * propio percentil para que los colores salgan vivos en cualquier musica. Se calcula una vez por pista.
 * soft = paleta apagada con grano, como la onda vertical estilo djay.
 */
internal fun buildWaveColors(bd: FloatArray?, n: Int, soft: Boolean = false): IntArray? {
    if (bd == null || bd.size < 6 || n <= 0) return null
    val cnt = minOf(n, bd.size / 3)
    val sc = FloatArray(3)
    val tmp = FloatArray(cnt / 2 + 1)
    for (b in 0..2) {
        var m = 0
        var i = 0
        while (i < cnt && m < tmp.size) { tmp[m++] = bd[i * 3 + b]; i += 2 }
        java.util.Arrays.sort(tmp, 0, m)
        sc[b] = maxOf(1e-4f, tmp[(m * 0.985f).toInt().coerceIn(0, m - 1)])
    }
    val expo = if (soft) 2.2 else 4.5
    val out = IntArray(cnt)
    for (i in 0 until cnt) {
        val lo = minOf(1f, bd[i * 3] / sc[0])
        val mi = minOf(1f, bd[i * 3 + 1] / sc[1])
        val hi = minOf(1f, bd[i * 3 + 2] / sc[2])
        val mx = maxOf(1e-6f, maxOf(lo, maxOf(mi, hi)))
        val f0 = Math.pow((lo / mx).toDouble(), expo).toFloat()
        val f1 = Math.pow((mi / mx).toDouble(), expo).toFloat()
        val f2 = Math.pow((hi / mx).toDouble(), expo).toFloat()
        var r: Float
        var g: Float
        var b: Float
        if (soft) {
            // estilo djay: graves = rojo vivo, medios = lila, agudos = verde azulado; la cola suave tira a azul profundo
            val sum = maxOf(1e-6f, f0 + f1 + f2)
            val w0 = f0 / sum
            val w1 = f1 / sum
            val w2 = f2 / sum
            val tail = (1f - minOf(1f, mx)) * (1f - w0)          // poca energia y sin graves -> azul
            r = w0 * 1.00f + w1 * 0.70f + w2 * 0.16f
            g = w0 * 0.10f + w1 * 0.48f + w2 * 0.84f
            b = w0 * 0.14f + w1 * 0.92f + w2 * 0.74f
            r = r * (1f - 0.7f * tail) + 0.10f * 0.7f * tail
            g = g * (1f - 0.7f * tail) + 0.35f * 0.7f * tail
            b = b * (1f - 0.7f * tail) + 1.00f * 0.7f * tail
        } else {
            r = f0 * 1.00f + f1 * 0.15f + f2 * 0.10f
            g = f0 * 0.20f + f1 * 0.80f + f2 * 0.40f
            b = f0 * 0.10f + f1 * 0.50f + f2 * 1.00f
        }
        val mn = minOf(r, minOf(g, b))
        val sub = if (soft) 0.0f else 0.55f
        r -= sub * mn; g -= sub * mn; b -= sub * mn
        val top = maxOf(1e-6f, maxOf(r, maxOf(g, b)))
        var br = if (soft) 0.86f + 0.14f * Math.sqrt(minOf(1f, mx).toDouble()).toFloat()
        else 0.55f + 0.45f * Math.sqrt(minOf(1f, mx).toDouble()).toFloat()
        if (soft) {
            // grano: pequena variacion de brillo fila a fila
            val hsh = ((i * 7919 + 13) * 31337) and 0xFF
            br *= 0.80f + 0.20f * (hsh / 255f)
        }
        val ri = (255f * minOf(1f, r / top * br)).toInt()
        val gi = (255f * minOf(1f, g / top * br)).toInt()
        val bi = (255f * minOf(1f, b / top * br)).toInt()
        out[i] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
    }
    return out
}
