package app.inpulsedj.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import kotlin.math.max

/** Hilo de audio: pide bloques al DjEngine y los escribe en un AudioTrack float de baja latencia. */
class AudioOutput(private val ctx: android.content.Context, private val engine: DjEngine, private val block: Int) {
    /** Descripcion de la salida activa, para mostrarla en Ajustes. */
    @Volatile var description = "Salida estereo"

    /** true si la pre-escucha sale por los auriculares del controlador (USB) */
    @Volatile var cueOnUsb = false
    private var commSet = false

    /** El controlador puede declarar sus 4 canales de varias formas (cuentas, mascaras posicionales o por indice) o solo por su nombre. */
    private fun supportsQuad(d: android.media.AudioDeviceInfo): Boolean {
        if (d.channelCounts.any { it >= 4 }) return true
        if (d.channelMasks.any { Integer.bitCount(it) >= 4 }) return true
        if (d.channelIndexMasks.any { Integer.bitCount(it) >= 4 }) return true
        val n = d.productName?.toString()?.lowercase() ?: ""
        return n.contains("inpulse") || n.contains("hercules")
    }

    private fun findMultiChannelUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            val usb = d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE ||
                d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
            if (usb && supportsQuad(d)) return d
        }
        return null
    }

    private fun findBluetooth(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET) ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_SPEAKER)
            ) return d
        }
        return null
    }

    private fun findAnyUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET) return d
        }
        return null
    }

    private fun buildTrack(sr: Int, quad: Boolean, dev: android.media.AudioDeviceInfo?, lowLatency: Boolean = true, extraBlocks: Int = 3, indexMask: Boolean = false, usage: Int = AudioAttributes.USAGE_MEDIA): AudioTrack {
        val mask = if (quad) AudioFormat.CHANNEL_OUT_QUAD else AudioFormat.CHANNEL_OUT_STEREO
        val ch = if (quad) 4 else 2
        val minBuf = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_FLOAT)
        val bufBytes = max(minBuf, block * ch * 4 * extraBlocks)
        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .also { if (indexMask && Build.VERSION.SDK_INT >= 23) it.setChannelIndexMask((1 shl ch) - 1) else it.setChannelMask(mask) }
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
        if (Build.VERSION.SDK_INT >= 26) {
            builder.setPerformanceMode(if (lowLatency) AudioTrack.PERFORMANCE_MODE_LOW_LATENCY else AudioTrack.PERFORMANCE_MODE_NONE)
        }
        val t = builder.build()
        if (dev != null && Build.VERSION.SDK_INT >= 23) t.setPreferredDevice(dev)
        return t
    }

    @Volatile private var running = false
    private var thread: Thread? = null

    private var devCb: android.media.AudioDeviceCallback? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var startedAt = 0L
    private val restartTask = Runnable {
        if (running) {
            stopThread()
            startThread()
        }
    }

    @Volatile private var gen = 0
    private fun alive(g: Int) = running && gen == g

    private fun startThread() {
        running = true
        val g = ++gen
        val t = Thread({ loop(g) }, "dj-audio")
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    private fun stopThread() {
        running = false
        thread?.join(1200)
        thread = null
    }

    fun start() {
        if (running) return
        startedAt = System.currentTimeMillis()
        startThread()
        // si se conecta o desconecta Bluetooth / USB, se vuelve a elegir la salida
        if (Build.VERSION.SDK_INT >= 23 && devCb == null) {
            val am = ctx.getSystemService(android.media.AudioManager::class.java)
            val cb = object : android.media.AudioDeviceCallback() {
                private fun changed() {
                    if (System.currentTimeMillis() - startedAt < 2500) return
                    main.removeCallbacks(restartTask)
                    main.postDelayed(restartTask, 900)
                }
                override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
                override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
            }
            devCb = cb
            am?.registerAudioDeviceCallback(cb, main)
        }
    }

    fun stop() {
        main.removeCallbacks(restartTask)
        if (Build.VERSION.SDK_INT >= 23) {
            devCb?.let { ctx.getSystemService(android.media.AudioManager::class.java)?.unregisterAudioDeviceCallback(it) }
        }
        devCb = null
        stopThread()
    }

    /** Copia del master hacia el altavoz Bluetooth en su propio hilo: nunca bloquea el audio principal (USB). */
    private inner class BtMirror(sr: Int, dev: android.media.AudioDeviceInfo, private val g: Int) {
        private val track: AudioTrack = buildTrack(sr, false, dev, lowLatency = false, extraBlocks = 10)
        private val free = java.util.concurrent.ArrayBlockingQueue<FloatArray>(12)
        private val filled = java.util.concurrent.ArrayBlockingQueue<FloatArray>(12)
        private val th: Thread

        init {
            repeat(12) { free.offer(FloatArray(block * 2)) }
            th = Thread({
                var playing = false
                var count = 0
                while (alive(g)) {
                    val b = try { filled.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { null } ?: continue
                    val w = track.write(b, 0, b.size, AudioTrack.WRITE_BLOCKING)
                    free.offer(b)
                    if (w < 0) break
                    count++
                    if (!playing && count >= 3) {
                        try { track.play(); playing = true } catch (_: Exception) { break }
                    }
                }
            }, "dj-bt")
            th.start()
        }

        /** Se llama justo despues de mezclar un bloque. */
        fun push(src: FloatArray? = null) {
            val b = free.poll() ?: return
            if (src != null) System.arraycopy(src, 0, b, 0, block * 2) else engine.copyMaster(b, block)
            if (!filled.offer(b)) free.offer(b)
        }

        fun close() {
            try { th.join(500) } catch (_: InterruptedException) {}
            try { track.stop() } catch (_: IllegalStateException) {}
            track.release()
        }
    }

    /** Escribe silencio unos bloques y mira si Android esta sacando el audio por el dispositivo USB pedido. */
    private fun routedToUsb(t: AudioTrack, dev: android.media.AudioDeviceInfo, ch: Int): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        val z = FloatArray(block * ch)
        repeat(8) { if (t.write(z, 0, z.size, AudioTrack.WRITE_BLOCKING) < 0) return false }
        try { Thread.sleep(200) } catch (_: InterruptedException) {}
        val r = t.routedDevice ?: return false
        return r.id == dev.id || r.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || r.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
    }

    /** Comprueba por donde sale realmente el audio; si Android lo desvio del USB, vuelve a pedir el USB. */
    private fun checkRoute(tk: AudioTrack, usb: android.media.AudioDeviceInfo?, usbUsed: Boolean, label: String) {
        try {
            val r = tk.routedDevice
            val name = r?.productName?.toString() ?: "?"
            val isUsb = r != null && (r.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || r.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET)
            if (usbUsed && usb != null && !isUsb) tk.setPreferredDevice(usb)
            description = "$label [sale por: $name]"
        } catch (_: Exception) {
        }
    }

    private fun clearComm() {
        if (commSet && Build.VERSION.SDK_INT >= 31) {
            try { ctx.getSystemService(android.media.AudioManager::class.java)?.clearCommunicationDevice() } catch (_: Exception) {}
        }
        commSet = false
    }

    private fun loop(g: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sr = engine.sampleRate
        val quadDev = findMultiChannelUsb()
        val usbDev = quadDev ?: findAnyUsb()
        val btDev = findBluetooth()
        var quad = false
        var usbUsed = false
        var track: AudioTrack? = null
        var label = "Salida estereo"
        // 1) tarjeta USB del controlador: master 1-2 y auriculares 3-4. Se prueban varias formas de abrirla y se
        //    comprueba que Android la mande de verdad al USB (con Bluetooth conectado puede desviarla).
        if (usbDev != null) {
            val tries = if (quadDev != null) listOf(Triple(4, false, "A"), Triple(4, true, "B"), Triple(2, false, "C")) else listOf(Triple(2, false, "C"))
            for ((ch, idx, tag) in tries) {
                val dev = if (ch == 4) quadDev!! else usbDev
                var t: AudioTrack? = null
                try {
                    t = buildTrack(sr, ch == 4, dev, indexMask = idx)
                    t.play()
                    if (routedToUsb(t, dev, ch)) {
                        track = t
                        quad = ch == 4
                        usbUsed = true
                        label = if (quad) "USB 4 canales: master 1-2, auriculares 3-4 ($tag)" else "USB estereo ($tag)"
                        break
                    }
                    t.release()
                } catch (_: Exception) {
                    try { t?.release() } catch (_: Exception) {}
                }
            }
            // ultimo recurso con Bluetooth conectado: canal de "comunicacion", que Android deja mandar al USB aparte
            if (track == null && btDev != null && Build.VERSION.SDK_INT >= 31) {
                var t: AudioTrack? = null
                try {
                    val am = ctx.getSystemService(android.media.AudioManager::class.java)
                    val cd = am?.availableCommunicationDevices?.firstOrNull {
                        it.id == usbDev.id || it.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || it.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
                    }
                    if (am != null && cd != null && am.setCommunicationDevice(cd)) {
                        commSet = true
                        t = buildTrack(sr, false, usbDev, usage = AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        t.play()
                        if (routedToUsb(t, usbDev, 2)) {
                            track = t
                            usbUsed = true
                            label = "USB estereo (D)"
                        } else {
                            t.release()
                            clearComm()
                        }
                    }
                } catch (_: Exception) {
                    try { t?.release() } catch (_: Exception) {}
                    clearComm()
                }
            }
            if (track == null) {
                // no se pudo confirmar la ruta: se usa la primera opcion tal cual, como antes
                try {
                    val q = quadDev != null
                    val t = buildTrack(sr, q, quadDev ?: usbDev)
                    t.play()
                    track = t
                    quad = q
                    usbUsed = true
                    label = (if (q) "USB 4 canales: master 1-2, auriculares 3-4" else "USB estereo") + " (sin confirmar)"
                } catch (_: Exception) {
                    track = null
                }
            }
        }
        if (track == null) {
            track = buildTrack(sr, false, null)
            track.play()
        }
        // 2) Bluetooth: musica (master). Si el USB solo tiene 2 canales, el USB lleva la pre-escucha.
        var mirror: BtMirror? = null
        if (usbUsed && btDev != null) {
            try {
                mirror = BtMirror(sr, btDev, g)
            } catch (_: Exception) {
                mirror = null
            }
        }
        val stereoCue = mirror != null && !quad
        label = when {
            mirror == null -> label
            stereoCue -> "Bluetooth: musica | controlador USB: pre-escucha ($label)"
            else -> "$label + Bluetooth (copia del master)"
        }
        cueOnUsb = usbUsed && (quad || stereoCue)
        description = label
        val tk: AudioTrack = track!!
        val buf = FloatArray(block * (if (quad) 4 else 2))
        val mb = FloatArray(block * 2)
        val cb = FloatArray(block * 2)
        var n = 0
        while (alive(g)) {
            if (++n == 60 && Build.VERSION.SDK_INT >= 23) checkRoute(tk, usbDev, usbUsed, label)
            if (stereoCue) {
                engine.renderSplit(mb, cb, block)
                mirror!!.push(mb)
            } else {
                if (quad) engine.renderBlock4(buf, block) else engine.renderBlock(buf, block)
                mirror?.push()
            }
            val w = if (stereoCue) tk.write(cb, 0, cb.size, AudioTrack.WRITE_BLOCKING) else tk.write(buf, 0, buf.size, AudioTrack.WRITE_BLOCKING)
            if (w < 0) break
        }
        mirror?.close()
        cueOnUsb = false
        try {
            tk.stop()
        } catch (_: IllegalStateException) {
        }
        tk.release()
        clearComm()
    }
}
