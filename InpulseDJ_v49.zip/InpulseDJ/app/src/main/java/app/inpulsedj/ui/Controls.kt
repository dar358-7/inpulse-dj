package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

object Pal {
    /** true = skin modo dia (claro) */
    var day by androidx.compose.runtime.mutableStateOf(false)
    val bg get() = if (day) Color(0xFFE9EDF3) else Color(0xFF070B11)
    val panel get() = if (day) Color(0xFFF7F9FC) else Color(0xFF131B25)
    val panel2 get() = if (day) Color(0xFFDDE3EC) else Color(0xFF1E2A37)
    val track get() = if (day) Color(0xFFB9C2D0) else Color(0xFF2D3C4C)
    val text get() = if (day) Color(0xFF111827) else Color(0xFFE6EAF2)
    val dim get() = if (day) Color(0xFF5B6475) else Color(0xFF8B94A8)
    /** fondo de pocillos: faders, vumetros */
    val well get() = if (day) Color(0xFFCBD3DF) else Color(0xFF0B1118)
    val wellOff get() = if (day) Color(0xFFE3E8F0) else Color(0xFF1A202C)
    val deckA = Color(0xFF1F6BFF)
    val deckB = Color(0xFF9A3DFF)
    val ok = Color(0xFF19F0A0)
    val warn = Color(0xFFFFC21A)
    val gold = Color(0xFFE2BD6B)
    val red = Color(0xFFFF4D6D)
    val hot = listOf(Color(0xFFFF3D77), Color(0xFFFFD21A), Color(0xFF19F0A0), Color(0xFF3DB8FF))
}

/** Perilla rotativa: arrastre vertical, doble toque = valor por defecto. */
@Composable
fun Knob(
    value: Float, onChange: (Float) -> Unit, label: String, color: Color,
    size: Dp = 32.dp, center: Boolean = false, default: Float = 0.5f
) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(size)
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        cb((v - drag.y / 160f).coerceIn(0f, 1f))
                    }
                }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { cb(default) }) }
        ) {
            val stroke = this.size.minDimension * 0.13f
            val tl = Offset(stroke, stroke)
            val sz = Size(this.size.width - 2 * stroke, this.size.height - 2 * stroke)
            drawArc(Pal.track, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            // brillo neon suave detras del tramo activo
            drawArc(
                color.copy(alpha = 0.22f), if (center) 270f else 135f, if (center) 270f * (v - 0.5f) else 270f * v,
                false, tl, sz, style = Stroke(stroke * 2.2f, cap = StrokeCap.Round)
            )
            if (center) {
                drawArc(color, 270f, 270f * (v - 0.5f), false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            } else {
                drawArc(color, 135f, 270f * v, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            val ang = (135f + 270f * v) * PI.toFloat() / 180f
            val c = Offset(this.size.width / 2, this.size.height / 2)
            val r = this.size.minDimension / 2 - stroke
            drawCircle(
                androidx.compose.ui.graphics.Brush.radialGradient(
                    listOf(Pal.panel2, Pal.well), center = c, radius = r * 0.95f
                ), r * 0.92f, c
            )
            drawLine(
                Pal.text,
                Offset(c.x + cos(ang) * r * 0.3f, c.y + sin(ang) * r * 0.3f),
                Offset(c.x + cos(ang) * r * 0.9f, c.y + sin(ang) * r * 0.9f),
                strokeWidth = stroke * 0.7f, cap = StrokeCap.Round
            )
        }
        Text(label, color = Pal.dim, fontSize = 8.sp, lineHeight = 9.sp)
    }
}

/** Fader vertical u horizontal con arrastre absoluto. */
@Composable
fun Fader(
    value: Float, onChange: (Float) -> Unit, modifier: Modifier, vertical: Boolean,
    color: Color, centerMark: Boolean = false
) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o -> cb(posToValue(o, size.width.toFloat(), size.height.toFloat(), vertical)) }
                ) { change, _ ->
                    change.consume()
                    cb(posToValue(change.position, size.width.toFloat(), size.height.toFloat(), vertical))
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o -> cb(posToValue(o, size.width.toFloat(), size.height.toFloat(), vertical)) })
            }
    ) {
        val w = size.width
        val h = size.height
        if (vertical) {
            val cx = w / 2
            drawLine(Pal.track, Offset(cx, 6f), Offset(cx, h - 6f), strokeWidth = 5f, cap = StrokeCap.Round)
            if (centerMark) drawLine(Pal.dim, Offset(cx - 8f, h / 2), Offset(cx + 8f, h / 2), strokeWidth = 2f)
            val y = (h - 14f) * (1f - value) + 7f
            drawLine(color.copy(alpha = 0.18f), Offset(cx, h - 6f), Offset(cx, y), strokeWidth = 13f, cap = StrokeCap.Round)
            drawLine(color.copy(alpha = 0.55f), Offset(cx, h - 6f), Offset(cx, y), strokeWidth = 5f, cap = StrokeCap.Round)
            drawRoundRect(
                androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Pal.panel2, Pal.well), y - 8f, y + 8f),
                Offset(cx - w * 0.42f, y - 8f), Size(w * 0.84f, 16f), androidx.compose.ui.geometry.CornerRadius(3f)
            )
            drawRect(color, Offset(cx - w * 0.42f, y - 1.5f), Size(w * 0.84f, 3f))
        } else {
            val cy = h / 2
            drawLine(Pal.track, Offset(6f, cy), Offset(w - 6f, cy), strokeWidth = 5f, cap = StrokeCap.Round)
            if (centerMark) drawLine(Pal.dim, Offset(w / 2, cy - 8f), Offset(w / 2, cy + 8f), strokeWidth = 2f)
            val x = (w - 14f) * value + 7f
            drawRoundRect(
                androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Pal.panel2, Pal.well, Pal.panel2), x - 14f, x + 14f),
                Offset(x - 14f, cy - h * 0.42f), Size(28f, h * 0.84f), androidx.compose.ui.geometry.CornerRadius(5f)
            )
            drawRect(color, Offset(x - 1.5f, cy - h * 0.42f), Size(3f, h * 0.84f))
        }
    }
}

private fun posToValue(o: Offset, w: Float, h: Float, vertical: Boolean): Float =
    if (vertical) (1f - (o.y - 7f) / (h - 14f)).coerceIn(0f, 1f) else ((o.x - 7f) / (w - 14f)).coerceIn(0f, 1f)

/** Vúmetro vertical. */
@Composable
fun VuMeter(level: Float, modifier: Modifier) {
    // indicador de clipping: se enciende con nivel casi maximo y se mantiene ~0,7 s
    var clip by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val hit = level >= 0.97f
    androidx.compose.runtime.LaunchedEffect(hit) {
        if (hit) {
            clip = true
            kotlinx.coroutines.delay(700)
            clip = false
        }
    }
    Canvas(modifier.background(Pal.well)) {
        val segs = 14
        val gap = 2f
        val sh = (size.height - gap * (segs - 1)) / segs
        val lit = (level.coerceIn(0f, 1f) * segs).toInt()
        for (i in 0 until segs) {
            val y = size.height - (i + 1) * sh - i * gap
            val on = i < lit
            val c = when {
                i >= segs - 2 -> Pal.red
                i >= segs - 5 -> Pal.warn
                else -> Pal.ok
            }
            drawRect(if (on) c else Pal.wellOff, Offset(0f, y), Size(size.width, sh))
            if (clip && i >= segs - 1) drawRect(Pal.red, Offset(0f, y), Size(size.width, sh))
            if (on) drawRect(c.copy(alpha = 0.18f), Offset(-1f, y - 1f), Size(size.width + 2f, sh + 2f))
        }
    }
}

/** Boton con eventos de pulsar y soltar. Estados: normal, pulsado, activo, desactivado (enabled = false). */
@Composable
fun PressButton(
    text: String, modifier: Modifier = Modifier, active: Boolean = false, color: Color = Pal.deckA,
    onPress: () -> Unit, onRelease: () -> Unit = {}, enabled: Boolean = true, outline: Boolean = false, soft: Boolean = false
) {
    val p by rememberUpdatedState(onPress)
    val r by rememberUpdatedState(onRelease)
    val en by rememberUpdatedState(enabled)
    var down by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val glow by androidx.compose.animation.core.animateFloatAsState(
        if (down) 1f else 0f, androidx.compose.animation.core.tween(90), label = "btn"
    )
    val shape = RoundedCornerShape(9.dp)
    val tone = color
    val white = Color.White
    val lit = active || soft
    // volumen: degradado de 3 tonos (luz arriba, cuerpo, sombra abajo)
    val c1 = if (lit) androidx.compose.ui.graphics.lerp(tone, white, 0.28f) else androidx.compose.ui.graphics.lerp(Pal.panel2, white, 0.10f)
    val c2 = if (lit) tone else if (outline) Pal.panel else Pal.panel2
    val c3 = if (lit) androidx.compose.ui.graphics.lerp(tone, Color.Black, 0.38f) else if (outline) Pal.bg else androidx.compose.ui.graphics.lerp(Pal.panel, Color.Black, 0.25f)
    Box(
        modifier
            .alpha(if (enabled) 1f else 0.38f)
            .androidx_pressShift(down)
            .drawBehind {
                // sombra proyectada bajo el boton
                drawRoundRect(
                    Color.Black.copy(alpha = if (down) 0.25f else 0.55f), topLeft = Offset(0f, if (down) 1.5f else 4f), size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f)
                )
            }
            .clip(shape)
            .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(c1, c2, c3)))
            .drawBehind {
                if (active) drawRoundRect(
                    tone.copy(alpha = 0.35f), topLeft = Offset(-3f, -3f), size = Size(size.width + 6f, size.height + 6f), style = Stroke(6f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(20f)
                )
                // brillo de cristal en la mitad superior
                drawRoundRect(
                    androidx.compose.ui.graphics.Brush.verticalGradient(listOf(white.copy(alpha = if (lit) 0.34f else 0.16f), Color.Transparent), 0f, size.height * 0.55f),
                    size = Size(size.width, size.height * 0.55f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f)
                )
                // filo claro superior y labio oscuro inferior
                drawLine(white.copy(alpha = if (lit) 0.65f else 0.30f), Offset(size.height * 0.30f, 1.2f), Offset(size.width - size.height * 0.30f, 1.2f), strokeWidth = 1.6f)
                drawLine(Color.Black.copy(alpha = 0.40f), Offset(size.height * 0.30f, size.height - 1.5f), Offset(size.width - size.height * 0.30f, size.height - 1.5f), strokeWidth = 3f)
            }
            .background(Color.White.copy(alpha = 0.16f * glow))
            .border(
                if (outline) 1.5.dp else 1.dp,
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    if (lit) listOf(androidx.compose.ui.graphics.lerp(tone, white, 0.5f), tone)
                    else if (outline) listOf(color, color.copy(alpha = 0.55f))
                    else listOf(Color.White.copy(alpha = 0.28f), Pal.track.copy(alpha = 0.6f))
                ), shape
            )
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    if (!en) return@detectTapGestures
                    down = true
                    p()
                    tryAwaitRelease()
                    down = false
                    r()
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (lit) Color.White else if (outline) color else Pal.text,
            fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

/** Plato estilo djay: arco de progreso, aguja que gira, BPM arriba, tono a la izquierda, pitch a la derecha, tiempo y restante abajo. */
@Composable
fun Platter(
    angleDeg: Float, color: Color, progress: Float, bpmText: String, keyText: String, pitchText: String,
    elapsedText: String, remainText: String,
    onTouch: (Boolean) -> Unit, onTicks: (Int) -> Unit, modifier: Modifier
) {
    val touchCb by rememberUpdatedState(onTouch)
    val tickCb by rememberUpdatedState(onTicks)
    androidx.compose.foundation.layout.BoxWithConstraints(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                down.consume()
                touchCb(true)
                fun angleOf(o: Offset): Float =
                    Math.toDegrees(
                        atan2((o.y - size.height / 2f).toDouble(), (o.x - size.width / 2f).toDouble())
                    ).toFloat()
                var last = angleOf(down.position)
                var rem = 0f
                while (true) {
                    val ev = awaitPointerEvent()
                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!c.pressed) {
                        c.consume()
                        break
                    }
                    val a = angleOf(c.position)
                    var d = a - last
                    if (d > 180f) d -= 360f
                    if (d < -180f) d += 360f
                    last = a
                    rem += d / 360f * 248f
                    val t = rem.toInt()
                    if (t != 0) {
                        tickCb(t)
                        rem -= t
                    }
                    c.consume()
                }
                touchCb(false)
            }
        },
        contentAlignment = Alignment.Center
    ) {
        val m = minOf(maxWidth, maxHeight).value
        val ink = Color(0xFFF2F4F8)
        val metal = Color(0xFFB4B6BC)
        val nums = androidx.compose.ui.text.TextStyle(fontFeatureSettings = "tnum")
        Canvas(Modifier.matchParentSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = size.minDimension / 2
            // aro exterior gris con una muesca a la derecha, como los platos de los reproductores profesionales
            val ow = r * 0.15f
            val orad = r - ow / 2
            drawArc(metal, 10f, 340f, false, Offset(c.x - orad, c.y - orad), Size(orad * 2, orad * 2), style = Stroke(ow))
            drawCircle(Color.Black, r - ow, c)
            // anillo de color del deck: pista tenue + progreso de la pista
            val rr = r * 0.72f
            val tl = Offset(c.x - rr, c.y - rr)
            val sz = Size(rr * 2, rr * 2)
            val pr = progress.coerceIn(0f, 1f)
            drawArc(color.copy(alpha = 0.40f), 0f, 360f, false, tl, sz, style = Stroke(r * 0.05f))
            // el aro de color se va llenando con la reproduccion, con halo de neon y punta brillante
            drawArc(color.copy(alpha = 0.14f), -90f, 360f * pr, false, tl, sz, style = Stroke(r * 0.15f, cap = StrokeCap.Round))
            drawArc(color.copy(alpha = 0.30f), -90f, 360f * pr, false, tl, sz, style = Stroke(r * 0.095f, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * pr, false, tl, sz, style = Stroke(r * 0.05f, cap = StrokeCap.Round))
            if (pr > 0f) {
                val ang = Math.toRadians((-90f + 360f * pr).toDouble())
                val hp = Offset(c.x + rr * kotlin.math.cos(ang).toFloat(), c.y + rr * kotlin.math.sin(ang).toFloat())
                drawCircle(color.copy(alpha = 0.35f), r * 0.075f, hp)
                drawCircle(Color.White, r * 0.032f, hp)
            }
            drawCircle(Color.White.copy(alpha = 0.85f), r * 0.60f, c, style = Stroke(1.2f))
            // marcador rojo que gira con el plato
            rotate(angleDeg, c) {
                val q = r * 0.085f
                drawRect(Pal.red, Offset(c.x - q / 2, c.y - rr - q / 2), Size(q, q))
            }
        }
        androidx.compose.foundation.layout.Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val dot = bpmText.indexOf('.')
            androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    if (dot > 0) bpmText.substring(0, dot) else bpmText, color = ink, fontWeight = FontWeight.Bold,
                    fontSize = (m * 0.17f).sp, style = nums
                )
                if (dot > 0) Text(
                    bpmText.substring(dot), color = ink, fontWeight = FontWeight.Bold,
                    fontSize = (m * 0.09f).sp, style = nums, modifier = Modifier.padding(bottom = (m * 0.012f).dp)
                )
            }
            androidx.compose.foundation.layout.Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy((m * 0.04f).dp)) {
                Text(pitchText, color = ink, fontSize = (m * 0.06f).sp, style = nums)
                Text(keyText, color = Pal.red, fontSize = (m * 0.06f).sp, fontWeight = FontWeight.Bold)
            }
            Text(elapsedText, color = ink, fontWeight = FontWeight.Bold, fontSize = (m * 0.056f).sp, style = nums, modifier = Modifier.padding(top = (m * 0.02f).dp))
            Text(remainText, color = ink.copy(alpha = 0.65f), fontSize = (m * 0.05f).sp, style = nums)
        }
    }
}


/** Desplaza el boton hacia abajo mientras se pulsa (efecto de tecla real). */
private fun Modifier.androidx_pressShift(down: Boolean): Modifier =
    this.then(Modifier.graphicsLayer { translationY = if (down) 2.5f else 0f })
