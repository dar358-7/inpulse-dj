package app.inpulsedj.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.inpulsedj.DjViewModel
import app.inpulsedj.midi.Binding

@Composable
fun SettingsDialog(vm: DjViewModel, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.92f).fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(14.dp)).background(Pal.panel).padding(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("AJUSTES Y MIDI", color = Pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                PressButton("CERRAR", Modifier.width(80.dp).height(32.dp), color = Pal.red, onPress = onClose)
            }
            Row(
                Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MidiSection(vm)
                    LearnSection(vm)
                }
                Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AudioSection(vm)
                    MonitorSection(vm)
                }
            }
        }
    }
}

@Composable
private fun Title(t: String) = Text(t, color = Pal.deckA, fontSize = 12.sp)

@Composable
private fun MidiSection(vm: DjViewModel) {
    val devs by vm.usb.devices.collectAsState()
    val status by vm.usb.status.collectAsState()
    val connected by vm.usb.connectedName.collectAsState()
    Title("CONTROLADOR USB-MIDI")
    Text(status, color = if (connected != null) Pal.ok else Pal.warn, fontSize = 12.sp)
    Text(
        "Conecta la Inpulse 200 con un cable OTG/USB-C. Android la detecta como dispositivo MIDI sin drivers.",
        color = Pal.dim, fontSize = 10.sp
    )
    if (devs.isEmpty()) Text("No se ve ningun dispositivo MIDI.", color = Pal.dim, fontSize = 11.sp)
    for (d in devs) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(d.name + if (d.usb) " (USB)" else "", color = Pal.text, fontSize = 11.sp, modifier = Modifier.weight(1f))
            PressButton("CONECTAR", Modifier.width(84.dp).height(30.dp), onPress = { vm.usb.connect(d) })
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PressButton("ACTUALIZAR", Modifier.width(92.dp).height(30.dp), onPress = { vm.usb.refresh() })
        PressButton("DESCONECTAR", Modifier.width(100.dp).height(30.dp), color = Pal.red, onPress = { vm.usb.disconnect() })
    }
}

@Composable
private fun LearnSection(vm: DjViewModel) {
    val learnables = remember { vm.mapping.learnables() }
    var expanded by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Binding?>(null) }
    val st by vm.learnStatus.collectAsState()
    Title("MIDI LEARN (reasignar controles)")
    Text(
        "El mapeo de fabrica ya cubre toda la Inpulse 200. Aqui puedes cambiar cualquier control: " +
            "elige la funcion, pulsa APRENDER y mueve el control.",
        color = Pal.dim, fontSize = 10.sp
    )
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PressButton(sel?.label ?: "Elegir funcion...", Modifier.width(210.dp).height(32.dp), onPress = { expanded = true })
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            for (b in learnables) {
                DropdownMenuItem(
                    text = { Text(b.label, fontSize = 11.sp) },
                    onClick = { sel = b; expanded = false }
                )
            }
        }
        PressButton("APRENDER", Modifier.width(84.dp).height(32.dp), color = Pal.ok,
            onPress = { sel?.let { vm.startLearn(it) } })
    }
    if (st.isNotEmpty()) Text(st, color = Pal.warn, fontSize = 11.sp)
    PressButton("RESTABLECER MAPEO DE FABRICA", Modifier.width(230.dp).height(30.dp), color = Pal.red,
        onPress = { vm.resetMappings() })
}

@Composable
private fun AudioSection(vm: DjViewModel) {
    val s = vm.settings
    var range by remember { mutableFloatStateOf(s.pitchRange) }
    var invert by remember { mutableStateOf(s.invertPitch) }
    var jog by remember { mutableFloatStateOf(s.jogSens) }
    var split by remember { mutableStateOf(s.cueSplit) }
    var cueVol by remember { mutableFloatStateOf(s.cueVolume) }
    Title("PITCH Y JOG")
    Text("Rango del fader de pitch: ±${range.toInt()}%", color = Pal.text, fontSize = 11.sp)
    Slider(
        value = range, onValueChange = { range = it.toInt().toFloat().coerceIn(4f, 50f); s.pitchRange = range },
        valueRange = 4f..50f
    )
    SwitchRow("Invertir direccion del fader de pitch", invert) { invert = it; s.invertPitch = it }
    Text("Sensibilidad del jog: %.1fx".format(jog), color = Pal.text, fontSize = 11.sp)
    Slider(value = jog, onValueChange = { jog = it; s.jogSens = it; vm.applySettings() }, valueRange = 0.3f..3f)
    Title("SALIDA DE AUDIO")
    var tick by remember { mutableIntStateOf(0) }
    var devMenu by remember { mutableStateOf(false) }
    var pref by remember { mutableStateOf(s.btPref) }
    val info = remember(tick) { vm.audioInfo() }
    val report = remember(tick) { vm.audioReport() }
    Text("En uso: $info", color = Pal.ok, fontSize = 11.sp)
    Text("Android ofrece estas salidas:\n$report", color = Pal.dim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    Title("RUTAS: ELIGE POR DONDE SALE CADA SALIDA")
    Text(
        "Principal = la musica (RCA del controlador, Bluetooth, altavoz...). Audifonos = la pre-escucha (jack del controlador, canales 3-4). " +
            "Copia = la misma musica a un segundo destino. Con 'Automatico' en todo, la app decide sola.",
        color = Pal.dim, fontSize = 10.sp
    )
    RouteRow(vm, "Salida PRINCIPAL (musica)", 0)
    RouteRow(vm, "Salida de AUDIFONOS (pre-escucha)", 1)
    RouteRow(vm, "COPIA de la musica (opcional)", 2)
    var btg by remember { mutableFloatStateOf(vm.btGain()) }
    Text("Volumen hacia el Bluetooth: ${(btg * 100).toInt()}% (bajalo si se oye distorsionado)", color = Pal.text, fontSize = 11.sp)
    Slider(value = btg, onValueChange = { btg = it; vm.setBtGain(it) }, valueRange = 0.3f..1f)
    var mode by remember { mutableIntStateOf(vm.audioMode()) }
    var modeMenu by remember { mutableStateOf(false) }
    val modeNames = listOf(
        "Automatico",
        "A: USB 4 canales (forzado)",
        "B: USB 4 canales por indice",
        "C: USB estereo (forzado)",
        "D: USB por canal de comunicacion",
        "E: USB 4 canales, ruta del sistema"
    )
    var cueDelay by remember { mutableFloatStateOf(vm.cueDelay().toFloat()) }
    Text(
        "Retardo del audifono con Bluetooth: ${cueDelay.toInt()} ms (sube hasta que el audifono y el altavoz suenen a la vez)",
        color = Pal.text, fontSize = 11.sp
    )
    Slider(
        value = cueDelay,
        onValueChange = { cueDelay = it.toInt().toFloat(); vm.setCueDelay(cueDelay.toInt()) },
        valueRange = 0f..600f
    )
    Text("Si los audifonos del controlador no suenan, prueba otro modo y pulsa PROBAR AUDIFONOS (se oye un pitido solo ahi).", color = Pal.dim, fontSize = 10.sp)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PressButton("Controlador: ${modeNames[mode]}", Modifier.width(260.dp).height(32.dp), onPress = { modeMenu = true })
        DropdownMenu(expanded = modeMenu, onDismissRequest = { modeMenu = false }) {
            for (i in modeNames.indices) {
                DropdownMenuItem(
                    text = { Text(modeNames[i], fontSize = 11.sp) },
                    onClick = { mode = i; vm.setAudioMode(i); modeMenu = false }
                )
            }
        }
        PressButton("PROBAR AUDIFONOS", Modifier.width(150.dp).height(32.dp), color = Pal.ok, onPress = { vm.testCue() })
        PressButton("PROBAR BLUETOOTH", Modifier.width(150.dp).height(32.dp), color = Pal.ok, onPress = { vm.testBt() })
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PressButton("ACTUALIZAR", Modifier.width(100.dp).height(32.dp), onPress = { tick++ })
        PressButton(
            if (pref.isEmpty()) "Musica: AUTOMATICO" else "Musica: $pref",
            Modifier.width(230.dp).height(32.dp), onPress = { devMenu = true; tick++ }
        )
        DropdownMenu(expanded = devMenu, onDismissRequest = { devMenu = false }) {
            DropdownMenuItem(
                text = { Text("Automatico (Bluetooth)", fontSize = 11.sp) },
                onClick = { pref = ""; vm.setBtPref(""); devMenu = false }
            )
            for (n in vm.audioChoices()) {
                DropdownMenuItem(
                    text = { Text(n, fontSize = 11.sp) },
                    onClick = { pref = n; vm.setBtPref(n); devMenu = false }
                )
            }
        }
    }
    SwitchRow("Cue dividido: PFL en el canal izquierdo, master en el derecho", split) {
        split = it; s.cueSplit = it; vm.applySettings()
    }
    Text("Volumen de cue", color = Pal.text, fontSize = 11.sp)
    Slider(value = cueVol, onValueChange = { cueVol = it; s.cueVolume = it; vm.applySettings() }, valueRange = 0f..1f)
    Text(
        "Nota: la salida usa la tarjeta de sonido que Android tenga activa. Con auriculares/adaptador " +
            "estereo, el modo dividido permite cuear con un cable en Y.",
        color = Pal.dim, fontSize = 10.sp
    )
}

@Composable
private fun RouteRow(vm: DjViewModel, label: String, idx: Int) {
    var name by remember { mutableStateOf(vm.routeName(idx)) }
    var pair by remember { mutableIntStateOf(vm.routePair(idx)) }
    var menu by remember { mutableStateOf(false) }
    Text(label, color = Pal.text, fontSize = 11.sp)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PressButton(if (name.isEmpty()) (if (idx == 2) "Ninguna" else "Automatico") else name, Modifier.width(230.dp).height(32.dp), onPress = { menu = true })
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(if (idx == 2) "Ninguna" else "Automatico", fontSize = 11.sp) },
                onClick = { name = ""; vm.setRoute(idx, "", pair); menu = false }
            )
            for (n in vm.audioAllChoices()) {
                DropdownMenuItem(
                    text = { Text(n, fontSize = 11.sp) },
                    onClick = { name = n; vm.setRoute(idx, n, pair); menu = false }
                )
            }
        }
        if (idx != 2) {
            PressButton(
                if (pair == 0) "Canales 1-2" else "Canales 3-4", Modifier.width(110.dp).height(32.dp),
                onPress = { pair = 1 - pair; vm.setRoute(idx, name, pair) }
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Pal.text, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun MonitorSection(vm: DjViewModel) {
    val log by vm.midiLog.collectAsState()
    Title("MONITOR MIDI (estado dato1 dato2)")
    Column(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(6.dp)).background(Color0).padding(6.dp)) {
        if (log.isEmpty()) Text("Mueve cualquier control...", color = Pal.dim, fontSize = 10.sp)
        for (l in log) Text(l, color = Pal.ok, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

private val Color0 = androidx.compose.ui.graphics.Color(0xFF05070B)
