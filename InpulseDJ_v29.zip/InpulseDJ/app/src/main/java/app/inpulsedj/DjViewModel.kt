package app.inpulsedj

import android.app.Application
import android.content.ContentUris
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.inpulsedj.audio.AudioOutput
import app.inpulsedj.audio.DjEngine
import app.inpulsedj.audio.Track
import app.inpulsedj.ui.Pal
import app.inpulsedj.audio.TrackDecoder
import app.inpulsedj.midi.ActionSink
import app.inpulsedj.midi.Binding
import app.inpulsedj.midi.LedFeedback
import app.inpulsedj.midi.MappingEngine
import app.inpulsedj.midi.UsbMidi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

class DjViewModel(app: Application) : AndroidViewModel(app), ActionSink {
    private val ctx = app.applicationContext
    val settings = Settings(ctx)

    val engine: DjEngine
    private val audio: AudioOutput
    val mapping = MappingEngine(ctx)
    val usb: UsbMidi
    private val leds: LedFeedback

    val ui = MutableStateFlow(DjUi())
    val library = MutableStateFlow<List<LibTrack>>(emptyList())
    val showRemaining = MutableStateFlow(true)   // tiempo restante (true) o transcurrido en los platos A y B
    val libMode = MutableStateFlow(0)            // 0 = todas, 1 = por carpetas
    val libFolder = MutableStateFlow<String?>(null)
    val libSort = MutableStateFlow(0)            // 0 = titulo, 1 = BPM, 2 = tono
    val analysisStatus = MutableStateFlow("")
    val analyzing = MutableStateFlow(false)
    private val cache = AnalysisCache(ctx)
    private val prefs = ctx.getSharedPreferences("inpulse_lib", android.content.Context.MODE_PRIVATE)
    private var analysisJob: Job? = null
    val selected = MutableStateFlow(0)
    val libraryVisible = MutableStateFlow(false)
    val midiLog = MutableStateFlow<List<String>>(emptyList())
    val learnStatus = MutableStateFlow("")
    val message = MutableStateFlow("")

    private val titles = arrayOf("", "")
    private val artists = arrayOf("", "")
    private val loading = floatArrayOf(-1f, -1f)
    private val loadedUri = arrayOf<Uri?>(null, null)
    private val tracks = arrayOfNulls<Track>(2)
    private val rollBeats = doubleArrayOf(1.0, 2.0, 4.0, 8.0)

    private val autoMix = MutableStateFlow(false)
    val usedTracks = MutableStateFlow<Set<String>>(prefs.getStringSet("used", emptySet())?.toSet() ?: emptySet())
    private fun markUsed(uri: String) {
        if (uri in usedTracks.value) return
        val n = usedTracks.value + uri
        usedTracks.value = n
        prefs.edit().putStringSet("used", HashSet(n)).apply()
    }
    fun clearUsed() {
        usedTracks.value = emptySet()
        prefs.edit().remove("used").apply()
    }
    val waveZoom = MutableStateFlow(1)           // 0 = 3 s, 1 = 6 s, 2 = 12 s de ventana
    fun cycleZoom() { waveZoom.value = (waveZoom.value + 1) % 3 }
    val mixProgress = MutableStateFlow(-1f)      // progreso de la mezcla automatica (-1 = sin mezcla)
    val verticalView = MutableStateFlow(settings.verticalView)
    fun setVerticalView(on: Boolean) { settings.verticalView = on; verticalView.value = on }
    fun setCueHere(deck: Int) { val d = dk(deck); engine.post { d.cuePoint = d.pos } }
    fun setGridHere(deck: Int) { val d = dk(deck); engine.post { d.cmdSetAnchorHere() } }
    val simpleMode = MutableStateFlow(settings.simpleMode)
    fun setSimpleMode(on: Boolean) { settings.simpleMode = on; simpleMode.value = on }
    private var autoMixJobBusy = false

    init {
        val am = ctx.getSystemService(AudioManager::class.java)
        val sr = am?.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        val fpb = max(64, am?.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256)
        val block = fpb * ((256 + fpb - 1) / fpb)
        engine = DjEngine(sr, block)
        audio = AudioOutput(ctx, engine, block)
        applySettings()
        Pal.day = settings.dayMode
        audio.btPref = settings.btPref
        audio.usbMode = settings.audioMode
        audio.cueDelayMs = settings.cueDelayMs
        audio.routeMaster = settings.routeMaster
        audio.routeMasterPair = settings.routeMasterPair
        audio.routeCue = settings.routeCue
        audio.routeCuePair = settings.routeCuePair
        audio.routeCopy = settings.routeCopy
        audio.btGain = settings.btGain
        audio.start()

        mapping.load()
        mapping.onRaw = { s, d1, d2 ->
            val line = "%02X %02X %02X".format(s, d1, d2)
            midiLog.value = (listOf(line) + midiLog.value).take(14)
        }
        mapping.onLearned = { b ->
            learnStatus.value = "Asignado: ${b.label} <- %02X %02X".format(b.status, b.data1)
        }
        usb = UsbMidi(
            ctx, mapping.nameHints,
            onMessage = { s, a, b -> mapping.onMessage(s, a, b, this) },
            onConnected = { onControllerConnected() }
        )
        leds = LedFeedback(usb)
        usb.start()

        viewModelScope.launch(Dispatchers.Default) {
            var tick = 0
            while (isActive) {
                val s = snapshot()
                ui.value = s
                leds.update(s, (tick / 8) % 2 == 0)
                tick++
                runAutoMix(s)
                delay(33)
            }
        }
        refreshLibrary()
    }

    fun applySettings() {
        engine.cueSplit = settings.cueSplit
        engine.cueVolume = settings.cueVolume
        for (d in engine.decks) d.jogSensitivity = settings.jogSens.toDouble()
    }

    private fun onControllerConnected() {
        leds.reset()
        // Mensajes de arranque del script oficial: pide a la Inpulse que envie la posicion de todos
        // los faders y perillas para que la app quede sincronizada con el hardware.
        for (m in mapping.initMessages) usb.send(m)
        usb.send3(0x91, 0x03, 0x7F)
        usb.send3(0x92, 0x03, 0x7F)
        usb.send3(0x90, 0x04, 0x05)
    }

    // --------------------------------------------------------------- estado

    private fun deckUi(i: Int): DeckUi {
        val d = engine.decks[i]
        val t = tracks[i]
        val sr = t?.sampleRate ?: 44100
        val posSec = d.pos / sr
        var bar = 0
        var beat = 0
        if (t != null && d.bpm > 0.0) {
            val bt = Math.floor((posSec - d.anchorSec) * d.bpm / 60.0).toLong()
            if (bt >= 0) {
                bar = (bt / 4 + 1).toInt()
                beat = (bt % 4 + 1).toInt()
            }
        }
        return DeckUi(
            loaded = t != null,
            title = titles[i],
            artist = artists[i],
            posSec = posSec,
            durSec = t?.durationSec ?: 0.0,
            playing = d.playing,
            baseBpm = d.bpm,
            effBpm = d.bpm * d.tempo,
            tempoPct = (d.tempo - 1.0) * 100.0,
            tempo = d.tempo,
            sync = d.sync,
            keyLock = d.keyLock,
            leader = d.leader,
            pfl = d.pfl,
            vinyl = d.vinyl,
            cuePoint = d.cuePoint / sr,
            cuePreview = d.cuePreview,
            hotcues = d.hotcues.map { if (it < 0) -1.0 else it / sr },
            loopStart = if (d.loopStart < 0) -1.0 else d.loopStart / sr,
            loopEnd = if (d.loopEnd < 0) -1.0 else d.loopEnd / sr,
            loopActive = d.loopActive,
            rollIdx = d.rollIdx,
            fxUnit = d.fxUnitOn,
            fx = d.fxSlotOn.toList(),
            level = d.level,
            volume = d.volume,
            gain = d.gain,
            eqLow = d.eq.low,
            eqMid = d.eq.mid,
            eqHigh = d.eq.high,
            filter = d.filter.value,
            loading = loading[i],
            peaks = t?.peaks,
            bands = t?.bands,
            key = t?.key ?: "",
            bar = bar,
            beat = beat,
            anchorSec = d.anchorSec,
            platterDeg = ((posSec * 200.0) % 360.0).toFloat()
        )
    }

    private fun snapshot() = DjUi(
        a = deckUi(0), b = deckUi(1),
        crossfader = engine.crossfader,
        master = engine.master,
        masterLevel = engine.masterLevel,
        cueSplit = engine.cueSplit,
        cueQuad = audio.cueOnUsb,
        phaseMs = engine.phaseMs,
        audioInfo = audio.description,
        samplerMask = engine.sampler.playingMask(),
        autoMix = autoMix.value
    )

    // --------------------------------------------------------------- biblioteca

    private fun isAudioName(name: String, mime: String): Boolean {
        if (mime.startsWith("audio/")) return true
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus", "wma")
    }

    private fun sortKey(k: String): Int {
        if (k.length < 2) return 999
        val n = k.dropLast(1).toIntOrNull() ?: return 999
        return n * 2 + (if (k.last() == 'B') 1 else 0)
    }

    /** Aplica BPM/tono de la cache y ordena segun el criterio elegido. */
    private fun applyInfo(list: List<LibTrack>): List<LibTrack> {
        val withInfo = list.map {
            val e = cache.get(it.uri.toString())
            if (e != null) it.copy(bpm = e.bpm, key = e.key) else it
        }
        return when (libSort.value) {
            1 -> withInfo.sortedWith(compareBy<LibTrack> { if (it.bpm <= 0.0) 1 else 0 }.thenBy { it.bpm }.thenBy { it.title.lowercase() })
            2 -> withInfo.sortedWith(compareBy<LibTrack> { sortKey(it.key) }.thenBy { it.bpm }.thenBy { it.title.lowercase() })
            else -> withInfo.sortedBy { it.title.lowercase() }
        }
    }

    fun setSort(mode: Int) {
        libSort.value = mode
        library.update { applyInfo(it) }
    }

    fun setLibMode(mode: Int) {
        libMode.value = mode
        libFolder.value = null
    }

    /** Indices (dentro de [library]) de las pistas que se muestran con el modo/carpeta/busqueda actuales. */
    fun visibleIndexes(lib: List<LibTrack>, mode: Int, folder: String?, query: String): List<Int> {
        if (mode == 1 && folder == null) return emptyList()
        val out = ArrayList<Int>()
        for (i in lib.indices) {
            val t = lib[i]
            if (mode == 1 && t.folder != folder) continue
            if (query.isNotBlank() && !t.title.contains(query, true) && !t.artist.contains(query, true)) continue
            out.add(i)
        }
        return out
    }

    private val libLock = Any()
    private val mediaTracks = ArrayList<LibTrack>()
    private val treeTracks = ArrayList<LibTrack>()
    private val fileTracks = ArrayList<LibTrack>()

    private fun publish() {
        synchronized(libLock) { library.value = applyInfo(mediaTracks + treeTracks + fileTracks) }
    }

    fun refreshLibrary() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = ArrayList<LibTrack>()
            try {
                val pathCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.RELATIVE_PATH
                else MediaStore.Audio.Media.DATA
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION, pathCol
                )
                val sel = "(${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE '%.wav' OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE '%.WAV' OR ${MediaStore.Audio.Media.MIME_TYPE} LIKE '%wav%') " +
                    "AND ${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND ${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.IS_ALARM} = 0 " +
                    "AND ${MediaStore.Audio.Media.DURATION} >= 30000"
                val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                ctx.contentResolver.query(base, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")
                    ?.use { c ->
                        while (c.moveToNext()) {
                            val raw = c.getString(4) ?: ""
                            val folder = if (Build.VERSION.SDK_INT >= 29) raw.trimEnd('/')
                            else raw.substringBeforeLast('/', "").removePrefix("/storage/emulated/0/").removePrefix("/storage/")
                            list.add(
                                LibTrack(
                                    ContentUris.withAppendedId(base, c.getLong(0)),
                                    c.getString(1) ?: "Sin titulo",
                                    c.getString(2)?.takeIf { it != "<unknown>" } ?: "",
                                    c.getLong(3),
                                    folder.ifEmpty { "Almacenamiento" }
                                )
                            )
                        }
                    }
            } catch (_: SecurityException) {
            }
            synchronized(libLock) {
                mediaTracks.clear()
                mediaTracks.addAll(list)
            }
            publish()
            // carpetas elegidas por el usuario (acceso persistente)
            val trees = prefs.getStringSet("trees", emptySet()) ?: emptySet()
            if (trees.isNotEmpty()) {
                val scanned = ArrayList<LibTrack>()
                for (t in trees) {
                    try { scanned.addAll(scanTree(Uri.parse(t))) } catch (_: Exception) {}
                }
                synchronized(libLock) {
                    treeTracks.clear()
                    treeTracks.addAll(scanned)
                }
                publish()
                enrichTree()
            }
        }
    }

    private fun scanTree(tree: Uri): List<LibTrack> {
        val out = ArrayList<LibTrack>()
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val rootName = rootId.substringAfterLast(':').substringAfterLast('/').ifEmpty { "Carpeta" }
        fun walk(docId: String, path: String, depth: Int) {
            if (depth > 8 || out.size > 6000) return
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val dirs = ArrayList<Pair<String, String>>()
            ctx.contentResolver.query(
                children,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) dirs.add(id to name)
                    else if (isAudioName(name, mime)) {
                        out.add(
                            LibTrack(
                                DocumentsContract.buildDocumentUriUsingTree(tree, id),
                                name.substringBeforeLast('.'), "", 0L, path
                            )
                        )
                    }
                }
            }
            for ((id, n) in dirs) walk(id, "$path/$n", depth + 1)
        }
        walk(rootId, rootName, 0)
        return out
    }

    /** Lee titulo, artista y duracion de las pistas de carpetas, por tandas, sin bloquear la lista. */
    private fun enrichTree() {
        var done = 0
        val n = synchronized(libLock) { treeTracks.size }
        for (i in 0 until n) {
            val t = synchronized(libLock) { treeTracks.getOrNull(i) } ?: break
            if (t.durationMs > 0) continue
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, t.uri)
                val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: t.title
                val artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                r.release()
                synchronized(libLock) { if (i < treeTracks.size && treeTracks[i].uri == t.uri) treeTracks[i] = t.copy(title = title, artist = artist, durationMs = dur) }
            } catch (_: Exception) {
            }
            done++
            if (done % 20 == 0) publish()
        }
        publish()
    }

    /** El usuario eligio una carpeta con el selector del sistema. */
    fun addFolder(tree: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        val set = HashSet(prefs.getStringSet("trees", emptySet()) ?: emptySet())
        set.add(tree.toString())
        prefs.edit().putStringSet("trees", set).apply()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val found = scanTree(tree)
                synchronized(libLock) {
                    val have = treeTracks.map { it.uri }.toSet()
                    treeTracks.addAll(found.filter { it.uri !in have })
                }
                publish()
                message.value = "Carpeta agregada: ${found.size} pistas"
                enrichTree()
            } catch (e: Exception) {
                message.value = "No se pudo leer la carpeta: ${e.message}"
            }
        }
    }

    /** Olvida las carpetas elegidas a mano. */
    fun clearFolders() {
        prefs.edit().remove("trees").apply()
        synchronized(libLock) { treeTracks.clear() }
        publish()
        libFolder.value = null
    }

    fun addFiles(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            for (u in uris) {
                var title = u.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Archivo"
                var artist = ""
                var dur = 0L
                try {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(ctx, u)
                    r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.let { title = it }
                    r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.let { artist = it }
                    dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    r.release()
                } catch (_: Exception) {
                }
                synchronized(libLock) { fileTracks.add(LibTrack(u, title, artist, dur, "Archivos agregados")) }
            }
            publish()
        }
    }

    /** Analiza BPM y tono de toda la biblioteca en segundo plano (boton ANALIZAR). */
    fun toggleAnalysis() {
        if (analysisJob?.isActive == true) {
            analysisJob?.cancel()
            analyzing.value = false
            analysisStatus.value = "Analisis detenido"
            cache.save()
            return
        }
        analyzing.value = true
        analysisJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                val todo = library.value.filter { cache.get(it.uri.toString()) == null }
                if (todo.isEmpty()) {
                    analysisStatus.value = "Toda la biblioteca ya esta analizada"
                    return@launch
                }
                var n = 0
                for (t in todo) {
                    if (!isActive) break
                    while (loading[0] >= 0f || loading[1] >= 0f) delay(500)   // no competir con la carga de un deck
                    analysisStatus.value = "Analizando ${n + 1}/${todo.size}: ${t.title}"
                    try {
                        val r = TrackDecoder.analyze(ctx, t.uri)
                        cache.put(t.uri.toString(), r.bpm, r.key)
                    } catch (_: Exception) {
                        cache.put(t.uri.toString(), 0.0, "")
                    }
                    n++
                    if (n % 3 == 0) library.update { applyInfo(it) }
                    if (n % 20 == 0) cache.save()
                }
                analysisStatus.value = "Analisis completo: $n pistas"
            } finally {
                cache.save()
                library.update { applyInfo(it) }
                analyzing.value = false
            }
        }
    }

    fun audioInfo(): String = audio.description
    fun audioReport(): String = audio.outputsReport()
    fun audioChoices(): List<String> = audio.outputNames()
    fun audioMode(): Int = settings.audioMode
    fun setAudioMode(m: Int) {
        settings.audioMode = m
        audio.usbMode = m
        audio.restart()
    }
    fun audioAllChoices(): List<String> = audio.allOutputNames()
    fun routeName(i: Int): String = when (i) { 0 -> settings.routeMaster; 1 -> settings.routeCue; else -> settings.routeCopy }
    fun routePair(i: Int): Int = when (i) { 0 -> settings.routeMasterPair; else -> settings.routeCuePair }
    fun setRoute(i: Int, name: String, pair: Int) {
        when (i) {
            0 -> { settings.routeMaster = name; settings.routeMasterPair = pair; audio.routeMaster = name; audio.routeMasterPair = pair }
            1 -> { settings.routeCue = name; settings.routeCuePair = pair; audio.routeCue = name; audio.routeCuePair = pair }
            else -> { settings.routeCopy = name; audio.routeCopy = name }
        }
        audio.restart()
    }
    fun btGain(): Float = settings.btGain
    fun setBtGain(x: Float) {
        settings.btGain = x
        audio.btGain = x
    }
    fun cueDelay(): Int = settings.cueDelayMs
    fun setCueDelay(ms: Int) {
        settings.cueDelayMs = ms
        audio.cueDelayMs = ms
    }
    fun testCue() = audio.testCue()
    fun testBt() = audio.testBt()
    fun setBtPref(name: String) {
        settings.btPref = name
        audio.btPref = name
        audio.restart()
    }

    private val loadGen = IntArray(2)

    fun loadTrack(deck: Int, t: LibTrack) {
        if (loading[deck] >= 0f) return
        loading[deck] = 0f
        val gen = ++loadGen[deck]
        viewModelScope.launch(Dispatchers.Default) {
            var head: Track? = null
            try {
                val key = t.uri.toString()
                val cached = cache.get(key)
                val tr = TrackDecoder.decode(
                    ctx, t.uri, key, t.title, t.artist,
                    onProgress = { if (head == null && loadGen[deck] == gen) loading[deck] = it },
                    fast = true,
                    isCancelled = { loadGen[deck] != gen },
                    onHead = { h ->
                        // el deck suena ya con los primeros segundos; el resto se decodifica detras
                        if (cached != null && cached.bpm > 0.0 && cached.anchor >= 0.0) {
                            h.bpm = cached.bpm
                            h.anchorSec = cached.anchor
                        }
                        head = h
                        tracks[deck] = h
                        titles[deck] = t.title
                        artists[deck] = t.artist
                        loadedUri[deck] = t.uri
                        markUsed(key)
                        engine.post { engine.decks[deck].cmdLoad(h) }
                        loading[deck] = -1f
                        message.value = "Deck ${"AB"[deck]}: ${t.title} - cargando el resto..."
                    }
                )
                if (loadGen[deck] != gen) return@launch
                val h = head
                if (h != null) {
                    tracks[deck] = tr
                    engine.post { engine.decks[deck].cmdSwapTrack(h, tr) }
                } else {
                    tracks[deck] = tr
                    titles[deck] = t.title
                    artists[deck] = t.artist
                    loadedUri[deck] = t.uri
                    markUsed(key)
                    engine.post { engine.decks[deck].cmdLoad(tr) }
                }
                loading[deck] = -1f          // ya se puede tocar; el analisis sigue en segundo plano
                message.value = "Deck ${"AB"[deck]}: ${t.title} - analizando BPM y tono..."
                TrackDecoder.analyzeFull(tr, cached)
                cache.put(key, tr.bpm, tr.key, if (tr.bpm > 0) tr.anchorSec else -1.0)
                cache.save()
                library.update { applyInfo(it) }
                val d = engine.decks[deck]
                engine.post {
                    if (d.track === tr && d.bpm <= 0.0) {
                        d.bpm = tr.bpm
                        d.anchorSec = tr.anchorSec
                    }
                }
                message.value = if (tr.bpm > 0) "Deck ${"AB"[deck]}: ${t.title} (${"%.1f".format(tr.bpm)} BPM)"
                else "Deck ${"AB"[deck]}: ${t.title} (BPM no detectado: ajustalo a mano)"
            } catch (e: Exception) {
                if (loadGen[deck] == gen) message.value = "No se pudo cargar: ${e.message}"
            } finally {
                if (loadGen[deck] == gen) loading[deck] = -1f
            }
        }
    }

    /** Boton BROWSE: con la biblioteca cerrada la abre; abierta, carga la pista elegida
     *  en el deck libre (SHIFT+BROWSE: siempre en el deck B, primer toque abre). */
    private fun browseLoad(shift: Boolean) {
        if (!libraryVisible.value) {
            libraryVisible.value = true
            return
        }
        val a = engine.decks[0]
        val b = engine.decks[1]
        val target = when {
            shift -> 1
            a.track == null -> 0
            b.track == null -> 1
            !a.playing -> 0
            !b.playing -> 1
            else -> 1
        }
        loadSelected(target)
    }

    fun setDayMode(on: Boolean) {
        settings.dayMode = on
        Pal.day = on
    }

    fun loadSelected(deck: Int) {
        val l = library.value
        var i = selected.value
        if (i !in l.indices) {
            i = visibleIndexes(l, libMode.value, libFolder.value, "").firstOrNull() ?: l.indices.firstOrNull() ?: return
            selected.value = i
        }
        loadTrack(deck, l[i])
    }

    // --------------------------------------------------------------- acciones (MIDI + tactil)

    private fun dk(deck: Int) = engine.decks[deck.coerceIn(0, 1)]

    override fun button(action: String, deck: Int, idx: Int, pressed: Boolean) {
        if (deck in 0..1) deckButton(action, deck, idx, pressed) else globalButton(action, pressed)
    }

    private fun globalButton(action: String, pressed: Boolean) {
        if (!pressed) return
        when (action) {
            "browseClick" -> libraryVisible.value = !libraryVisible.value
            "browseClickShift" -> browseLoad(true)
            "autoMix" -> autoMix.value = !autoMix.value
        }
    }

    private fun deckButton(action: String, deck: Int, idx: Int, pressed: Boolean) {
        val d = dk(deck)
        when (action) {
            "play" -> if (pressed) engine.post { d.cmdTogglePlay() }
            "cue" -> engine.post { if (pressed) d.cmdCuePress() else d.cmdCueRelease() }
            "sync" -> if (pressed) engine.setSync(deck, !d.sync)
            "keyLock" -> if (pressed) { d.keyAuto = false; d.keyLock = !d.keyLock }
            "syncLeader" -> if (pressed) engine.setLeader(deck)
            "pfl" -> if (pressed) {
                d.pfl = !d.pfl
                if (d.pfl && !engine.cueSplit && !audio.cueOnUsb) {
                    message.value = "Pre-escucha: activa AUDIFONOS (cable Y, canal izq = cue) o conecta la salida USB de 4 canales"
                }
            }
            "vinyl" -> if (pressed) d.vinyl = !d.vinyl
            "load" -> if (pressed) loadSelected(deck)
            "jogTouch" -> engine.post { d.cmdJogTouch(pressed, false) }
            "jogTouchShift" -> engine.post { d.cmdJogTouch(pressed, true) }
            "loopIn" -> if (pressed) engine.post { d.cmdLoopIn() }
            "loopOut" -> if (pressed) engine.post { d.cmdReloop() }
            "loopHalve" -> if (pressed) engine.post { d.cmdLoopHalve() }
            "loopDouble" -> if (pressed) engine.post { d.cmdLoopDouble() }
            "playStutter" -> if (pressed) engine.post { d.cmdPlayStutter() }
            "startPlay" -> if (pressed) engine.post { d.cmdStartPlay() }
            "hotcue" -> engine.post { if (pressed) d.cmdHotcuePress(idx - 1) else d.cmdHotcueRelease(idx - 1) }
            "hotcueClear" -> if (pressed) engine.post { d.cmdHotcueClear(idx - 1) }
            "roll" -> engine.post {
                if (pressed) d.cmdRollPress(idx, rollBeats[(idx - 1).coerceIn(0, 3)]) else d.cmdRollRelease(idx)
            }
            "fxSlot" -> if (pressed && idx in 1..3) d.fxSlotOn[idx - 1] = !d.fxSlotOn[idx - 1]
            "fxUnit" -> if (pressed) d.fxUnitOn = !d.fxUnitOn
            "sampler" -> if (pressed) engine.post { engine.sampler.trigger(deck * 4 + idx - 1) }
        }
    }

    override fun knob(action: String, deck: Int, value: Float) {
        val v = value.coerceIn(0f, 1f)
        if (action == "crossfader") {
            engine.crossfader = v
            return
        }
        if (deck !in 0..1) return
        val d = dk(deck)
        when (action) {
            "volume" -> d.volume = v
            "gain" -> d.gain = v
            "eqLow" -> d.eq.low = v
            "eqHigh" -> d.eq.high = v
            "eqMid" -> d.eq.mid = v
            "filter" -> d.filter.value = v
            "pitch" -> setPitchFromFader(deck, v, hardware = true)
        }
    }

    fun pitchFaderValue(tempo: Double): Float {
        val range = settings.pitchRange / 100.0
        var x = ((tempo - 1.0) / (2.0 * range) + 0.5).toFloat().coerceIn(0f, 1f)
        if (settings.invertPitch) x = 1f - x
        return x
    }

    private val lastFaderTempo = doubleArrayOf(1.0, 1.0)
    private var pickupMsgAt = 0L

    /**
     * Fader de pitch del hardware o de pantalla (0..1, 0.5 = 0%).
     * Hardware con "recogida suave": si el tempo lo cambio otra cosa (SYNC, auto-mix), el fader fisico
     * no manda hasta que pasa por el valor actual; asi el pitch no da saltos al tocarlo.
     */
    fun setPitchFromFader(deck: Int, v: Float, hardware: Boolean = false) {
        val d = dk(deck)
        var x = if (abs(v - 0.5f) < 0.004f) 0.5f else v
        if (settings.invertPitch) x = 1f - x
        val range = settings.pitchRange / 100.0
        val target = 1.0 + (x - 0.5) * 2.0 * range
        if (hardware) {
            val changedElsewhere = abs(d.tempo - lastFaderTempo[deck]) > 0.0003
            if (changedElsewhere) {
                if (abs(target - d.tempo) > 0.0025) {
                    val now = System.currentTimeMillis()
                    if (now - pickupMsgAt > 2500) {
                        pickupMsgAt = now
                        message.value = "Pitch ${"AB"[deck]}: mueve el fader hasta %+.1f%% para retomar el control".format((d.tempo - 1.0) * 100)
                    }
                    return
                }
            }
            if (abs(target - d.tempo) < 0.00005) return   // ruido del fader
        }
        // Si es seguidor de sync, mover el pitch de verdad rompe el sync (como en Mixxx)
        val o = engine.decks[1 - deck]
        val isLeader = d.leader || (o.sync && deck == 0 && !o.leader)
        if (d.sync && !isLeader && abs(target - d.tempo) > 0.0006) engine.setSync(deck, false)
        d.tempo = target
        lastFaderTempo[deck] = target
    }

    override fun rel(action: String, deck: Int, ticks: Int) {
        when (action) {
            "jogScratch", "jogBend", "jogScratchShift" -> if (deck in 0..1) dk(deck).addJog(ticks)
            "browseTurn" -> moveSelection(ticks)
            "browseTurnShift" -> moveSelection(ticks * 8)
        }
    }

    private fun moveSelection(n: Int) {
        val lib = library.value
        if (lib.isEmpty()) return
        var vis = visibleIndexes(lib, libMode.value, libFolder.value, "")
        if (vis.isEmpty()) vis = lib.indices.toList()
        val pos = vis.indexOf(selected.value)
        val np = ((if (pos < 0) 0 else pos) + n).coerceIn(0, vis.size - 1)
        selected.value = vis[np]
    }

    // --------------------------------------------------------------- UI helpers

    fun toggleCueSplit() {
        settings.cueSplit = !settings.cueSplit
        applySettings()
    }

    fun setMaster(v: Float) { engine.master = v }
    fun setBpm(deck: Int, bpm: Double) { val d = dk(deck); engine.post { d.cmdSetBpm(bpm) } }
    fun setBeatHere(deck: Int) { val d = dk(deck); engine.post { d.cmdSetAnchorHere() } }
    fun seekFraction(deck: Int, f: Double) {
        val t = tracks[deck] ?: return
        val d = dk(deck)
        engine.post { d.cmdSeekFrames(f * t.frames) }
    }

    fun startLearn(b: Binding) {
        mapping.learnTarget = b
        learnStatus.value = "Mueve o pulsa el control para: ${b.label}"
    }

    fun resetMappings() {
        mapping.resetUser()
        learnStatus.value = "Mapeo restablecido al de fabrica"
    }

    fun toggleAutoMix() { autoMix.value = !autoMix.value }

    // --------------------------------------------------------------- Auto-mix (boton Assistant)

    private fun runAutoMix(s: DjUi) {
        if (!autoMix.value || autoMixJobBusy) return
        val lib = library.value
        if (lib.isEmpty()) return
        val fade = 10.0
        val cur = when {
            s.a.playing && !s.b.playing -> 0
            s.b.playing && !s.a.playing -> 1
            else -> -1
        }
        if (cur < 0) return
        val c = if (cur == 0) s.a else s.b
        val other = 1 - cur
        val o = if (cur == 0) s.b else s.a
        if (c.durSec - c.posSec > fade + 1.0) return
        autoMixJobBusy = true
        viewModelScope.launch(Dispatchers.Default) { transition(cur, fade, !o.loaded || o.posSec > 1.0) }
    }

    /** Modo MIXER: mezcla ahora al otro disco, emparejando tempo y compas automaticamente. */
    fun mixNow(fade: Double) {
        if (autoMixJobBusy) return
        val a = dk(0)
        val b = dk(1)
        val cur = when {
            a.playing && !b.playing -> 0
            b.playing && !a.playing -> 1
            a.playing && b.playing -> if (engine.crossfader < 0.5f) 0 else 1
            else -> {
                message.value = "Pon a sonar un disco para mezclar al otro"
                return
            }
        }
        val other = dk(1 - cur)
        autoMixJobBusy = true
        viewModelScope.launch(Dispatchers.Default) { transition(cur, fade, other.track == null) }
    }

    private suspend fun transition(cur: Int, fade: Double, loadNext: Boolean) {
        val other = 1 - cur
        try {
            if (loadNext) {
                val lib = library.value
                if (lib.isEmpty()) {
                    message.value = "Biblioteca vacia: carga una pista en el otro disco"
                    return
                }
                val idx = lib.indexOfFirst { it.uri == loadedUri[cur] }
                val next = lib[(if (idx < 0) 0 else idx + 1) % lib.size]
                loadTrack(other, next)
                var guard = 0
                while (loading[other] >= 0f && guard < 600) { delay(100); guard++ }
            }
            val od = dk(other)
            val cd = dk(cur)
            if (od.track == null) return
            engine.setSync(other, true)   // iguala tempo y compas con el disco que suena
            if (!od.playing) engine.post { od.cmdTogglePlay() }
            delay(300)
            val from = engine.crossfader
            val to = if (other == 1) 1f else 0f
            val steps = (fade * 20).toInt().coerceAtLeast(1)
            for (k in 1..steps) {
                engine.crossfader = from + (to - from) * k / steps
                mixProgress.value = k.toFloat() / steps
                delay(50)
            }
            engine.post { if (cd.playing) cd.cmdTogglePlay() }
            engine.setSync(other, false)
        } finally {
            mixProgress.value = -1f
            autoMixJobBusy = false
        }
    }

    override fun onCleared() {
        for (m in mapping.shutdownMessages) usb.send(m)
        usb.stop()
        audio.stop()
        super.onCleared()
    }
}
