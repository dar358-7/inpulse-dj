package app.inpulsedj.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Detector de BPM y primer tiempo basado en la envolvente de graves
 * (autocorrelacion del flujo de onsets). Pensado para musica con bombo marcado.
 */
object BpmDetector {
    class Result(val bpm: Double, val anchorSec: Double)

    /** Como en Traktor/rekordbox: casi toda la musica de estudio va a un BPM entero; si el analisis cae a menos de 0,035 se ajusta (evita derivas). */
    fun snap(b: Double): Double {
        val r = Math.round(b).toDouble()
        return if (b > 0.0 && Math.abs(b - r) <= 0.035) r else b
    }

    fun analyze(pcm: ShortArray, frames: Int, sr: Int): Result? {
        val hop = 256
        val durSec = frames.toDouble() / sr
        if (durSec < 20.0) return null
        val startSec = min(20.0, durSec * 0.2)
        val lenSec = min(90.0, durSec - startSec - 1.0)
        val startFrame = (startSec * sr).toInt()
        val nHop = (lenSec * sr / hop).toInt()
        if (nHop < 600) return null

        // Envolvente de la banda < 150 Hz
        val env = FloatArray(nHop)
        val a = (1.0 - exp(-2.0 * PI * 150.0 / sr)).toFloat()
        var lp = 0f
        var idx = startFrame
        for (h in 0 until nHop) {
            var e = 0f
            for (k in 0 until hop) {
                val m = (pcm[2 * idx].toInt() + pcm[2 * idx + 1].toInt()) * (0.5f / 32768f)
                lp += a * (m - lp)
                e += abs(lp)
                idx++
            }
            env[h] = e / hop
        }
        val onsetPos = FloatArray(nHop)
        for (i in 1 until nHop) onsetPos[i] = max(0f, env[i] - env[i - 1])
        var mean = 0f
        for (v in onsetPos) mean += v
        mean /= nHop
        val onset = FloatArray(nHop) { onsetPos[it] - mean }

        val fps = sr.toDouble() / hop
        val minLag = max(2, (fps * 60.0 / 200.0).toInt())
        val maxLag = (fps * 60.0 / 60.0).toInt()
        val maxAll = min(nHop / 2, maxLag * 2 + 2)
        val ac = DoubleArray(maxAll + 1)
        for (l in max(1, minLag / 2)..maxAll) {
            var s = 0.0
            for (i in 0 until nHop - l) s += onset[i] * onset[i + l]
            ac[l] = s / (nHop - l)
        }

        fun score(l: Int): Double {
            var s = ac[l]
            if (2 * l <= maxAll) s += 0.5 * ac[2 * l]
            val bpm = 60.0 * fps / l
            val oct = ln(bpm / 125.0) / ln(2.0)
            val w = exp(-0.5 * (oct / 0.9) * (oct / 0.9))
            return s * w
        }

        var bestLag = -1
        var bestScore = -1e30
        for (l in minLag..min(maxLag, maxAll)) {
            val s = score(l)
            if (s > bestScore) {
                bestScore = s
                bestLag = l
            }
        }
        if (bestLag < 0 || bestScore <= 0.0) return null

        // Interpolacion parabolica
        var lagF = bestLag.toDouble()
        if (bestLag > minLag && bestLag < min(maxLag, maxAll)) {
            val y0 = score(bestLag - 1)
            val y1 = score(bestLag)
            val y2 = score(bestLag + 1)
            val den = y0 - 2 * y1 + y2
            if (abs(den) > 1e-18) lagF += 0.5 * (y0 - y2) / den
        }
        var bpm = 60.0 * fps / lagF
        while (bpm < 80.0) bpm *= 2.0
        while (bpm > 175.0) bpm /= 2.0

        // Refinado: peine de pulsos sobre toda la ventana (+-1 BPM, paso 0.05)
        var bestBpm = bpm
        var bestPhase = 0.0
        var bestAvg = -1.0
        var cand = bpm - 1.0
        while (cand <= bpm + 1.0001) {
            val period = fps * 60.0 / cand
            var phi = 0.0
            while (phi < period) {
                var sum = 0.0
                var cnt = 0
                var pos = phi
                while (pos < nHop - 1) {
                    sum += onsetPos[pos.toInt()]
                    cnt++
                    pos += period
                }
                val avg = if (cnt > 0) sum / cnt else 0.0
                if (avg > bestAvg) {
                    bestAvg = avg
                    bestBpm = cand
                    bestPhase = phi
                }
                phi += 0.5
            }
            cand += 0.05
        }
        bpm = bestBpm

        // Refinado fino: peine de pulsos con resolucion de 0,01 BPM sobre una ventana larga
        val lenFine = min(240.0, durSec - startSec - 1.0)
        val fine = fineRefine(pcm, sr, startFrame, (lenFine * sr).toInt(), bpm)
        var anchorSec: Double
        if (fine != null) {
            bpm = fine[0]
            anchorSec = fine[1]
        } else {
            anchorSec = (startFrame + bestPhase * hop) / sr - 0.003
        }
        if (abs(bpm - bpm.roundToInt()) < 0.025) bpm = bpm.roundToInt().toDouble()
        bpm = (bpm * 100.0).roundToInt() / 100.0
        val periodSec = 60.0 / bpm
        anchorSec -= floor(anchorSec / periodSec) * periodSec
        return Result(snap(bpm), anchorSec)
    }

    /** Devuelve [bpm, ancla en segundos] o null si no hay datos suficientes. */
    private fun fineRefine(pcm: ShortArray, sr: Int, startFrame: Int, lenFrames: Int, bpm0: Double): DoubleArray? {
        val hop = 32
        val n = lenFrames / hop
        if (n < 4000) return null
        val a = (1.0 - exp(-2.0 * PI * 150.0 / sr)).toFloat()
        val env = FloatArray(n)
        var lp = 0f
        var idx = startFrame
        for (h in 0 until n) {
            var e = 0f
            for (k in 0 until hop) {
                val m = (pcm[2 * idx].toInt() + pcm[2 * idx + 1].toInt()) * (0.5f / 32768f)
                lp += a * (m - lp)
                e += abs(lp)
                idx++
            }
            env[h] = e / hop
        }
        val w = 4
        val sm = FloatArray(n)
        var acc = 0f
        for (i in 0 until n) {
            acc += env[i]
            if (i >= w) acc -= env[i - w]
            sm[i] = acc / min(i + 1, w)
        }
        val on = FloatArray(n)
        for (i in 1 until n) on[i] = max(0f, sm[i] - sm[i - 1])
        val fps = sr.toDouble() / hop
        var bestBpm = bpm0
        var bestPhase = 0.0
        var bestAvg = -1.0
        var cand = bpm0 - 0.2
        while (cand <= bpm0 + 0.2001) {
            val period = fps * 60.0 / cand
            var phi = 0.0
            while (phi < period) {
                var sum = 0.0
                var cnt = 0
                var pos = phi
                while (pos < n - 1) {
                    sum += on[pos.toInt()]
                    cnt++
                    pos += period
                }
                val avg = if (cnt > 0) sum / cnt else 0.0
                if (avg > bestAvg) {
                    bestAvg = avg
                    bestBpm = cand
                    bestPhase = phi
                }
                phi += 1.0
            }
            cand += 0.01
        }
        // el flujo de onsets llega ~ (w/2 + 0,5) saltos despues del ataque real
        val anchor = (startFrame + (bestPhase - (w / 2.0 + 0.5)) * hop) / sr - ANCHOR_BIAS
        return doubleArrayOf(bestBpm, anchor)
    }

    private const val ANCHOR_BIAS = 0.002
}
