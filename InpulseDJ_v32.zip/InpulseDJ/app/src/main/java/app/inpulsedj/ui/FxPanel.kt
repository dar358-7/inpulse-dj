package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.inpulsedj.DjUi
import app.inpulsedj.DjViewModel
import app.inpulsedj.audio.FxKinds
import app.inpulsedj.audio.XfKinds

/** Nombres de los ejes del pad XY de cada efecto: (horizontal, vertical). */
private val axisNames = listOf(
    "Tiempo" to "Filtro: LP abajo / HP arriba",
    "Tamano" to "Mezcla",
    "Velocidad" to "Profundidad",
    "Velocidad" to "Resonancia",
    "Bits" to "Muestreo",
    "Ritmo (1/4, 1/8, 1/16, 1/32)" to "Profundidad",
    "Velocidad" to "Volumen",
    "Duracion" to "Ruido",
    "Ritmo" to "Resonancia",
    "Frenado" to "-",
    "Realimentacion" to "-"
)

/** Panel de efectos estilo djay: Pad (XY), Instant (8 pads) y Manual, para el disco A o B. */
@Composable
fun FxSheet(ui: DjUi, vm: DjViewModel, modifier: Modifier, onClose: () -> Unit) {
    var deck by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    val d = if (deck == 0) ui.a else ui.b
    val color = if (deck == 0) Pal.deckA else Pal.deckB
    Column(
        modifier.clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)).background(Pal.panel).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("EFECTOS", color = Pal.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
            PressButton("DECK A", Modifier.width(74.dp).height(28.dp), active = deck == 0, color = Pal.deckA, onPress = { deck = 0 })
            PressButton("DECK B", Modifier.width(74.dp).height(28.dp), active = deck == 1, color = Pal.deckB, onPress = { deck = 1 })
            PressButton("CERRAR", Modifier.width(74.dp).height(28.dp), color = Pal.red, onPress = onClose)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PressButton("PAD", Modifier.weight(1f).height(28.dp), active = tab == 0, color = color, onPress = { tab = 0 })
            PressButton("INSTANT", Modifier.weight(1f).height(28.dp), active = tab == 1, color = color, onPress = { tab = 1 })
            PressButton("MANUAL", Modifier.weight(1f).height(28.dp), active = tab == 2, color = color, onPress = { tab = 2 })
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FxKinds.names.forEachIndexed { i, n ->
                PressButton(n, Modifier.width(88.dp).height(28.dp), active = d.advKind == i, color = color, onPress = { vm.fxSelect(deck, i) })
            }
        }
        when (tab) {
            0 -> {
                val ax = axisNames[d.advKind.coerceIn(0, axisNames.size - 1)]
                Text("Horizontal: ${ax.first}    Vertical: ${ax.second}", color = Pal.dim, fontSize = 10.sp, maxLines = 1)
                XyPad(
                    d.advX, d.advY, d.advOn, color, Modifier.weight(1f).fillMaxWidth(),
                    onXY = { x, y -> vm.fxXY(deck, x, y) }, onHold = { vm.fxHold(deck, it) }
                )
                Text("Toca y arrastra: el efecto suena mientras mantienes el dedo", color = Pal.dim, fontSize = 9.sp)
            }
            1 -> {
                Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (row in 0..1) {
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (col in 0..3) {
                                val idx = row * 4 + col
                                val p = FxKinds.pads[idx]
                                PressButton(
                                    p.label + (if (p.sub.isNotEmpty()) " " + p.sub else ""),
                                    Modifier.weight(1f).fillMaxHeight(),
                                    active = d.advOn && d.advKind == p.kind, color = color,
                                    onPress = { vm.fxPad(deck, idx, true) },
                                    onRelease = { vm.fxPad(deck, idx, false) }
                                )
                            }
                        }
                    }
                }
                Text("Mantén el pad pulsado: el efecto suena solo mientras lo tocas", color = Pal.dim, fontSize = 9.sp)
            }
            else -> {
                Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PressButton(
                        if (d.advOn) "DESACTIVAR ${FxKinds.names[d.advKind.coerceIn(0, FxKinds.names.size - 1)].uppercase()}" else "ACTIVAR ${FxKinds.names[d.advKind.coerceIn(0, FxKinds.names.size - 1)].uppercase()}",
                        Modifier.fillMaxWidth().height(40.dp), active = d.advOn, color = color,
                        onPress = { vm.fxHold(deck, !d.advOn) }
                    )
                    val ax = axisNames[d.advKind.coerceIn(0, axisNames.size - 1)]
                    Text(ax.first, color = Pal.dim, fontSize = 10.sp)
                    Slider(value = d.advX, onValueChange = { vm.fxXY(deck, it, d.advY) }, valueRange = 0f..1f)
                    Text(ax.second, color = Pal.dim, fontSize = 10.sp)
                    Slider(value = d.advY, onValueChange = { vm.fxXY(deck, d.advX, it) }, valueRange = 0f..1f)
                }
            }
        }
    }
}

@Composable
private fun XyPad(
    x: Float, y: Float, on: Boolean, color: Color, modifier: Modifier,
    onXY: (Float, Float) -> Unit, onHold: (Boolean) -> Unit
) {
    val cbXY by rememberUpdatedState(onXY)
    val cbHold by rememberUpdatedState(onHold)
    Box(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Pal.well)
            .border(1.dp, if (on) color else Pal.track, RoundedCornerShape(8.dp))
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val w = size.width.toFloat().coerceAtLeast(1f)
                    val h = size.height.toFloat().coerceAtLeast(1f)
                    cbXY((down.position.x / w).coerceIn(0f, 1f), 1f - (down.position.y / h).coerceIn(0f, 1f))
                    cbHold(true)
                    drag(down.id) { ch ->
                        cbXY((ch.position.x / w).coerceIn(0f, 1f), 1f - (ch.position.y / h).coerceIn(0f, 1f))
                        ch.consume()
                    }
                    cbHold(false)
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val px = x * size.width
            val py = (1f - y) * size.height
            val line = Pal.track
            drawLine(line, Offset(px, 0f), Offset(px, size.height), strokeWidth = 1.5f)
            drawLine(line, Offset(0f, py), Offset(size.width, py), strokeWidth = 1.5f)
            drawCircle(if (on) color else Pal.dim, radius = if (on) 22f else 12f, center = Offset(px, py))
        }
    }
}

/** Crossfader FX: Fundido / Filter / EQ / Echo / Dissolve, mezcla de tempo y "Mezclar ahora" (como djay). */
@Composable
fun XfxDialog(ui: DjUi, vm: DjViewModel, onClose: () -> Unit) {
    val blend by vm.tempoBlend.collectAsState()
    val bars by vm.xfBars.collectAsState()
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.55f).clip(RoundedCornerShape(14.dp)).background(Pal.panel).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Crossfader FX", color = Pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Switch(checked = ui.xfFxOn, onCheckedChange = { vm.setXfFxOn(it) })
            }
            XfKinds.names.forEachIndexed { i, n ->
                PressButton(
                    n, Modifier.fillMaxWidth().height(32.dp), active = ui.xfFxKind == i, color = Pal.deckB,
                    onPress = { vm.setXfFxKind(i); if (i != 0) vm.setXfFxOn(true) else vm.setXfFxOn(false) }
                )
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Mezcla de tempo", color = Pal.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Switch(checked = blend, onCheckedChange = { vm.setTempoBlend(it) })
            }
            PressButton(
                "MEZCLAR AHORA", Modifier.fillMaxWidth().height(36.dp), color = Pal.ok, active = true,
                onPress = { vm.mixNowBars(); onClose() }
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                PressButton("<", Modifier.width(46.dp).height(30.dp), onPress = { vm.setXfBars(when (bars) { 16 -> 8; 8 -> 4; 4 -> 2; else -> 1 }) })
                Text(if (bars == 1) "1 barra" else "$bars barras", color = Pal.dim, fontSize = 13.sp)
                PressButton(">", Modifier.width(46.dp).height(30.dp), onPress = { vm.setXfBars(when (bars) { 1 -> 2; 2 -> 4; 4 -> 8; else -> 16 }) })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PressButton("CENTRAR CROSSFADER", Modifier.weight(1f).height(30.dp), onPress = { vm.knob("crossfader", -1, 0.5f) })
                PressButton("CERRAR", Modifier.width(80.dp).height(30.dp), color = Pal.red, onPress = onClose)
            }
        }
    }
}
