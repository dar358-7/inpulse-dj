package app.inpulsedj.audio

import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * Key Lock / Master Tempo: devuelve al tono original el audio reproducido con varispeed.
 *
 * Un solo puntero de lectura va a velocidad `ratio` sobre una linea de retardo. Cuando se aleja
 * demasiado del centro, salta una distancia fija hacia delante (se omite audio) o hacia atras
 * (se repite) y la posicion exacta del salto se elige por correlacion cruzada (SOLA): la nueva
 * lectura queda en fase con la que sale, asi el empalme no se oye. Con cambios de tempo pequenos
 * (lo normal al igualar BPM) los saltos son raros y el audio sale casi intacto, sin el efecto
 * "peine" de los desplazadores de dos tomas.
 *
 * Siempre introduce una latencia fija (`latencyFrames`) incluso en bypass, para que dos decks
 * con key lock queden alineados entre si.
 */
class KeyLockShifter(g: Int = 2048) {
    private val size = 16384
    private val mask = size - 1
    private val bl = FloatArray(size)
    private val br = FloatArray(size)
    private var wp = 0L
    private var m = 0f

    private val dc = g * 5 / 8          // retardo central
    private val jump = g * 3 / 16       // distancia de cada salto (corta: el retardo oscila solo +-4 ms y las pistas quedan mejor empatadas)
    private val xf = 288                // duracion del empalme (muestras)
    private val srch = 480              // radio de busqueda de la mejor fase (cubre medio periodo de un bajo)
    private val win = 512               // ventana que se compara para elegir la fase
    private var rp = 0.0                // puntero de lectura (absoluto)
    private var rp2 = 0.0               // puntero saliente durante el empalme
    private var xfLeft = 0
    private val ref = FloatArray(win / 2 + 1)

    val latencyFrames: Int get() = dc

    private fun mono(i: Int): Float {
        val k = i and mask
        return (bl[k] + br[k]) * 0.5f
    }

    /** correlacion normalizada entre la lectura saliente (ref) y una candidata c; step = paso de muestreo (en pares) */
    private fun score(c: Double, ratio: Double, step: Int, dl: Int): Float {
        if (c + win * ratio + 4 >= wp.toDouble() || wp - c > size - 64) return -1e30f
        var sab = 0f
        var sbb = 0f
        var k = 0
        while (k < win / 2) {
            val b = mono((c + 2 * k * ratio).toInt())
            sab += ref[k] * b
            sbb += b * b
            k += step
        }
        return sab / sqrt(sbb + 1e-9f) - 1e-4f * (if (dl < 0) -dl else dl)
    }

    private fun splice(ratio: Double) {
        val d = wp - rp
        val dir = if (d > dc) 1 else -1
        val base = rp + dir * jump
        var energy = 0f
        for (k in 0 until win / 2) {
            val v = mono((rp + 2 * k * ratio).toInt())
            ref[k] = v
            energy += v * v
        }
        var bestD = 0
        if (energy > 1e-6f) {
            // busqueda gruesa y luego fina alrededor del mejor punto
            var best = -1e30f
            var dl = -srch
            while (dl <= srch) {
                val sc = score(base + dl, ratio, 4, dl)
                if (sc > best) { best = sc; bestD = dl }
                dl += 4
            }
            val c0 = bestD
            best = -1e30f
            for (e in -4..4) {
                val sc = score(base + c0 + e, ratio, 1, c0 + e)
                if (sc > best) { best = sc; bestD = c0 + e }
            }
        }
        val c = base + bestD
        if (c + xf * ratio + 4 >= wp.toDouble()) return   // sin datos suficientes: no se salta aun
        rp2 = rp
        rp = c
        xfLeft = xf
    }

    private fun tap(buf: FloatArray, pos: Double): Float {
        val f = floor(pos)
        val fr = (pos - f).toFloat()
        val i = f.toLong().toInt()
        val a0 = buf[(i - 1) and mask]
        val a1 = buf[i and mask]
        val a2 = buf[(i + 1) and mask]
        val a3 = buf[(i + 2) and mask]
        return a1 + 0.5f * fr * (a2 - a0 + fr * (2f * a0 - 5f * a1 + 4f * a2 - a3 + fr * (3f * (a1 - a2) + a3 - a0)))
    }

    fun process(out: FloatArray, frames: Int, ratio: Double, active: Boolean) {
        val target = if (active) 1f else 0f
        val dm = 1f / 1024f
        val hi = dc + jump / 2
        val lo = dc - jump / 2
        for (i in 0 until frames) {
            val j = i * 2
            val wi = (wp and mask.toLong()).toInt()
            bl[wi] = out[j]
            br[wi] = out[j + 1]
            val di = ((wp - dc) and mask.toLong()).toInt()
            var l = bl[di]
            var r = br[di]
            if (m < target) m = minOf(target, m + dm) else if (m > target) m = maxOf(target, m - dm)
            if (m > 0f) {
                if (xfLeft == 0) {
                    val d = wp - rp
                    if (d > hi || d < lo) splice(ratio)
                }
                var wl = tap(bl, rp)
                var wr = tap(br, rp)
                if (xfLeft > 0) {
                    val f = 1f - xfLeft.toFloat() / xf
                    val w = f * f * (3f - 2f * f)
                    wl = tap(bl, rp2) * (1f - w) + wl * w
                    wr = tap(br, rp2) * (1f - w) + wr * w
                    rp2 += ratio
                    xfLeft--
                }
                rp += ratio
                l = l * (1f - m) + wl * m
                r = r * (1f - m) + wr * m
            } else {
                rp = (wp - dc).toDouble()
                xfLeft = 0
            }
            out[j] = l
            out[j + 1] = r
            wp++
        }
    }
}
