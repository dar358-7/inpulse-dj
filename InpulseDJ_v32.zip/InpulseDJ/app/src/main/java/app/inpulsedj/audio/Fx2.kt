package app.inpulsedj.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan

/** Efectos avanzados por disco (estilo djay): uno seleccionado a la vez, con pad XY / pads instantaneos. */
object FxKinds {
    val names = listOf(
        "Echo", "Reverb", "Flanger", "Phaser", "Bit Crusher", "Gate",
        "Alarm", "Rocket", "Hydrant", "Landing", "Echo Out+"
    )
    const val ECHO = 0
    const val REVERB = 1
    const val FLANGER = 2
    const val PHASER = 3
    const val CRUSH = 4
    const val GATE = 5
    const val ALARM = 6
    const val ROCKET = 7
    const val HYDRANT = 8
    const val LANDING = 9
    const val ECHO_OUT = 10

    /** Los 8 pads "instantaneos": (efecto, x, y) */
    class Pad(val label: String, val sub: String, val kind: Int, val x: Float, val y: Float)

    val pads = listOf(
        Pad("Landing", "", LANDING, 0.5f, 0.5f),
        Pad("Echo Out+", "", ECHO_OUT, 0.5f, 0.5f),
        Pad("Reverb", "", REVERB, 0.8f, 0.8f),
        Pad("Gate", "1/4", GATE, 0.1f, 1.0f),
        Pad("Flanger", "", FLANGER, 0.4f, 0.8f),
        Pad("Alarm", "", ALARM, 0.5f, 0.7f),
        Pad("Hydrant", "", HYDRANT, 0.5f, 0.5f),
        Pad("Rocket", "", ROCKET, 0.5f, 0.5f)
    )
}

abstract class AdvEffect(protected val sr: Int) {
    abstract fun reset()
    /** buf estereo intercalado; a[i] = activacion suavizada (0..1) de cada muestra */
    abstract fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double)
}

private fun onePoleK(fc: Double, sr: Int): Float = (1.0 - exp(-2.0 * PI * fc / sr)).toFloat()

/** Linea de retardo estereo con relectura interpolada. */
private class Delay(val n: Int) {
    val l = FloatArray(n)
    val r = FloatArray(n)
    var w = 0
    fun clear() { l.fill(0f); r.fill(0f); w = 0 }
    fun readL(d: Float): Float = tap(l, d)
    fun readR(d: Float): Float = tap(r, d)
    private fun tap(b: FloatArray, d: Float): Float {
        var p = w - d
        while (p < 0f) p += n
        val i0 = floor(p).toInt() % n
        val i1 = if (i0 + 1 == n) 0 else i0 + 1
        val f = p - floor(p)
        return b[i0] + (b[i1] - b[i0]) * f
    }
    fun write(a: Float, b: Float) { l[w] = a; r[w] = b; w++; if (w == n) w = 0 }
}

class AdvEcho(sr: Int) : AdvEffect(sr) {
    private val dly = Delay(sr * 3)
    private var cur = sr * 0.4f
    private var lpL = 0f; private var lpR = 0f
    private var hpL = 0f; private var hpR = 0f
    override fun reset() { dly.clear(); lpL = 0f; lpR = 0f; hpL = 0f; hpR = 0f }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val mult = doubleArrayOf(0.25, 0.5, 0.75, 1.0, 1.5)[(x.coerceIn(0f, 1f) * 4.99f).toInt()]
        val target = (beat * mult * sr).toFloat().coerceIn(1500f, dly.n - 4f)
        val t = (y - 0.5f) * 2f
        // y arriba = pasa-altos sobre las repeticiones, abajo = pasa-bajos (como el pad HP/LP de djay)
        val kLp = if (t < 0f) onePoleK(8000.0 * (0.06).pow((-t).toDouble()), sr) else 1f
        val kHp = if (t > 0f) onePoleK(120.0 * 12.0.pow(t.toDouble()), sr) else 0f
        for (i in 0 until frames) {
            cur += (target - cur) * 0.0004f
            val dl = dly.readL(cur)
            val dr = dly.readR(cur)
            lpL += (dl - lpL) * kLp; lpR += (dr - lpR) * kLp
            hpL += (lpL - hpL) * kHp; hpR += (lpR - hpR) * kHp
            val fl = lpL - (if (kHp > 0f) hpL else 0f)
            val fr = lpR - (if (kHp > 0f) hpR else 0f)
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            val g = a[i]
            dly.write(l * g + fl * 0.55f, r * g + fr * 0.55f)
            buf[2 * i] = l + dl * 0.7f
            buf[2 * i + 1] = r + dr * 0.7f
        }
    }
}

class AdvEchoOut(sr: Int) : AdvEffect(sr) {
    private val dly = Delay(sr * 3)
    private var held = 0
    private var wasOn = false
    override fun reset() { dly.clear(); held = 0; wasOn = false }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val d = (beat * 0.75 * sr).toFloat().coerceIn(1500f, dly.n - 4f)
        val fb = 0.72f + 0.12f * x
        for (i in 0 until frames) {
            val on = a[i] > 0.5f
            if (on && !wasOn) held = (sr * 0.12).toInt()
            wasOn = on
            val feed = if (held > 0) 1f else 0f
            if (held > 0) held--
            val dl = dly.readL(d)
            val dr = dly.readR(d)
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            dly.write(l * feed + dl * fb, r * feed + dr * fb)
            val dry = 1f - a[i]
            buf[2 * i] = l * dry + dl * 0.95f
            buf[2 * i + 1] = r * dry + dr * 0.95f
        }
    }
}

class AdvReverb(sr: Int) : AdvEffect(sr) {
    private class Comb(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        private var filt = 0f
        fun clear() { buf.fill(0f); filt = 0f; idx = 0 }
        fun process(x: Float, fb: Float, damp: Float): Float {
            val out = buf[idx]
            filt = out * (1f - damp) + filt * damp
            buf[idx] = x + filt * fb
            idx++
            if (idx >= buf.size) idx = 0
            return out
        }
    }
    private class Allpass(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        fun clear() { buf.fill(0f); idx = 0 }
        fun process(x: Float): Float {
            val b = buf[idx]
            val out = -x + b
            buf[idx] = x + b * 0.5f
            idx++
            if (idx >= buf.size) idx = 0
            return out
        }
    }
    private val scale = sr / 44100.0
    private val tun = intArrayOf(1116, 1188, 1277, 1356)
    private val combL = Array(4) { Comb((tun[it] * scale).toInt()) }
    private val combR = Array(4) { Comb(((tun[it] + 23) * scale).toInt()) }
    private val apL = arrayOf(Allpass((556 * scale).toInt()), Allpass((441 * scale).toInt()))
    private val apR = arrayOf(Allpass(((556 + 23) * scale).toInt()), Allpass(((441 + 23) * scale).toInt()))
    override fun reset() {
        for (c in combL) c.clear(); for (c in combR) c.clear(); for (c in apL) c.clear(); for (c in apR) c.clear()
    }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val fb = 0.70f + 0.24f * x.coerceIn(0f, 1f)
        val wet = 0.6f + 1.8f * y.coerceIn(0f, 1f)
        for (i in 0 until frames) {
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            val xin = (l + r) * 0.5f * a[i] * 0.3f
            var wl = 0f
            var wr = 0f
            for (c in combL) wl += c.process(xin, fb, 0.2f)
            for (c in combR) wr += c.process(xin, fb, 0.2f)
            wl *= 0.25f; wr *= 0.25f
            for (ap in apL) wl = ap.process(wl)
            for (ap in apR) wr = ap.process(wr)
            buf[2 * i] = l + wl * wet
            buf[2 * i + 1] = r + wr * wet
        }
    }
}

class AdvFlanger(sr: Int) : AdvEffect(sr) {
    private val dly = Delay(4096)
    private var ph = 0.0
    override fun reset() { dly.clear(); ph = 0.0 }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val inc = 2.0 * PI * (0.1 + 1.9 * x) / sr
        val depth = 0.002 + 0.006 * y
        for (i in 0 until frames) {
            val lfo = 0.5 + 0.5 * sin(ph)
            ph += inc
            if (ph > 2.0 * PI) ph -= 2.0 * PI
            val d = (sr * (0.0008 + depth * lfo)).toFloat()
            val wl = dly.readL(d)
            val wr = dly.readR(d)
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            dly.write(l + wl * 0.55f, r + wr * 0.55f)
            val g = a[i]
            buf[2 * i] = l * (1f - 0.25f * g) + wl * 0.85f * g
            buf[2 * i + 1] = r * (1f - 0.25f * g) + wr * 0.85f * g
        }
    }
}

class AdvPhaser(sr: Int) : AdvEffect(sr) {
    private val zx = DoubleArray(8)
    private val zy = DoubleArray(8)
    private var ph = 0.0
    private var fbL = 0f; private var fbR = 0f
    override fun reset() { zx.fill(0.0); zy.fill(0.0); ph = 0.0; fbL = 0f; fbR = 0f }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val inc = 2.0 * PI * (0.1 + 2.9 * x) / sr
        val fb = 0.35f + 0.45f * y
        for (i in 0 until frames) {
            val lfo = 0.5 + 0.5 * sin(ph)
            ph += inc
            if (ph > 2.0 * PI) ph -= 2.0 * PI
            val fc = 250.0 * 12.0.pow(lfo)
            val tn = tan(PI * min(fc, sr * 0.45) / sr)
            val c = (tn - 1.0) / (tn + 1.0)
            for (ch in 0..1) {
                var v = (buf[2 * i + ch] + (if (ch == 0) fbL else fbR) * fb).toDouble()
                for (s in 0 until 4) {
                    val k = ch * 4 + s
                    val out = c * v + zx[k] - c * zy[k]
                    zx[k] = v
                    zy[k] = out
                    v = out
                }
                if (ch == 0) fbL = v.toFloat() else fbR = v.toFloat()
                val dry = buf[2 * i + ch]
                val wet = (dry + v.toFloat()) * 0.5f
                buf[2 * i + ch] = dry * (1f - a[i]) + wet * a[i]
            }
        }
    }
}

class AdvCrush(sr: Int) : AdvEffect(sr) {
    private var hl = 0f; private var hr = 0f
    private var cnt = 0
    override fun reset() { hl = 0f; hr = 0f; cnt = 0 }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val bits = 14.0 - 11.0 * x
        val q = 2.0.pow(bits - 1.0).toFloat()
        val hold = (1 + 30 * y * y).toInt()
        for (i in 0 until frames) {
            if (cnt <= 0) {
                hl = floor(buf[2 * i] * q + 0.5f) / q
                hr = floor(buf[2 * i + 1] * q + 0.5f) / q
                cnt = hold
            }
            cnt--
            val g = a[i]
            buf[2 * i] = buf[2 * i] * (1f - g) + hl * g
            buf[2 * i + 1] = buf[2 * i + 1] * (1f - g) + hr * g
        }
    }
}

class AdvGate(sr: Int) : AdvEffect(sr) {
    private var phase = 0.0
    private var gain = 1f
    override fun reset() { phase = 0.0; gain = 1f }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val mult = doubleArrayOf(1.0, 0.5, 0.25, 0.125)[(x.coerceIn(0f, 1f) * 3.99f).toInt()]
        val inc = 1.0 / (beat * mult * sr)
        val closed = (1f - y.coerceIn(0f, 1f)).coerceIn(0f, 0.9f)
        for (i in 0 until frames) {
            phase += inc
            if (phase >= 1.0) phase -= 1.0
            val tgt = if (phase < 0.5) 1f else closed
            gain += (tgt - gain) * 0.01f
            val g = a[i]
            val m = 1f - g + gain * g
            buf[2 * i] *= m
            buf[2 * i + 1] *= m
        }
    }
}

class AdvAlarm(sr: Int) : AdvEffect(sr) {
    private var ph = 0.0
    private var lfo = 0.0
    override fun reset() { ph = 0.0; lfo = 0.0 }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val rate = 1.0 + 3.0 * x
        val lev = 0.10f + 0.28f * y
        for (i in 0 until frames) {
            lfo += 2.0 * PI * rate / sr
            if (lfo > 2.0 * PI) lfo -= 2.0 * PI
            val f = 520.0 + 640.0 * (0.5 + 0.5 * sin(lfo))
            ph += 2.0 * PI * f / sr
            if (ph > 2.0 * PI) ph -= 2.0 * PI
            val s = sin(ph).toFloat() * lev * a[i]
            buf[2 * i] = buf[2 * i] * (1f - 0.2f * a[i]) + s
            buf[2 * i + 1] = buf[2 * i + 1] * (1f - 0.2f * a[i]) + s
        }
    }
}

class AdvRocket(sr: Int) : AdvEffect(sr) {
    private val hp = arrayOf(Biquad(), Biquad())
    private var prog = 0.0
    private var seed = 12345
    private var lastFc = -1.0
    override fun reset() { for (b in hp) b.reset(); prog = 0.0; lastFc = -1.0 }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val dur = 7.0 - 5.0 * x   // segundos que tarda en subir
        for (i in 0 until frames) {
            if (a[i] > 0.5f) prog = min(1.0, prog + 1.0 / (dur * sr)) else prog = max(0.0, prog - 3.0 / (dur * sr))
            if ((i and 31) == 0) {
                val fc = min(80.0 * 90.0.pow(prog), sr * 0.45)
                if (abs(fc - lastFc) > 1.0) { for (b in hp) b.highPass(sr.toDouble(), fc, 1.6); lastFc = fc }
            }
            seed = seed * 1664525 + 1013904223
            val nz = ((seed shr 8) and 0xFFFF) / 32768f - 1f
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            val wl = hp[0].process(l)
            val wr = hp[1].process(r)
            val g = a[i]
            val level = (0.05 + 0.35 * prog * (0.4 + 0.6 * y)).toFloat() * g
            buf[2 * i] = l * (1f - g) + (wl + nz * level) * g
            buf[2 * i + 1] = r * (1f - g) + (wr + nz * level) * g
        }
    }
}

class AdvHydrant(sr: Int) : AdvEffect(sr) {
    private val bp = arrayOf(Biquad(), Biquad())
    private var ph = 0.0
    override fun reset() { for (b in bp) b.reset(); ph = 0.0 }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val cyc = beat * (2.0 - 1.5 * x)
        val inc = 2.0 * PI / (cyc * sr)
        val q = 2.0 + 6.0 * y
        for (i in 0 until frames) {
            if ((i and 15) == 0) {
                val fc = 300.0 * 40.0.pow(0.5 + 0.5 * sin(ph))
                for (b in bp) b.bandPass(sr.toDouble(), min(fc, sr * 0.45), q)
            }
            ph += inc * 1.0
            if (ph > 2.0 * PI) ph -= 2.0 * PI
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            val wl = bp[0].process(l) * 1.1f
            val wr = bp[1].process(r) * 1.1f
            val g = a[i]
            buf[2 * i] = l * (1f - g) + (wl + l * 0.25f) * g
            buf[2 * i + 1] = r * (1f - g) + (wr + r * 0.25f) * g
        }
    }
}

/** "Landing": el disco frena como un plato al apagarlo (tape stop); al soltar vuelve al instante. */
class AdvLanding(sr: Int) : AdvEffect(sr) {
    private val n = sr * 4
    private val bl = FloatArray(n)
    private val br = FloatArray(n)
    private var w = 0
    private var rp = 0.0
    private var speed = 1.0
    private var wasOn = false
    override fun reset() { bl.fill(0f); br.fill(0f); w = 0; rp = 0.0; speed = 1.0; wasOn = false }
    private fun tap(b: FloatArray, p: Double): Float {
        var q = p
        while (q < 0.0) q += n
        val i0 = floor(q).toInt() % n
        val i1 = if (i0 + 1 == n) 0 else i0 + 1
        val f = (q - floor(q)).toFloat()
        return b[i0] + (b[i1] - b[i0]) * f
    }
    override fun run(buf: FloatArray, frames: Int, a: FloatArray, x: Float, y: Float, beat: Double) {
        val stopT = 0.35 + 1.6 * x
        val dec = 1.0 / (stopT * sr * 0.8)     // caida lineal de la velocidad hasta parar
        for (i in 0 until frames) {
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            bl[w] = l; br[w] = r
            val on = a[i] > 0.3f
            if (on && !wasOn) { rp = w.toDouble(); speed = 1.0 }
            wasOn = on
            var tl = 0f
            var tr = 0f
            if (on || a[i] > 0.001f) {
                speed = max(0.0, speed - dec)
                rp += speed
                // no dejar que el puntero de lectura alcance al de escritura (speed <= 1 asi que no ocurre) ni quedar mas de n-8 atras
                var lag = w - rp
                if (lag < 0) lag += n
                if (lag > n - 8) rp = (w - (n - 8)).toDouble()
                val fade = min(1.0, speed * 5.0).toFloat()
                tl = tap(bl, rp) * fade
                tr = tap(br, rp) * fade
            }
            val g = a[i]
            buf[2 * i] = l * (1f - g) + tl * g
            buf[2 * i + 1] = r * (1f - g) + tr * g
            w++
            if (w == n) w = 0
        }
    }
}

/** Contenedor por disco: elige el efecto, lo activa (mantenido) y le pasa los ejes del pad XY. */
class FxRack(private val sr: Int) {
    @Volatile var kind = 0
    @Volatile var on = false
    @Volatile var x = 0.5f
    @Volatile var y = 0.5f
    @Volatile var beatSec = 0.5

    private val fx: Array<AdvEffect> = arrayOf(
        AdvEcho(sr), AdvReverb(sr), AdvFlanger(sr), AdvPhaser(sr), AdvCrush(sr), AdvGate(sr),
        AdvAlarm(sr), AdvRocket(sr), AdvHydrant(sr), AdvLanding(sr), AdvEchoOut(sr)
    )
    private var a = FloatArray(4096)
    private var amt = 0f
    private var tail = 0
    private var running = false
    private var cur = -1

    val active: Boolean get() = running

    fun process(buf: FloatArray, frames: Int) {
        val k = kind.coerceIn(0, fx.size - 1)
        if (k != cur) { cur = k; running = false }
        val o = on
        if (!o && amt < 0.0005f && tail <= 0) { running = false; return }
        if (!running) { fx[k].reset(); running = true; amt = 0f }
        if (o) tail = if (k == FxKinds.ECHO || k == FxKinds.REVERB || k == FxKinds.ECHO_OUT) sr * 5 else sr / 4
        else tail -= frames
        if (a.size < frames) a = FloatArray(frames)
        val target = if (o) 1f else 0f
        val kk = if (k == FxKinds.LANDING && !o) 0.02f else 0.01f
        for (i in 0 until frames) {
            amt += (target - amt) * (if (o) 0.01f else kk)
            a[i] = amt
        }
        fx[k].run(buf, frames, a, x.coerceIn(0f, 1f), y.coerceIn(0f, 1f), beatSec.coerceIn(0.2, 2.0))
    }
}

/** Efectos de crossfader: dan caracter a la transicion segun cuanto se ha "ido" cada disco (p: 0 = presente, 1 = fuera). */
object XfKinds {
    val names = listOf("Fundido", "Filter", "EQ", "Echo", "Dissolve")
}

class XfFx(private val sr: Int) {
    private val hp = Array(2) { arrayOf(Biquad(), Biquad()) }
    private val ls = Array(2) { arrayOf(Biquad(), Biquad()) }
    private val lastP = floatArrayOf(-1f, -1f)
    private val dly = arrayOf(Delay(sr * 2), Delay(sr * 2))
    private val gate = floatArrayOf(1f, 1f)
    private val gateTgt = floatArrayOf(1f, 1f)
    private val seg = IntArray(2)
    private var seed = 987654321

    fun process(buf: FloatArray, frames: Int, kind: Int, p: Float, deck: Int, beat: Double) {
        val pp = p.coerceIn(0f, 1f)
        when (kind) {
            1 -> {
                if (pp < 0.02f) { lastP[deck] = -1f; return }
                if (abs(pp - lastP[deck]) > 0.01f) {
                    val fc = min(40.0 * (6000.0 / 40.0).pow(pp.toDouble()), sr * 0.45)
                    for (b in hp[deck]) b.highPass(sr.toDouble(), fc, 0.9)
                    lastP[deck] = pp
                }
                for (i in 0 until frames) {
                    buf[2 * i] = hp[deck][0].process(buf[2 * i])
                    buf[2 * i + 1] = hp[deck][1].process(buf[2 * i + 1])
                }
            }
            2 -> {
                if (pp < 0.02f) { lastP[deck] = -1f; return }
                if (abs(pp - lastP[deck]) > 0.01f) {
                    val db = -46.0 * pp.toDouble().pow(1.1)
                    for (b in ls[deck]) b.lowShelf(sr.toDouble(), 220.0, db)
                    lastP[deck] = pp
                }
                for (i in 0 until frames) {
                    buf[2 * i] = ls[deck][0].process(buf[2 * i])
                    buf[2 * i + 1] = ls[deck][1].process(buf[2 * i + 1])
                }
            }
            3 -> {
                val d = dly[deck]
                val wet = (pp * 2f).coerceIn(0f, 1f) * 0.6f
                val dl = (beat * 0.75 * sr).toFloat().coerceIn(1500f, d.n - 4f)
                for (i in 0 until frames) {
                    val tl = d.readL(dl)
                    val tr = d.readR(dl)
                    val l = buf[2 * i]
                    val r = buf[2 * i + 1]
                    d.write(l * wet + tl * 0.5f, r * wet + tr * 0.5f)
                    buf[2 * i] = l + tl * wet
                    buf[2 * i + 1] = r + tr * wet
                }
            }
            4 -> {
                val segLen = (sr * 0.007).toInt()
                for (i in 0 until frames) {
                    if (seg[deck] <= 0) {
                        seg[deck] = segLen
                        seed = seed * 1664525 + 1013904223
                        val u = ((seed ushr 8) and 0xFFFF) / 65536f
                        gateTgt[deck] = if (u >= pp * 1.05f) 1f else 0f
                    }
                    seg[deck]--
                    gate[deck] += (gateTgt[deck] - gate[deck]) * 0.03f
                    buf[2 * i] *= gate[deck]
                    buf[2 * i + 1] *= gate[deck]
                }
            }
        }
    }
}
