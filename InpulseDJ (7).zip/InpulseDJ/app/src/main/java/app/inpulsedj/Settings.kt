package app.inpulsedj

import android.content.Context

/** Preferencias persistentes. */
class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("inpulsedj", Context.MODE_PRIVATE)

    var pitchRange: Float
        get() = p.getFloat("pitchRange", 8f)
        set(v) { p.edit().putFloat("pitchRange", v).apply() }
    var invertPitch: Boolean
        get() = p.getBoolean("invertPitch", false)
        set(v) { p.edit().putBoolean("invertPitch", v).apply() }
    var jogSens: Float
        get() = p.getFloat("jogSens", 1f)
        set(v) { p.edit().putFloat("jogSens", v).apply() }
    var simpleMode: Boolean
        get() = p.getBoolean("simpleMode", false)
        set(v) { p.edit().putBoolean("simpleMode", v).apply() }
    var dayMode: Boolean
        get() = p.getBoolean("dayMode", false)
        set(v) { p.edit().putBoolean("dayMode", v).apply() }
    var cueSplit: Boolean
        get() = p.getBoolean("cueSplit", false)
        set(v) { p.edit().putBoolean("cueSplit", v).apply() }
    var cueVolume: Float
        get() = p.getFloat("cueVolume", 0.8f)
        set(v) { p.edit().putFloat("cueVolume", v).apply() }
    var btPref: String
        get() = p.getString("btPref", "") ?: ""
        set(v) { p.edit().putString("btPref", v).apply() }
    var audioMode: Int
        get() = p.getInt("audioMode", 0)
        set(v) { p.edit().putInt("audioMode", v).apply() }
    var cueDelayMs: Int
        get() = p.getInt("cueDelayMs", 180)
        set(v) { p.edit().putInt("cueDelayMs", v).apply() }
    var routeMaster: String
        get() = p.getString("routeMaster", "") ?: ""
        set(v) { p.edit().putString("routeMaster", v).apply() }
    var routeMasterPair: Int
        get() = p.getInt("routeMasterPair", 0)
        set(v) { p.edit().putInt("routeMasterPair", v).apply() }
    var routeCue: String
        get() = p.getString("routeCue", "") ?: ""
        set(v) { p.edit().putString("routeCue", v).apply() }
    var routeCuePair: Int
        get() = p.getInt("routeCuePair", 1)
        set(v) { p.edit().putInt("routeCuePair", v).apply() }
    var routeCopy: String
        get() = p.getString("routeCopy", "") ?: ""
        set(v) { p.edit().putString("routeCopy", v).apply() }
    var btGain: Float
        get() = p.getFloat("btGain", 0.8f)
        set(v) { p.edit().putFloat("btGain", v).apply() }
    var verticalView: Boolean
        get() = p.getBoolean("verticalView", false)
        set(v) { p.edit().putBoolean("verticalView", v).apply() }
}
