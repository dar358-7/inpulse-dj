package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DeckUi
import app.inpulsedj.DjUi
import app.inpulsedj.DjViewModel
import app.inpulsedj.audio.PEAKS_PER_SEC
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

private val VBg = Color(0xFF17181B)
private val VPanel = Color(0xFF212226)
private val VEdge = Color(0xFF3B3E45)
private val VText = Color(0xFFEDEFF3)
private val VDim = Color(0xFF8C909A)
private val VBlue = Color(0xFF2D8CFF)
private val VButton = Color(0xFF2B2D32)

/** Area tactil con eventos de pulsar y soltar. */
@Composable
private fun Tap(
    modifier: Modifier, onPress: () -> Unit = {}, onRelease: () -> Unit = {},
    content: @Composable BoxScope.() -> Unit
) {
    val p by rememberUpdatedState(onPress)
    val r by rememberUpdatedState(onRelease)
    Box(
        modifier.pointerInput(Unit) {
            detectTapGestures(onPress = {
                p()
                tryAwaitRelease()
                r()
            })
        },
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** Boton azul de la onda: activa y desactiva la vista vertical. */
@Composable
fun WaveToggleButton(active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Tap(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) VBlue else Pal.panel2)
            .border(1.dp, if (active) VBlue else Pal.track, RoundedCornerShape(8.dp)),
        onPress = onClick
    ) {
        Icon(
            Icons.Filled.GraphicEq, contentDescription = null,
            tint = if (active) Color.White else Pal.text, modifier = Modifier.size(20.dp)
        )
    }
}

/** Vista vertical estilo djay: dos ondas que bajan, SYNC y pitch a los lados, transporte y crossfader abajo. */
@Composable
fun VerticalView(
    ui: DjUi, vm: DjViewModel, message: String,
    onLibrary: () -> Unit, onSettings: () -> Unit, onClose: () -> Unit,
    modifier: Modifier
) {
    var beatsWin by remember { mutableFloatStateOf(5f) }
    var mixerDeck by remember { mutableIntStateOf(-1) }
    Box(modifier.background(VBg)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                SideColumn(ui.a, 0, vm, Modifier.weight(0.13f).fillMaxHeight()) {
                    mixerDeck = if (mixerDeck == 0) -1 else 0
                }
                Column(Modifier.weight(0.74f).fillMaxHeight()) {
                    Row(
                        Modifier.fillMaxWidth().height(46.dp).background(VPanel),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(0.35f), contentAlignment = Alignment.Center) { LoopControls(ui.a, 0, vm) }
                        Row(
                            Modifier.weight(0.30f), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Tap(Modifier.size(40.dp), onPress = onLibrary) {
                                Icon(Icons.Filled.LibraryMusic, null, tint = VDim, modifier = Modifier.size(24.dp))
                            }
                            WaveToggleButton(true, onClose, Modifier.size(width = 52.dp, height = 36.dp))
                            Tap(Modifier.size(40.dp), onPress = onSettings) {
                                Icon(Icons.Filled.GridView, null, tint = VDim, modifier = Modifier.size(24.dp))
                            }
                        }
                        Box(Modifier.weight(0.35f), contentAlignment = Alignment.Center) { LoopControls(ui.b, 1, vm) }
                    }
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        VWave(
                            ui.a, 0, vm, beatsWin,
                            { beatsWin = (beatsWin * 0.75f).coerceIn(2f, 32f) },
                            { beatsWin = (beatsWin / 0.75f).coerceIn(2f, 32f) },
                            Modifier.weight(1f).fillMaxHeight()
                        )
                        Box(Modifier.width(1.dp).fillMaxHeight().background(VEdge))
                        VWave(
                            ui.b, 1, vm, beatsWin,
                            { beatsWin = (beatsWin * 0.75f).coerceIn(2f, 32f) },
                            { beatsWin = (beatsWin / 0.75f).coerceIn(2f, 32f) },
                            Modifier.weight(1f).fillMaxHeight()
                        )
                    }
                }
                SideColumn(ui.b, 1, vm, Modifier.weight(0.13f).fillMaxHeight()) {
                    mixerDeck = if (mixerDeck == 1) -1 else 1
                }
            }
            BottomBar(ui, vm)
        }

        if (!ui.phaseMs.isNaN()) {
            val ms = ui.phaseMs
            val am = abs(ms)
            val txt = when {
                am < 6.0 -> "EMPATADOS (%.0f ms)".format(ms)
                ms > 0 -> "B ATRASADO %.0f ms".format(am)
                else -> "B ADELANTADO %.0f ms".format(am)
            }
            Text(
                txt, color = if (am < 6.0) Pal.ok else if (am < 25.0) Pal.warn else Pal.red,
                fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 50.dp)
            )
        }
        if (message.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 76.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xCC000000)).padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(message, color = Pal.warn, fontSize = 11.sp, maxLines = 2)
            }
        }
        if (mixerDeck in 0..1) {
            MixerPopup(
                if (mixerDeck == 0) ui.a else ui.b, mixerDeck, vm,
                if (mixerDeck == 0) Pal.deckA else Pal.deckB
            ) { mixerDeck = -1 }
        }
    }
}

// ------------------------------------------------------------------ columnas laterales

@Composable
private fun SideColumn(d: DeckUi, deck: Int, vm: DjViewModel, modifier: Modifier, onMixer: () -> Unit) {
    Column(
        modifier.background(VPanel).padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Tap(
            Modifier.fillMaxWidth().height(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (d.sync) VBlue else VButton)
                .border(1.5.dp, if (d.sync) VBlue else VEdge, RoundedCornerShape(10.dp)),
            onPress = { vm.button("sync", deck, 0, true) }
        ) {
            Text("SYNC", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text("BPM", color = VDim, fontSize = 11.sp)
        Text(
            if (d.loaded && d.effBpm > 0) "%.1f".format(d.effBpm) else "--",
            color = VText, fontSize = 20.sp, fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(6.dp))
        Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            val centered = abs(d.tempoPct) < 0.1
            val note: @Composable () -> Unit = {
                Tap(Modifier.size(24.dp), onPress = { vm.button("keyLock", deck, 0, true) }) {
                    Icon(
                        Icons.Filled.MusicNote, null,
                        tint = if (d.keyLock) VBlue else VDim, modifier = Modifier.size(20.dp)
                    )
                }
            }
            val dot: @Composable () -> Unit = {
                Box(
                    Modifier.size(9.dp).clip(CircleShape)
                        .background(if (centered) Color(0xFF34D399) else Color(0xFF3A3D45))
                )
            }
            if (deck == 0) note() else dot()
            PitchFader(
                vm.pitchFaderValue(d.tempo), { vm.setPitchFromFader(deck, it) },
                Modifier.weight(1f).fillMaxHeight()
            )
            if (deck == 0) dot() else note()
        }
        Spacer(Modifier.height(8.dp))
        Tap(
            Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF1B1C20)).border(1.5.dp, VEdge, CircleShape),
            onPress = onMixer
        ) {
            Icon(Icons.Filled.Tune, null, tint = VText, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun PitchFader(value: Float, onChange: (Float) -> Unit, modifier: Modifier) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectDragGestures(onDragStart = { o -> cb(pitchVal(o.y, size.height.toFloat())) }) { change, _ ->
                    change.consume()
                    cb(pitchVal(change.position.y, size.height.toFloat()))
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o -> cb(pitchVal(o.y, size.height.toFloat())) })
            }
    ) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val pad = 22f
        // ranura oscura con marcas a los lados
        drawRoundRect(
            Color(0xFF111215), Offset(cx - 9f, pad - 8f), Size(18f, h - 2 * pad + 16f),
            CornerRadius(9f, 9f)
        )
        for (i in 0..4) {
            val y = pad + (h - 2 * pad) * i / 4f
            val big = i == 2
            val len = if (big) w * 0.30f else w * 0.20f
            val c = if (big) Color(0xFF8C909A) else Color(0xFF4A4D55)
            drawLine(c, Offset(cx - 14f - len, y), Offset(cx - 14f, y), strokeWidth = 2f)
            drawLine(c, Offset(cx + 14f, y), Offset(cx + 14f + len, y), strokeWidth = 2f)
        }
        // pomo
        val ty = pad + (h - 2 * pad) * (1f - value)
        val tw = w * 0.80f
        drawRoundRect(
            Color(0xFFE7E8EC), Offset(cx - tw / 2f, ty - 15f), Size(tw, 30f), CornerRadius(9f, 9f)
        )
        drawLine(Color(0xFF50535B), Offset(cx - tw / 2f + 8f, ty), Offset(cx + tw / 2f - 8f, ty), strokeWidth = 3f, cap = StrokeCap.Round)
    }
}

private fun pitchVal(y: Float, h: Float): Float = (1f - (y - 22f) / (h - 44f)).coerceIn(0f, 1f)

// ------------------------------------------------------------------ cabecera: loop

@Composable
private fun LoopControls(d: DeckUi, deck: Int, vm: DjViewModel) {
    val label = if (d.loopStart >= 0 && d.loopEnd > d.loopStart && d.baseBpm > 0) {
        val beats = (d.loopEnd - d.loopStart) * d.baseBpm / 60.0
        if (beats >= 1.0) beats.roundToInt().toString() else "1/" + (1.0 / beats).roundToInt()
    } else "4"
    val on = d.loopActive
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Tap(Modifier.size(36.dp), onPress = { vm.button("loopHalve", deck, 0, true) }) {
            Icon(Icons.Filled.ChevronLeft, null, tint = VText, modifier = Modifier.size(34.dp))
        }
        Tap(
            Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                .border(1.5.dp, if (on) VBlue else VEdge, RoundedCornerShape(12.dp)),
            onPress = { vm.button("loopIn", deck, 0, true) }
        ) {
            Icon(Icons.Filled.Repeat, null, tint = if (on) VBlue else VDim, modifier = Modifier.size(38.dp))
            Text(label, color = if (on) VBlue else VText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Tap(Modifier.size(36.dp), onPress = { vm.button("loopDouble", deck, 0, true) }) {
            Icon(Icons.Filled.ChevronRight, null, tint = VText, modifier = Modifier.size(34.dp))
        }
    }
}

// ------------------------------------------------------------------ onda vertical

@Composable
private fun VWave(
    d: DeckUi, deck: Int, vm: DjViewModel, beatsWin: Float,
    onZoomIn: () -> Unit, onZoomOut: () -> Unit, modifier: Modifier
) {
    val peakMax = remember(d.peaks) {
        var m = 0.05f
        d.peaks?.let { for (v in it) if (v > m) m = v }
        m
    }
    val colors = remember(d.bands, d.peaks) { buildWaveColors(d.bands, d.peaks?.size ?: 0, true) }
    val density = LocalDensity.current
    val paint = remember(density) {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = 0xFFB9BDC7.toInt()
            textSize = with(density) { 15.sp.toPx() }
        }
    }
    val left = deck == 0
    Box(modifier.background(VBg)) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val playY = h * 0.5f
            val tempo = d.tempo.coerceIn(0.5, 2.0)
            // escala en tiempo real (126 BPM de referencia): con el mismo BPM efectivo los pulsos de las dos ondas coinciden
            val pxPerSec = (h / (beatsWin * 0.476) / tempo).toFloat()
            val t0 = d.posSec - playY / pxPerSec
            val t1 = d.posSec + (h - playY) / pxPerSec

            // loop
            if (d.loopStart >= 0 && d.loopEnd > d.loopStart) {
                val y0 = (playY + (d.loopStart - d.posSec) * pxPerSec).toFloat().coerceIn(0f, h)
                val y1 = (playY + (d.loopEnd - d.posSec) * pxPerSec).toFloat().coerceIn(0f, h)
                drawRect(
                    Color(0xFF34D399).copy(alpha = if (d.loopActive) 0.28f else 0.10f),
                    Offset(0f, y0), Size(w, (y1 - y0).coerceAtLeast(0f))
                )
            }

            // onda: cada fila es un trozo de la pista, simetrica respecto al centro
            val peaks = d.peaks
            if (peaks != null) {
                val fallback = Color(0xFF3FB8C8)
                val cx = w / 2f
                val maxHalf = w * 0.36f
                var y = 0f
                while (y < h) {
                    val t = d.posSec + (y - playY) / pxPerSec
                    val idx = floor(t * PEAKS_PER_SEC).toInt()
                    if (idx >= 1 && idx < peaks.size - 1) {
                        val pk = (peaks[idx - 1] * 0.25f + peaks[idx] * 0.5f + peaks[idx + 1] * 0.25f) / peakMax
                        val a = Math.pow(pk.coerceIn(0f, 1f).toDouble(), 0.65).toFloat().coerceAtLeast(0.03f)
                        val col = if (colors != null && idx < colors.size) Color(colors[idx]) else fallback
                        val half = a * maxHalf
                        drawLine(
                            col.copy(alpha = if (y < playY) 0.6f else 1f),
                            Offset(cx - half, y), Offset(cx + half, y), strokeWidth = 2.2f
                        )
                    }
                    y += 2f
                }
            }

            // rejilla: linea en cada pulso, mas marcada en cada compas con su numero
            if (d.baseBpm > 0) {
                val beat = 60.0 / d.baseBpm
                var k = ceil((t0 - d.anchorSec) / beat).toLong()
                while (true) {
                    val t = d.anchorSec + k * beat
                    if (t > t1) break
                    val y = (playY + (t - d.posSec) * pxPerSec).toFloat()
                    val bar = Math.floorMod(k, 4L) == 0L
                    drawLine(
                        Color(0xFFB8C27A).copy(alpha = if (bar) 0.75f else 0.35f),
                        Offset(0f, y), Offset(w, y), strokeWidth = if (bar) 2f else 1.2f
                    )
                    if (bar && k >= 0) {
                        val n = Math.floorDiv(k, 4L) + 1
                        drawIntoCanvas { c -> c.nativeCanvas.drawText(n.toString(), 14f, y + paint.textSize * 1.15f, paint) }
                    }
                    k++
                }
            }

            // hot cues y cue
            for (i in 0..3) {
                val hc = d.hotcues[i]
                if (hc >= 0 && hc in t0..t1) {
                    val y = (playY + (hc - d.posSec) * pxPerSec).toFloat()
                    drawRect(Pal.hot[i], Offset(0f, y - 2f), Size(22f, 4f))
                }
            }
            if (d.cuePoint in t0..t1) {
                val y = (playY + (d.cuePoint - d.posSec) * pxPerSec).toFloat()
                drawRect(Pal.warn, Offset(0f, y - 2f), Size(22f, 4f))
            }

            // cabezal rojo
            drawLine(Color(0xFFE5322D), Offset(0f, playY), Offset(w, playY), strokeWidth = 2.5f)
        }

        // numero de deck (toca = pre-escucha)
        Tap(
            Modifier.align(if (left) Alignment.TopStart else Alignment.TopEnd).padding(8.dp),
            onPress = { vm.button("pfl", deck, 0, true) }
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (deck + 1).toString(), color = if (d.pfl) VBlue else VDim,
                    fontSize = 22.sp, fontWeight = FontWeight.Medium
                )
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = if (d.pfl) VBlue else VDim, modifier = Modifier.size(20.dp))
            }
        }
        // zoom + / -
        Column(
            Modifier.align(if (left) Alignment.CenterStart else Alignment.CenterEnd).padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Tap(Modifier.size(40.dp), onPress = onZoomIn) {
                Icon(Icons.Filled.Add, null, tint = VDim, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(26.dp))
            Tap(Modifier.size(40.dp), onPress = onZoomOut) {
                Icon(Icons.Filled.Remove, null, tint = VDim, modifier = Modifier.size(30.dp))
            }
        }
        // lapiz: fija el primer tiempo de la rejilla en la posicion actual
        Tap(
            Modifier.align(if (left) Alignment.BottomStart else Alignment.BottomEnd).padding(10.dp).size(36.dp),
            onPress = { vm.setGridHere(deck) }
        ) {
            Icon(Icons.Filled.Edit, null, tint = VDim, modifier = Modifier.size(22.dp))
        }
    }
}

// ------------------------------------------------------------------ barra inferior

@Composable
private fun BottomBar(ui: DjUi, vm: DjViewModel) {
    Row(
        Modifier.fillMaxWidth().height(68.dp).background(VPanel),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(0.13f).fillMaxHeight(), contentAlignment = Alignment.Center) { PlayButton(ui.a, 0, vm) }
        Box(Modifier.weight(0.17f).fillMaxHeight().padding(horizontal = 6.dp), contentAlignment = Alignment.Center) { SetGroup(0, vm) }
        Box(Modifier.weight(0.05f).fillMaxHeight(), contentAlignment = Alignment.Center) { PflCircle(ui.a, 0, vm) }
        Box(Modifier.weight(0.30f).fillMaxHeight().padding(horizontal = 8.dp, vertical = 2.dp), contentAlignment = Alignment.Center) {
            CrossFader(ui.crossfader, { vm.knob("crossfader", -1, it) }, Modifier.fillMaxSize())
        }
        Box(Modifier.weight(0.04f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Tap(
                Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF34373E)),
                onPress = { vm.knob("crossfader", -1, 0.5f) }
            ) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = VText, modifier = Modifier.size(22.dp))
            }
        }
        Box(Modifier.weight(0.05f).fillMaxHeight(), contentAlignment = Alignment.Center) { PflCircle(ui.b, 1, vm) }
        Box(Modifier.weight(0.17f).fillMaxHeight().padding(horizontal = 6.dp), contentAlignment = Alignment.Center) { SetGroup(1, vm) }
        Box(Modifier.weight(0.13f).fillMaxHeight(), contentAlignment = Alignment.Center) { PlayButton(ui.b, 1, vm) }
    }
}

@Composable
private fun PlayButton(d: DeckUi, deck: Int, vm: DjViewModel) {
    Tap(
        Modifier.size(60.dp).clip(CircleShape).background(Color(0xFF111215))
            .border(2.dp, if (d.playing) VBlue else Color(0xFF55585F), CircleShape),
        onPress = { vm.button("play", deck, 0, true) }
    ) {
        Icon(
            if (d.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
            tint = VText, modifier = Modifier.size(34.dp)
        )
    }
}

@Composable
private fun SetGroup(deck: Int, vm: DjViewModel) {
    Row(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(10.dp)).background(VButton)
            .border(1.5.dp, VEdge, RoundedCornerShape(10.dp))
    ) {
        Tap(Modifier.weight(1f).fillMaxHeight(), onPress = { vm.setCueHere(deck) }) {
            Text("SET", color = VText, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.width(1.5.dp).fillMaxHeight().background(VEdge))
        Tap(
            Modifier.weight(1f).fillMaxHeight(),
            onPress = { vm.button("cue", deck, 0, true) },
            onRelease = { vm.button("cue", deck, 0, false) }
        ) {
            Icon(Icons.Filled.Replay, null, tint = VText, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun PflCircle(d: DeckUi, deck: Int, vm: DjViewModel) {
    Tap(
        Modifier.size(42.dp).clip(CircleShape)
            .background(if (d.pfl) VBlue.copy(alpha = 0.25f) else Color(0xFF1B1C20))
            .border(1.5.dp, if (d.pfl) VBlue else VEdge, CircleShape),
        onPress = { vm.button("pfl", deck, 0, true) }
    ) {
        Icon(Icons.Filled.Headphones, null, tint = if (d.pfl) VBlue else VText, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun CrossFader(value: Float, onChange: (Float) -> Unit, modifier: Modifier) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectDragGestures(onDragStart = { o -> cb(crossVal(o.x, size.width.toFloat())) }) { change, _ ->
                    change.consume()
                    cb(crossVal(change.position.x, size.width.toFloat()))
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o -> cb(crossVal(o.x, size.width.toFloat())) })
            }
    ) {
        val w = size.width
        val h = size.height
        val cy = h / 2f
        val pad = 22f
        for (i in 0..6) {
            val x = pad + (w - 2 * pad) * i / 6f
            drawLine(Color(0xFF3A3D45), Offset(x, cy - h * 0.32f), Offset(x, cy + h * 0.32f), strokeWidth = 2f)
        }
        drawLine(Color(0xFF0E0F11), Offset(pad, cy), Offset(w - pad, cy), strokeWidth = 8f, cap = StrokeCap.Round)
        val x = pad + (w - 2 * pad) * value
        drawRoundRect(Color(0xFFE7E8EC), Offset(x - 16f, 3f), Size(32f, h - 6f), CornerRadius(10f, 10f))
        drawLine(Color(0xFF50535B), Offset(x, 12f), Offset(x, h - 12f), strokeWidth = 3f, cap = StrokeCap.Round)
    }
}

private fun crossVal(x: Float, w: Float): Float = ((x - 22f) / (w - 44f)).coerceIn(0f, 1f)

// ------------------------------------------------------------------ mezclador del deck

@Composable
private fun MixerPopup(d: DeckUi, deck: Int, vm: DjViewModel, color: Color, onClose: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000)).pointerInput(Unit) { detectTapGestures { onClose() } },
        contentAlignment = Alignment.Center
    ) {
        Row(
            Modifier.clip(RoundedCornerShape(14.dp)).background(VPanel).border(1.dp, VEdge, RoundedCornerShape(14.dp))
                .padding(14.dp).pointerInput(Unit) { detectTapGestures { } },
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Knob(d.gain, { vm.knob("gain", deck, it) }, "GAIN", color, size = 44.dp)
            Knob(d.eqHigh, { vm.knob("eqHigh", deck, it) }, "HI", color, size = 44.dp, center = true)
            Knob(d.eqMid, { vm.knob("eqMid", deck, it) }, "MID", color, size = 44.dp, center = true)
            Knob(d.eqLow, { vm.knob("eqLow", deck, it) }, "LOW", color, size = 44.dp, center = true)
            Knob(d.filter, { vm.knob("filter", deck, it) }, "FILTER", color, size = 44.dp, center = true)
            VuMeter(d.level, Modifier.width(8.dp).height(150.dp))
            Fader(
                value = d.volume, onChange = { vm.knob("volume", deck, it) },
                modifier = Modifier.width(36.dp).height(150.dp), vertical = true, color = color
            )
        }
    }
}
