package app.inpulsedj.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import kotlin.math.max

/** Hilo de audio: pide bloques al DjEngine y los escribe en un AudioTrack float de baja latencia. */
class AudioOutput(private val ctx: android.content.Context, private val engine: DjEngine, private val block: Int) {
    /** Descripcion de la salida activa, para mostrarla en Ajustes. */
    @Volatile var description = "Salida estereo"

    private fun findMultiChannelUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            val usb = d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE ||
                d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
            if (usb && d.channelCounts.any { it >= 4 }) return d
        }
        return null
    }

    private fun findBluetooth(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET) ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_SPEAKER)
            ) return d
        }
        return null
    }

    private fun findAnyUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET) return d
        }
        return null
    }

    private fun buildTrack(sr: Int, quad: Boolean, dev: android.media.AudioDeviceInfo?, lowLatency: Boolean = true, extraBlocks: Int = 3): AudioTrack {
        val mask = if (quad) AudioFormat.CHANNEL_OUT_QUAD else AudioFormat.CHANNEL_OUT_STEREO
        val ch = if (quad) 4 else 2
        val minBuf = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_FLOAT)
        val bufBytes = max(minBuf, block * ch * 4 * extraBlocks)
        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .setChannelMask(mask)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
        if (Build.VERSION.SDK_INT >= 26) {
            builder.setPerformanceMode(if (lowLatency) AudioTrack.PERFORMANCE_MODE_LOW_LATENCY else AudioTrack.PERFORMANCE_MODE_NONE)
        }
        val t = builder.build()
        if (dev != null && Build.VERSION.SDK_INT >= 23) t.setPreferredDevice(dev)
        return t
    }

    @Volatile private var running = false
    private var thread: Thread? = null

    private var devCb: android.media.AudioDeviceCallback? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var startedAt = 0L
    private val restartTask = Runnable {
        if (running) {
            stopThread()
            startThread()
        }
    }

    @Volatile private var gen = 0
    private fun alive(g: Int) = running && gen == g

    private fun startThread() {
        running = true
        val g = ++gen
        val t = Thread({ loop(g) }, "dj-audio")
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    private fun stopThread() {
        running = false
        thread?.join(1200)
        thread = null
    }

    fun start() {
        if (running) return
        startedAt = System.currentTimeMillis()
        startThread()
        // si se conecta o desconecta Bluetooth / USB, se vuelve a elegir la salida
        if (Build.VERSION.SDK_INT >= 23 && devCb == null) {
            val am = ctx.getSystemService(android.media.AudioManager::class.java)
            val cb = object : android.media.AudioDeviceCallback() {
                private fun changed() {
                    if (System.currentTimeMillis() - startedAt < 2500) return
                    main.removeCallbacks(restartTask)
                    main.postDelayed(restartTask, 900)
                }
                override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
                override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
            }
            devCb = cb
            am?.registerAudioDeviceCallback(cb, main)
        }
    }

    fun stop() {
        main.removeCallbacks(restartTask)
        if (Build.VERSION.SDK_INT >= 23) {
            devCb?.let { ctx.getSystemService(android.media.AudioManager::class.java)?.unregisterAudioDeviceCallback(it) }
        }
        devCb = null
        stopThread()
    }

    /** Copia del master hacia el altavoz Bluetooth en su propio hilo: nunca bloquea el audio principal (USB). */
    private inner class BtMirror(sr: Int, dev: android.media.AudioDeviceInfo, private val g: Int) {
        private val track: AudioTrack = buildTrack(sr, false, dev, lowLatency = false, extraBlocks = 10)
        private val free = java.util.concurrent.ArrayBlockingQueue<FloatArray>(12)
        private val filled = java.util.concurrent.ArrayBlockingQueue<FloatArray>(12)
        private val th: Thread

        init {
            repeat(12) { free.offer(FloatArray(block * 2)) }
            th = Thread({
                var playing = false
                while (alive(g)) {
                    val b = try { filled.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { null } ?: continue
                    val w = track.write(b, 0, b.size, AudioTrack.WRITE_BLOCKING)
                    free.offer(b)
                    if (w < 0) break
                    if (!playing && filled.size >= 2) {
                        try { track.play(); playing = true } catch (_: Exception) { break }
                    }
                }
            }, "dj-bt")
            th.start()
        }

        /** Se llama justo despues de mezclar un bloque. */
        fun push() {
            val b = free.poll() ?: return
            engine.copyMaster(b, block)
            if (!filled.offer(b)) free.offer(b)
        }

        fun close() {
            try { th.join(500) } catch (_: InterruptedException) {}
            try { track.stop() } catch (_: IllegalStateException) {}
            track.release()
        }
    }

    /** Comprueba por donde sale realmente el audio; si Android lo desvio del USB, vuelve a pedir el USB. */
    private fun checkRoute(tk: AudioTrack, usb: android.media.AudioDeviceInfo?, usbUsed: Boolean, label: String) {
        try {
            val r = tk.routedDevice
            val name = r?.productName?.toString() ?: "?"
            val isUsb = r != null && (r.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || r.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET)
            if (usbUsed && usb != null && !isUsb) tk.setPreferredDevice(usb)
            description = "$label [sale por: $name]"
        } catch (_: Exception) {
        }
    }

    private fun loop(g: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sr = engine.sampleRate
        val quadDev = findMultiChannelUsb()
        val usbDev = quadDev ?: findAnyUsb()
        val btDev = findBluetooth()
        var quad = false
        var usbUsed = false
        var track: AudioTrack? = null
        var label = "Salida estereo"
        // 1) tarjeta USB del controlador: master 1-2 y auriculares 3-4 (igual que antes de conectar el Bluetooth)
        if (quadDev != null) {
            try {
                val t = buildTrack(sr, true, quadDev)
                t.play()
                track = t
                quad = true
                usbUsed = true
                label = "USB 4 canales: master 1-2, auriculares 3-4"
            } catch (_: Exception) {
                track = null
            }
        }
        if (track == null && usbDev != null) {
            try {
                val t = buildTrack(sr, false, usbDev)
                t.play()
                track = t
                usbUsed = true
                label = "USB estereo"
            } catch (_: Exception) {
                track = null
            }
        }
        if (track == null) {
            track = buildTrack(sr, false, null)
            track.play()
        }
        // 2) Bluetooth: copia del master, sin tocar la ruta USB
        var mirror: BtMirror? = null
        if (usbUsed && btDev != null) {
            try {
                mirror = BtMirror(sr, btDev, g)
                label += " + copia a Bluetooth"
            } catch (_: Exception) {
                mirror = null
            }
        }
        description = label
        val tk: AudioTrack = track!!
        val buf = FloatArray(block * (if (quad) 4 else 2))
        var n = 0
        while (alive(g)) {
            if (++n == 60 && Build.VERSION.SDK_INT >= 23) checkRoute(tk, usbDev, usbUsed, label)
            if (quad) engine.renderBlock4(buf, block) else engine.renderBlock(buf, block)
            mirror?.push()
            val w = tk.write(buf, 0, buf.size, AudioTrack.WRITE_BLOCKING)
            if (w < 0) break
        }
        mirror?.close()
        try {
            tk.stop()
        } catch (_: IllegalStateException) {
        }
        tk.release()
    }
}
