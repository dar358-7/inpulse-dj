package app.inpulsedj.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DeckUi
import app.inpulsedj.DjUi
import app.inpulsedj.DjViewModel

/** Modo MIXER (como djay): dos discos, crossfader grande y mezcla automatica con emparejado de tempo y compas. */
@Composable
fun SimpleMixer(s: DjUi, vm: DjViewModel, modifier: Modifier) {
    val progress by vm.mixProgress.collectAsState()
    var fadeIdx by remember { mutableIntStateOf(1) }
    val fades = listOf(5, 10, 20, 30)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().height(86.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SimpleHeader(s.a, 0, vm, Pal.deckA, Modifier.weight(1f).fillMaxHeight())
            SimpleHeader(s.b, 1, vm, Pal.deckB, Modifier.weight(1f).fillMaxHeight())
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SimplePlatter(s.a, 0, vm, Pal.deckA, Modifier.weight(1f).fillMaxHeight())
            SimplePlatter(s.b, 1, vm, Pal.deckB, Modifier.weight(1f).fillMaxHeight())
        }
        // reproducir A | crossfader | reproducir B
        Row(
            Modifier.fillMaxWidth().height(52.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PressButton(if (s.a.playing) "II" else "PLAY", Modifier.width(90.dp).fillMaxHeight(), active = s.a.playing, color = Pal.deckA,
                onPress = { vm.button("play", 0, 0, true) })
            Fader(
                value = s.crossfader, onChange = { vm.knob("crossfader", -1, it) },
                modifier = Modifier.weight(1f).height(44.dp), vertical = false, color = Pal.text, centerMark = true
            )
            PressButton(if (s.b.playing) "II" else "PLAY", Modifier.width(90.dp).fillMaxHeight(), active = s.b.playing, color = Pal.deckB,
                onPress = { vm.button("play", 1, 0, true) })
        }
        // mezcla automatica
        Row(
            Modifier.fillMaxWidth().height(40.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PressButton(
                if (progress >= 0f) "MEZCLANDO ${(progress * 100).toInt()}%" else "EMPAREJAR Y MEZCLAR",
                Modifier.weight(1f).fillMaxHeight(), active = progress >= 0f, color = Pal.ok,
                onPress = { vm.mixNow(fades[fadeIdx].toDouble()) }
            )
            Text("DURACION", color = Pal.dim, fontSize = 9.sp)
            for (i in fades.indices) {
                PressButton("${fades[i]}s", Modifier.width(52.dp).fillMaxHeight(), active = fadeIdx == i, color = Pal.warn,
                    onPress = { fadeIdx = i })
            }
        }
    }
}

@Composable
private fun SimpleHeader(d: DeckUi, deck: Int, vm: DjViewModel, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(Pal.panel).padding(6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${"AB"[deck]}", color = color, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(
                if (d.loaded) d.title else "Sin pista", color = Pal.text, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
            )
            if (d.loaded) {
                Text("(${"%.0f".format(d.effBpm)})", color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(
                    "-" + fmtTime(d.durSec - d.posSec), color = Pal.text, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
        OverviewStrip(d, color, { vm.seekFraction(deck, it.toDouble()) }, Modifier.weight(1f).fillMaxWidth())
    }
}

@Composable
private fun SimplePlatter(d: DeckUi, deck: Int, vm: DjViewModel, color: Color, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Platter(
            angleDeg = d.platterDeg, color = color,
            progress = if (d.durSec > 0) (d.posSec / d.durSec).toFloat() else 0f,
            bpmText = if (d.loaded && d.effBpm > 0) "%.1f".format(d.effBpm) else "--",
            keyText = if (d.loaded && d.key.isNotEmpty()) app.inpulsedj.audio.KeyDetector.name(d.key) else "",
            pitchText = if (d.loaded) "%+.1f%%".format(d.tempoPct) else "",
            elapsedText = if (d.loaded) fmtTime2(d.posSec) else "--:--:--",
            remainText = if (d.loaded) "-" + fmtTime2(d.durSec - d.posSec) else "",
            onTouch = { vm.button("jogTouch", deck, 0, it) },
            onTicks = { vm.rel("jogScratch", deck, it) },
            modifier = Modifier.fillMaxHeight().fillMaxWidth()
        )
    }
}
