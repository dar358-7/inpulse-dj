package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

object Pal {
    /** true = skin modo dia (claro) */
    var day by androidx.compose.runtime.mutableStateOf(false)
    val bg get() = if (day) Color(0xFFE9EDF3) else Color(0xFF0A0C11)
    val panel get() = if (day) Color(0xFFF7F9FC) else Color(0xFF141821)
    val panel2 get() = if (day) Color(0xFFDDE3EC) else Color(0xFF1C2230)
    val track get() = if (day) Color(0xFFB9C2D0) else Color(0xFF2A3142)
    val text get() = if (day) Color(0xFF111827) else Color(0xFFE6EAF2)
    val dim get() = if (day) Color(0xFF5B6475) else Color(0xFF8B94A8)
    /** fondo de pocillos: faders, vumetros */
    val well get() = if (day) Color(0xFFCBD3DF) else Color(0xFF0E1118)
    val wellOff get() = if (day) Color(0xFFE3E8F0) else Color(0xFF1A202C)
    val deckA = Color(0xFF22D3EE)
    val deckB = Color(0xFF3B82F6)
    val ok = Color(0xFF34D399)
    val warn = Color(0xFFFBBF24)
    val red = Color(0xFFF87171)
    val hot = listOf(Color(0xFFF87171), Color(0xFFFBBF24), Color(0xFF34D399), Color(0xFF60A5FA))
}

/** Perilla rotativa: arrastre vertical, doble toque = valor por defecto. */
@Composable
fun Knob(
    value: Float, onChange: (Float) -> Unit, label: String, color: Color,
    size: Dp = 32.dp, center: Boolean = false, default: Float = 0.5f
) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(size)
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        cb((v - drag.y / 160f).coerceIn(0f, 1f))
                    }
                }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { cb(default) }) }
        ) {
            val stroke = this.size.minDimension * 0.13f
            val tl = Offset(stroke, stroke)
            val sz = Size(this.size.width - 2 * stroke, this.size.height - 2 * stroke)
            drawArc(Pal.track, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (center) {
                drawArc(color, 270f, 270f * (v - 0.5f), false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            } else {
                drawArc(color, 135f, 270f * v, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            val ang = (135f + 270f * v) * PI.toFloat() / 180f
            val c = Offset(this.size.width / 2, this.size.height / 2)
            val r = this.size.minDimension / 2 - stroke
            drawLine(
                Pal.text,
                Offset(c.x + cos(ang) * r * 0.3f, c.y + sin(ang) * r * 0.3f),
                Offset(c.x + cos(ang) * r * 0.9f, c.y + sin(ang) * r * 0.9f),
                strokeWidth = stroke * 0.7f, cap = StrokeCap.Round
            )
        }
        Text(label, color = Pal.dim, fontSize = 8.sp, lineHeight = 9.sp)
    }
}

/** Fader vertical u horizontal con arrastre absoluto. */
@Composable
fun Fader(
    value: Float, onChange: (Float) -> Unit, modifier: Modifier, vertical: Boolean,
    color: Color, centerMark: Boolean = false
) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o -> cb(posToValue(o, size.width.toFloat(), size.height.toFloat(), vertical)) }
                ) { change, _ ->
                    change.consume()
                    cb(posToValue(change.position, size.width.toFloat(), size.height.toFloat(), vertical))
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o -> cb(posToValue(o, size.width.toFloat(), size.height.toFloat(), vertical)) })
            }
    ) {
        val w = size.width
        val h = size.height
        if (vertical) {
            val cx = w / 2
            drawLine(Pal.track, Offset(cx, 6f), Offset(cx, h - 6f), strokeWidth = 5f, cap = StrokeCap.Round)
            if (centerMark) drawLine(Pal.dim, Offset(cx - 8f, h / 2), Offset(cx + 8f, h / 2), strokeWidth = 2f)
            val y = (h - 14f) * (1f - value) + 7f
            drawRect(Pal.well, Offset(cx - w * 0.42f, y - 8f), Size(w * 0.84f, 16f))
            drawRect(color, Offset(cx - w * 0.42f, y - 1.5f), Size(w * 0.84f, 3f))
        } else {
            val cy = h / 2
            drawLine(Pal.track, Offset(6f, cy), Offset(w - 6f, cy), strokeWidth = 5f, cap = StrokeCap.Round)
            if (centerMark) drawLine(Pal.dim, Offset(w / 2, cy - 8f), Offset(w / 2, cy + 8f), strokeWidth = 2f)
            val x = (w - 14f) * value + 7f
            drawRect(Pal.well, Offset(x - 8f, cy - h * 0.42f), Size(16f, h * 0.84f))
            drawRect(color, Offset(x - 1.5f, cy - h * 0.42f), Size(3f, h * 0.84f))
        }
    }
}

private fun posToValue(o: Offset, w: Float, h: Float, vertical: Boolean): Float =
    if (vertical) (1f - (o.y - 7f) / (h - 14f)).coerceIn(0f, 1f) else ((o.x - 7f) / (w - 14f)).coerceIn(0f, 1f)

/** Vúmetro vertical. */
@Composable
fun VuMeter(level: Float, modifier: Modifier) {
    Canvas(modifier.background(Pal.well)) {
        val segs = 14
        val gap = 2f
        val sh = (size.height - gap * (segs - 1)) / segs
        val lit = (level.coerceIn(0f, 1f) * segs).toInt()
        for (i in 0 until segs) {
            val y = size.height - (i + 1) * sh - i * gap
            val on = i < lit
            val c = when {
                i >= segs - 2 -> Pal.red
                i >= segs - 5 -> Pal.warn
                else -> Pal.ok
            }
            drawRect(if (on) c else Pal.wellOff, Offset(0f, y), Size(size.width, sh))
        }
    }
}

/** Boton con eventos de pulsar y soltar (cue, hot cues, rolls...). */
@Composable
fun PressButton(
    text: String, modifier: Modifier = Modifier, active: Boolean = false, color: Color = Pal.deckA,
    onPress: () -> Unit, onRelease: () -> Unit = {}
) {
    val p by rememberUpdatedState(onPress)
    val r by rememberUpdatedState(onRelease)
    Box(
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (active) color.copy(alpha = 0.9f) else Pal.panel2)
            .border(1.dp, if (active) color else Pal.track, RoundedCornerShape(6.dp))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    p()
                    tryAwaitRelease()
                    r()
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (active) Color.Black else Pal.text,
            fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

/** Plato estilo djay: arco de progreso, aguja que gira, BPM arriba, tono a la izquierda, pitch a la derecha, tiempo y restante abajo. */
@Composable
fun Platter(
    angleDeg: Float, color: Color, progress: Float, bpmText: String, keyText: String, pitchText: String,
    elapsedText: String, remainText: String,
    onTouch: (Boolean) -> Unit, onTicks: (Int) -> Unit, modifier: Modifier
) {
    val touchCb by rememberUpdatedState(onTouch)
    val tickCb by rememberUpdatedState(onTicks)
    androidx.compose.foundation.layout.BoxWithConstraints(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                down.consume()
                touchCb(true)
                fun angleOf(o: Offset): Float =
                    Math.toDegrees(
                        atan2((o.y - size.height / 2f).toDouble(), (o.x - size.width / 2f).toDouble())
                    ).toFloat()
                var last = angleOf(down.position)
                var rem = 0f
                while (true) {
                    val ev = awaitPointerEvent()
                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!c.pressed) {
                        c.consume()
                        break
                    }
                    val a = angleOf(c.position)
                    var d = a - last
                    if (d > 180f) d -= 360f
                    if (d < -180f) d += 360f
                    last = a
                    rem += d / 360f * 248f
                    val t = rem.toInt()
                    if (t != 0) {
                        tickCb(t)
                        rem -= t
                    }
                    c.consume()
                }
                touchCb(false)
            }
        },
        contentAlignment = Alignment.Center
    ) {
        val m = minOf(maxWidth, maxHeight).value
        val ink = Color(0xFFD6E4FF)
        val shadow = androidx.compose.ui.graphics.Shadow(Color.Black, Offset(2f, 2f), 4f)
        val serif = androidx.compose.ui.text.font.FontFamily.Serif
        Canvas(Modifier.matchParentSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = size.minDimension / 2
            drawCircle(Color(0xFF111113), r, c)
            val ringR = r * 0.94f
            val st = r * 0.07f
            val tl = Offset(c.x - ringR, c.y - ringR)
            val sz = Size(ringR * 2, ringR * 2)
            drawArc(Color(0xFF3A3A3C), 0f, 360f, false, tl, sz, style = Stroke(st))
            drawArc(color, -90f, 360f * progress.coerceIn(0f, 1f), false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
            // aguja que gira
            rotate(angleDeg, c) {
                drawLine(color, Offset(c.x, c.y - r * 0.26f), Offset(c.x, c.y - r * 0.86f), strokeWidth = r * 0.06f, cap = StrokeCap.Round)
            }
            // buje central
            drawCircle(Color(0xFF444446), r * 0.26f, c)
            drawCircle(color, r * 0.26f, c, style = Stroke(r * 0.025f))
            drawCircle(color, r * 0.065f, c)
        }
        Text(
            bpmText, color = ink, fontFamily = serif, fontWeight = FontWeight.Bold,
            fontSize = (m * 0.115f).sp,
            style = androidx.compose.ui.text.TextStyle(shadow = shadow),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = (m * 0.15f).dp)
        )
        Text(
            keyText, color = ink, fontFamily = serif, fontSize = (m * 0.085f).sp,
            style = androidx.compose.ui.text.TextStyle(shadow = shadow),
            modifier = Modifier.align(Alignment.CenterStart).padding(start = (m * 0.07f).dp)
        )
        Text(
            pitchText, color = ink, fontFamily = serif, fontSize = (m * 0.085f).sp,
            style = androidx.compose.ui.text.TextStyle(shadow = shadow),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = (m * 0.07f).dp)
        )
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = (m * 0.14f).dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                elapsedText, color = ink, fontFamily = serif, fontWeight = FontWeight.Bold,
                fontSize = (m * 0.095f).sp, style = androidx.compose.ui.text.TextStyle(shadow = shadow)
            )
            Text(
                remainText, color = ink, fontFamily = serif, fontWeight = FontWeight.Bold,
                fontSize = (m * 0.095f).sp, style = androidx.compose.ui.text.TextStyle(shadow = shadow)
            )
        }
    }
}
