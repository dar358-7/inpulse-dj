package app.inpulsedj.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.R

/** Nombre de la app: texto blanco liso, sin sombra. */
@Composable
fun Text3D(text: String, fontSize: TextUnit, modifier: Modifier = Modifier, depth: Int = 0) {
    Text(
        text, color = Color.White, fontSize = fontSize, fontWeight = FontWeight.Black,
        modifier = modifier
    )
}

@Composable
fun LogoMark(size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.logo_mark), contentDescription = "Darvis",
        modifier = modifier.size(size)
    )
}

/** Pantalla de bienvenida con el logotipo y el nombre en 3D. */
@Composable
fun SplashOverlay() {
    Box(Modifier.fillMaxSize().background(Color(0xFF171E31)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.logo_darvis), contentDescription = "Darvis Live DJ App",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxHeight(0.62f)
            )
            Text3D("INPULSE DJ", 30.sp, depth = 8)
            Text3D("BY DARVI'S", 18.sp, depth = 6, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
