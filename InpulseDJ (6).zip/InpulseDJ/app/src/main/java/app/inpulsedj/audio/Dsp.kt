package app.inpulsedj.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/** Biquad RBJ (doble precision, un canal). */
class Biquad {
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    fun process(x: Float): Float {
        val xd = x.toDouble()
        val y = b0 * xd + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1
        x1 = xd
        y2 = y1
        y1 = y
        return y.toFloat()
    }

    fun reset() {
        x1 = 0.0; x2 = 0.0; y1 = 0.0; y2 = 0.0
    }

    private fun set(nb0: Double, nb1: Double, nb2: Double, a0: Double, na1: Double, na2: Double) {
        b0 = nb0 / a0
        b1 = nb1 / a0
        b2 = nb2 / a0
        a1 = na1 / a0
        a2 = na2 / a0
    }

    fun lowShelf(sr: Double, f: Double, db: Double) {
        val a = 10.0.pow(db / 40.0)
        val w0 = 2.0 * PI * f / sr
        val cs = cos(w0)
        val sn = sin(w0)
        val alpha = sn / 2.0 * sqrt(2.0)
        val sq = 2.0 * sqrt(a) * alpha
        set(
            a * ((a + 1) - (a - 1) * cs + sq),
            2 * a * ((a - 1) - (a + 1) * cs),
            a * ((a + 1) - (a - 1) * cs - sq),
            (a + 1) + (a - 1) * cs + sq,
            -2 * ((a - 1) + (a + 1) * cs),
            (a + 1) + (a - 1) * cs - sq
        )
    }

    fun highShelf(sr: Double, f: Double, db: Double) {
        val a = 10.0.pow(db / 40.0)
        val w0 = 2.0 * PI * f / sr
        val cs = cos(w0)
        val sn = sin(w0)
        val alpha = sn / 2.0 * sqrt(2.0)
        val sq = 2.0 * sqrt(a) * alpha
        set(
            a * ((a + 1) + (a - 1) * cs + sq),
            -2 * a * ((a - 1) + (a + 1) * cs),
            a * ((a + 1) + (a - 1) * cs - sq),
            (a + 1) - (a - 1) * cs + sq,
            2 * ((a - 1) - (a + 1) * cs),
            (a + 1) - (a - 1) * cs - sq
        )
    }

    fun peaking(sr: Double, f: Double, q: Double, db: Double) {
        val a = 10.0.pow(db / 40.0)
        val w0 = 2.0 * PI * f / sr
        val cs = cos(w0)
        val alpha = sin(w0) / (2.0 * q)
        set(
            1 + alpha * a, -2 * cs, 1 - alpha * a,
            1 + alpha / a, -2 * cs, 1 - alpha / a
        )
    }

    fun lowPass(sr: Double, f: Double, q: Double) {
        val w0 = 2.0 * PI * f / sr
        val cs = cos(w0)
        val alpha = sin(w0) / (2.0 * q)
        set((1 - cs) / 2, 1 - cs, (1 - cs) / 2, 1 + alpha, -2 * cs, 1 - alpha)
    }

    fun highPass(sr: Double, f: Double, q: Double) {
        val w0 = 2.0 * PI * f / sr
        val cs = cos(w0)
        val alpha = sin(w0) / (2.0 * q)
        set((1 + cs) / 2, -(1 + cs), (1 + cs) / 2, 1 + alpha, -2 * cs, 1 - alpha)
    }
}

/** EQ de 3 bandas (graves / medios / agudos). Valor 0..1, 0.5 = plano. */
class Eq3(private val sr: Double) {
    private val lo = arrayOf(Biquad(), Biquad())
    private val mi = arrayOf(Biquad(), Biquad())
    private val hi = arrayOf(Biquad(), Biquad())

    @Volatile var low = 0.5f
    @Volatile var mid = 0.5f
    @Volatile var high = 0.5f

    private var cl = -1f
    private var cm = -1f
    private var ch = -1f

    fun process(buf: FloatArray, frames: Int) {
        val l = low
        val m = mid
        val h = high
        if (l != cl) {
            val db = knobToDb(l)
            for (b in lo) b.lowShelf(sr, 200.0, db)
            cl = l
        }
        if (m != cm) {
            val db = knobToDb(m)
            for (b in mi) b.peaking(sr, 1000.0, 0.7, db)
            cm = m
        }
        if (h != ch) {
            val db = knobToDb(h)
            for (b in hi) b.highShelf(sr, 3500.0, db)
            ch = h
        }
        for (i in 0 until frames) {
            val j = i * 2
            buf[j] = hi[0].process(mi[0].process(lo[0].process(buf[j])))
            buf[j + 1] = hi[1].process(mi[1].process(lo[1].process(buf[j + 1])))
        }
    }

    companion object {
        fun knobToDb(v: Float): Double {
            val x = v.coerceIn(0f, 1f).toDouble()
            return if (x < 0.5) -40.0 * (1.0 - 2.0 * x).pow(1.5) else 6.0 * (2.0 * x - 1.0)
        }
    }
}

/** Filtro DJ de una perilla: izquierda = pasa-bajos, derecha = pasa-altos, centro = bypass. */
class DjFilter(private val sr: Double) {
    private val f = arrayOf(Biquad(), Biquad())

    @Volatile var value = 0.5f
    private var cur = -1f
    private var mode = 0 // 0 bypass, 1 LP, 2 HP

    fun process(buf: FloatArray, frames: Int) {
        val v = value
        if (abs(v - 0.5f) < 0.03f) {
            if (mode != 0) {
                for (b in f) b.reset()
                mode = 0
                cur = -1f
            }
            return
        }
        if (v != cur) {
            val newMode: Int
            if (v < 0.5f) {
                val x = ((0.47f - v) / 0.47f).coerceIn(0f, 1f).toDouble()
                val fc = min(20000.0 * (250.0 / 20000.0).pow(x), sr * 0.45)
                for (b in f) b.lowPass(sr, fc, 1.1)
                newMode = 1
            } else {
                val x = ((v - 0.53f) / 0.47f).coerceIn(0f, 1f).toDouble()
                val fc = min(20.0 * (9000.0 / 20.0).pow(x), sr * 0.45)
                for (b in f) b.highPass(sr, fc, 1.1)
                newMode = 2
            }
            if (newMode != mode) for (b in f) b.reset()
            mode = newMode
            cur = v
        }
        for (i in 0 until frames) {
            val j = i * 2
            buf[j] = f[0].process(buf[j])
            buf[j + 1] = f[1].process(buf[j + 1])
        }
    }
}

interface Fx {
    var enabled: Boolean
    fun process(buf: FloatArray, frames: Int)
}

/** Eco sincronizado al tempo (corchea con puntillo). */
class EchoFx(private val sr: Int) : Fx {
    @Volatile override var enabled = false
    @Volatile var beatSeconds = 0.5

    private val n = sr * 3
    private val bl = FloatArray(n)
    private val br = FloatArray(n)
    private var w = 0
    private var inGain = 0f

    override fun process(buf: FloatArray, frames: Int) {
        val target = if (enabled) 1f else 0f
        val delay = (beatSeconds * 0.75 * sr).toInt().coerceIn(2000, n - 1)
        val fb = 0.5f
        for (i in 0 until frames) {
            inGain += (target - inGain) * 0.002f
            val r = (w - delay + n) % n
            val dl = bl[r]
            val dr = br[r]
            val l = buf[2 * i]
            val rr = buf[2 * i + 1]
            bl[w] = l * inGain + dl * fb
            br[w] = rr * inGain + dr * fb
            buf[2 * i] = l + dl * 0.6f
            buf[2 * i + 1] = rr + dr * 0.6f
            w++
            if (w >= n) w = 0
        }
    }
}

class FlangerFx(private val sr: Int) : Fx {
    @Volatile override var enabled = false

    private val n = 2048
    private val bl = FloatArray(n)
    private val br = FloatArray(n)
    private var w = 0
    private var phase = 0.0
    private var amount = 0f

    override fun process(buf: FloatArray, frames: Int) {
        val target = if (enabled) 1f else 0f
        val inc = 2.0 * PI * 0.25 / sr
        for (i in 0 until frames) {
            amount += (target - amount) * 0.001f
            val lfo = 0.5 + 0.5 * sin(phase)
            phase += inc
            if (phase > 2.0 * PI) phase -= 2.0 * PI
            val d = sr * (0.001 + 0.005 * lfo)
            val rp = w - d
            val i0f = floor(rp)
            val frac = (rp - i0f).toFloat()
            val i0 = ((i0f.toInt() % n) + n) % n
            val i1 = (i0 + 1) % n
            val wl = bl[i0] + (bl[i1] - bl[i0]) * frac
            val wr = br[i0] + (br[i1] - br[i0]) * frac
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            bl[w] = l + wl * 0.5f
            br[w] = r + wr * 0.5f
            buf[2 * i] = l * (1f - 0.25f * amount) + wl * 0.85f * amount
            buf[2 * i + 1] = r * (1f - 0.25f * amount) + wr * 0.85f * amount
            w++
            if (w >= n) w = 0
        }
    }
}

class ReverbFx(sr: Int) : Fx {
    @Volatile override var enabled = false

    private class Comb(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        private var filt = 0f
        fun process(x: Float, fb: Float, damp: Float): Float {
            val out = buf[idx]
            filt = out * (1f - damp) + filt * damp
            buf[idx] = x + filt * fb
            idx++
            if (idx >= buf.size) idx = 0
            return out
        }
    }

    private class Allpass(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        fun process(x: Float): Float {
            val b = buf[idx]
            val out = -x + b
            buf[idx] = x + b * 0.5f
            idx++
            if (idx >= buf.size) idx = 0
            return out
        }
    }

    private val scale = sr / 44100.0
    private val tunings = intArrayOf(1116, 1188, 1277, 1356)
    private val combL = Array(4) { Comb((tunings[it] * scale).toInt()) }
    private val combR = Array(4) { Comb(((tunings[it] + 23) * scale).toInt()) }
    private val apL = arrayOf(Allpass((556 * scale).toInt()), Allpass((441 * scale).toInt()))
    private val apR = arrayOf(Allpass(((556 + 23) * scale).toInt()), Allpass(((441 + 23) * scale).toInt()))
    private var inGain = 0f

    override fun process(buf: FloatArray, frames: Int) {
        val target = if (enabled) 1f else 0f
        for (i in 0 until frames) {
            inGain += (target - inGain) * 0.002f
            val l = buf[2 * i]
            val r = buf[2 * i + 1]
            val x = (l + r) * 0.5f * inGain * 0.35f
            var wl = 0f
            var wr = 0f
            for (c in combL) wl += c.process(x, 0.84f, 0.2f)
            for (c in combR) wr += c.process(x, 0.84f, 0.2f)
            wl *= 0.25f
            wr *= 0.25f
            for (a in apL) wl = a.process(wl)
            for (a in apR) wr = a.process(wr)
            buf[2 * i] = l + wl * 1.6f
            buf[2 * i + 1] = r + wr * 1.6f
        }
    }
}

/** Limitador suave: transparente por debajo de 0.8, tanh por encima. */
fun softClip(x: Float): Float {
    val a = abs(x)
    if (a < 0.8f) return x
    val s = 0.8f + 0.2f * tanh((a - 0.8f) / 0.2f)
    return if (x < 0f) -s else s
}


/**
 * Limitador con anticipacion (1,5 ms): baja la ganancia un poco antes del pico en lugar de recortarlo.
 * Asi un master fuerte suena limpio (el recorte con tanh distorsiona) y los picos nunca pasan de 1.
 */
class Limiter(sr: Int, private val thr: Float = 0.92f) {
    private val n = 72
    private val dl = FloatArray(n)
    private val dr = FloatArray(n)
    private val req = FloatArray(n) { 1f }
    private var w = 0
    private var g = 1f
    private val relK = (1.0 - exp(-1.0 / (0.12 * sr))).toFloat()
    private val atkK = (1.0 - exp(-3.0 / n)).toFloat()

    fun process(l: FloatArray, r: FloatArray, frames: Int) {
        for (i in 0 until frames) {
            val inL = l[i]
            val inR = r[i]
            val pk = max(abs(inL), abs(inR))
            req[w] = if (pk > thr) thr / pk else 1f
            val oL = dl[w]
            val oR = dr[w]
            dl[w] = inL
            dr[w] = inR
            w = if (w + 1 == n) 0 else w + 1
            var mn = 1f
            for (k in 0 until n) if (req[k] < mn) mn = req[k]
            g += if (mn < g) (mn - g) * atkK else (mn - g) * relK
            val a = oL * g
            val b = oR * g
            l[i] = if (a > 1f) 1f else if (a < -1f) -1f else a
            r[i] = if (b > 1f) 1f else if (b < -1f) -1f else b
        }
    }
}
