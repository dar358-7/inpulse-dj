package app.inpulsedj.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import kotlin.math.max

/** Hilo de audio: pide bloques al DjEngine y los escribe en un AudioTrack float de baja latencia. */
class AudioOutput(private val ctx: android.content.Context, private val engine: DjEngine, private val block: Int) {
    /** Descripcion de la salida activa, para mostrarla en Ajustes. */
    @Volatile var description = "Salida estereo"

    private fun findMultiChannelUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            val usb = d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE ||
                d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
            if (usb && d.channelCounts.any { it >= 4 }) return d
        }
        return null
    }

    private fun findBluetooth(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET) ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_SPEAKER)
            ) return d
        }
        return null
    }

    private fun findAnyUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET) return d
        }
        return null
    }

    /** Altavoz Bluetooth = master; auriculares del controlador (USB) = pre-escucha. Dos pistas, cada una a su dispositivo. */
    private fun runDual(g: Int, sr: Int, usb: android.media.AudioDeviceInfo, bt: android.media.AudioDeviceInfo): Boolean {
        val quad = usb.channelCounts.any { it >= 4 }
        val mt: AudioTrack
        val ct: AudioTrack
        try {
            mt = buildTrack(sr, false, bt)
            ct = buildTrack(sr, quad, usb)
            mt.play()
            ct.play()
        } catch (_: Exception) {
            return false
        }
        description = if (quad) "Bluetooth master + USB 3-4 auriculares" else "Bluetooth master + USB auriculares"
        val q = java.util.concurrent.ArrayBlockingQueue<FloatArray>(6)
        val cueThread = Thread({
            while (alive(g)) {
                val b = try { q.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { null } ?: continue
                if (ct.write(b, 0, b.size, AudioTrack.WRITE_BLOCKING) < 0) break
            }
        }, "dj-cue")
        cueThread.start()
        val m = FloatArray(block * 2)
        val c = FloatArray(block * 2)
        while (alive(g)) {
            engine.renderSplit(m, c, block)
            if (mt.write(m, 0, m.size, AudioTrack.WRITE_BLOCKING) < 0) break
            val out = if (quad) FloatArray(block * 4) else FloatArray(block * 2)
            if (quad) {
                for (i in 0 until block) {
                    out[i * 4 + 2] = c[i * 2]
                    out[i * 4 + 3] = c[i * 2 + 1]
                }
            } else {
                System.arraycopy(c, 0, out, 0, block * 2)
            }
            if (!q.offer(out)) {
                q.poll()
                q.offer(out)
            }
        }
        try { cueThread.join(500) } catch (_: InterruptedException) {}
        try { mt.stop() } catch (_: IllegalStateException) {}
        try { ct.stop() } catch (_: IllegalStateException) {}
        mt.release()
        ct.release()
        return true
    }

    private fun buildTrack(sr: Int, quad: Boolean, dev: android.media.AudioDeviceInfo?): AudioTrack {
        val mask = if (quad) AudioFormat.CHANNEL_OUT_QUAD else AudioFormat.CHANNEL_OUT_STEREO
        val ch = if (quad) 4 else 2
        val minBuf = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_FLOAT)
        val bufBytes = max(minBuf, block * ch * 4 * 3)
        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .setChannelMask(mask)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
        if (Build.VERSION.SDK_INT >= 26) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }
        val t = builder.build()
        if (dev != null && Build.VERSION.SDK_INT >= 23) t.setPreferredDevice(dev)
        return t
    }

    @Volatile private var running = false
    private var thread: Thread? = null

    private var devCb: android.media.AudioDeviceCallback? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var startedAt = 0L
    private val restartTask = Runnable {
        if (running) {
            stopThread()
            startThread()
        }
    }

    @Volatile private var gen = 0
    private fun alive(g: Int) = running && gen == g

    private fun startThread() {
        running = true
        val g = ++gen
        val t = Thread({ loop(g) }, "dj-audio")
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    private fun stopThread() {
        running = false
        thread?.join(1200)
        thread = null
    }

    fun start() {
        if (running) return
        startedAt = System.currentTimeMillis()
        startThread()
        // si se conecta o desconecta Bluetooth / USB, se vuelve a elegir la salida
        if (Build.VERSION.SDK_INT >= 23 && devCb == null) {
            val am = ctx.getSystemService(android.media.AudioManager::class.java)
            val cb = object : android.media.AudioDeviceCallback() {
                private fun changed() {
                    if (System.currentTimeMillis() - startedAt < 2500) return
                    main.removeCallbacks(restartTask)
                    main.postDelayed(restartTask, 900)
                }
                override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
                override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
            }
            devCb = cb
            am?.registerAudioDeviceCallback(cb, main)
        }
    }

    fun stop() {
        main.removeCallbacks(restartTask)
        if (Build.VERSION.SDK_INT >= 23) {
            devCb?.let { ctx.getSystemService(android.media.AudioManager::class.java)?.unregisterAudioDeviceCallback(it) }
        }
        devCb = null
        stopThread()
    }

    private fun loop(g: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sr = engine.sampleRate
        val anyUsb = findAnyUsb()
        val bt = findBluetooth()
        if (anyUsb != null && bt != null) {
            if (runDual(g, sr, anyUsb, bt)) return
        }
        var quad = false
        var track: AudioTrack? = null
        val dev = findMultiChannelUsb()
        if (dev != null) {
            try {
                val t = buildTrack(sr, true, dev)
                t.play()
                track = t
                quad = true
                description = "USB 4 canales: master 1-2, auriculares 3-4"
            } catch (_: Exception) {
                track = null
            }
        }
        if (track == null) {
            track = buildTrack(sr, false, null)
            track.play()
            description = "Salida estereo"
        }
        val tk: AudioTrack = track!!
        val buf = FloatArray(block * (if (quad) 4 else 2))
        while (alive(g)) {
            if (quad) engine.renderBlock4(buf, block) else engine.renderBlock(buf, block)
            val w = tk.write(buf, 0, buf.size, AudioTrack.WRITE_BLOCKING)
            if (w < 0) break
        }
        try {
            tk.stop()
        } catch (_: IllegalStateException) {
        }
        tk.release()
    }
}
