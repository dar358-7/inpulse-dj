package app.inpulsedj.audio

import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin

/**
 * Key Lock / Master Tempo: desplazador de tono granular de dos tomas con ventana sin².
 * Recibe audio ya reproducido con varispeed (tono * s) y lo devuelve a su tono original.
 * Siempre introduce una latencia fija de g/2 muestras (incluso en bypass) para que
 * dos decks con key lock queden alineados entre si.
 */
class KeyLockShifter(private val g: Int = 2048) {
    private val size = 8192
    private val mask = size - 1
    private val bl = FloatArray(size)
    private val br = FloatArray(size)
    private var wp = 0
    private var ph = 0.0
    private var m = 0f

    val latencyFrames: Int get() = g / 2

    fun process(out: FloatArray, frames: Int, ratio: Double, active: Boolean) {
        val target = if (active) 1f else 0f
        val dm = 1f / 1024f
        val dph = (1.0 - ratio) / g
        val half = g / 2
        for (i in 0 until frames) {
            val j = i * 2
            bl[wp] = out[j]
            br[wp] = out[j + 1]
            val di = (wp - half) and mask
            var l = bl[di]
            var r = br[di]
            if (m < target) m = minOf(target, m + dm) else if (m > target) m = maxOf(target, m - dm)
            if (m > 0f) {
                ph += dph
                ph -= floor(ph)
                val s1 = sin(PI * ph)
                val w1 = (s1 * s1).toFloat()
                val w2 = 1f - w1
                val p2 = (ph + 0.5) % 1.0
                val a = tap(bl, ph * g)
                val b = tap(bl, p2 * g)
                val c = tap(br, ph * g)
                val d = tap(br, p2 * g)
                val wl = a * w1 + b * w2
                val wr = c * w1 + d * w2
                l = l * (1f - m) + wl * m
                r = r * (1f - m) + wr * m
            }
            out[j] = l
            out[j + 1] = r
            wp = (wp + 1) and mask
        }
    }

    private fun tap(buf: FloatArray, delay: Double): Float {
        val pos = wp - delay
        val f = floor(pos)
        val fr = (pos - f).toFloat()
        val i0 = f.toInt() and mask
        val i1 = (i0 + 1) and mask
        return buf[i0] + (buf[i1] - buf[i0]) * fr
    }
}
