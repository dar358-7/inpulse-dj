package app.inpulsedj.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Detector de tonalidad (chroma por Goertzel + perfiles de Krumhansl).
 * Devuelve el codigo Camelot ("8A" = La menor, "8B" = Do mayor), como en Rekordbox/Traktor.
 */
object KeyDetector {
    private val major = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val minor = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
    private val camMajor = intArrayOf(8, 3, 10, 5, 12, 7, 2, 9, 4, 11, 6, 1)
    private val camMinor = intArrayOf(5, 12, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10)

    private val minorNames = arrayOf("G#m", "D#m", "A#m", "Fm", "Cm", "Gm", "Dm", "Am", "Em", "Bm", "F#m", "C#m")
    private val majorNames = arrayOf("B", "F#", "Db", "Ab", "Eb", "Bb", "F", "C", "G", "D", "A", "E")

    /** "8A" -> "Am". */
    fun name(code: String): String {
        if (code.length < 2) return ""
        val n = code.dropLast(1).toIntOrNull() ?: return ""
        if (n !in 1..12) return ""
        return if (code.last() == 'A') minorNames[n - 1] else majorNames[n - 1]
    }

    fun analyze(pcm: ShortArray, frames: Int, sr: Int): String? {
        val dur = frames.toDouble() / sr
        if (dur < 10.0) return null
        val dec = max(1, sr / 11025)
        val sr2 = sr.toDouble() / dec
        val startSec = min(30.0, dur * 0.25)
        val lenSec = min(45.0, dur - startSec - 1.0)
        val start = (startSec * sr).toInt()
        val n2 = (lenSec * sr / dec).toInt()
        val N = 8192
        if (n2 < N * 4) return null
        val mono = FloatArray(n2)
        for (i in 0 until n2) {
            var s = 0f
            for (k in 0 until dec) {
                val j = (start + i * dec + k) * 2
                s += pcm[j] + pcm[j + 1]
            }
            mono[i] = s / (dec * 2f * 32768f)
        }
        val win = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / (N - 1))).toFloat() }
        val notes = 60 // C2..B6
        val coef = DoubleArray(notes) { 2.0 * cos(2.0 * PI * (440.0 * 2.0.pow((36 + it - 69) / 12.0)) / sr2) }
        val chroma = DoubleArray(12)
        val buf = FloatArray(N)
        var pos = 0
        while (pos + N <= n2) {
            for (i in 0 until N) buf[i] = mono[pos + i] * win[i]
            for (m in 0 until notes) {
                val c = coef[m]
                var s1 = 0.0
                var s2 = 0.0
                for (i in 0 until N) {
                    val s0 = buf[i] + c * s1 - s2
                    s2 = s1
                    s1 = s0
                }
                val p = s1 * s1 + s2 * s2 - c * s1 * s2
                chroma[(36 + m) % 12] += sqrt(max(0.0, p))
            }
            pos += N
        }
        val total = chroma.sum()
        if (total <= 1e-9) return null
        var best = -2.0
        var bestKey = 0
        var bestMinor = false
        for (tonic in 0 until 12) {
            for (isMinor in booleanArrayOf(false, true)) {
                val prof = if (isMinor) minor else major
                val r = corr(chroma, prof, tonic)
                if (r > best) {
                    best = r
                    bestKey = tonic
                    bestMinor = isMinor
                }
            }
        }
        val num = if (bestMinor) camMinor[bestKey] else camMajor[bestKey]
        return "$num${if (bestMinor) "A" else "B"}"
    }

    private fun corr(chroma: DoubleArray, prof: DoubleArray, tonic: Int): Double {
        var mx = 0.0
        var my = 0.0
        for (i in 0 until 12) { mx += chroma[i]; my += prof[i] }
        mx /= 12; my /= 12
        var sxy = 0.0
        var sxx = 0.0
        var syy = 0.0
        for (i in 0 until 12) {
            val x = chroma[(i + tonic) % 12] - mx
            val y = prof[i] - my
            sxy += x * y; sxx += x * x; syy += y * y
        }
        return if (sxx <= 0 || syy <= 0) 0.0 else sxy / sqrt(sxx * syy)
    }
}
