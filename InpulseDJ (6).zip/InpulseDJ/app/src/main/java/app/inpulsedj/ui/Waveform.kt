package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import app.inpulsedj.DeckUi
import app.inpulsedj.audio.PEAKS_PER_SEC
import kotlin.math.ceil
import kotlin.math.floor

/** Onda desplazable (ventana de 8 s) con rejilla de tiempos, hot cues, loop y cabezal central. */
@Composable
fun WaveStrip(d: DeckUi, color: Color, modifier: Modifier, window: Double = 6.0, onTap: () -> Unit = {}) {
    val peakMax = remember(d.peaks) {
        var m = 0.05f
        d.peaks?.let { for (v in it) if (v > m) m = v }
        m
    }
    val colors = remember(d.bands, d.peaks) { buildWaveColors(d.bands, d.peaks?.size ?: 0) }
    val tap by rememberUpdatedState(onTap)
    val barsLeft = if (d.loaded && d.effBpm > 0) ((d.durSec - d.posSec) / (240.0 / d.effBpm)).coerceAtLeast(0.0) else -1.0
    androidx.compose.foundation.layout.Box(modifier.background(Color.Black)) {
    Canvas(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { tap() } }) {
        val w = size.width
        val h = size.height
        val peaks = d.peaks
        // la ventana va en tiempo REAL: con tempo distinto cada onda se estira igual y los golpes casan al empatar
        val pxPerSec = (w / window / d.tempo.coerceIn(0.5, 2.0)).toFloat()
        val center = w / 2f
        val t0 = d.posSec - center / pxPerSec
        val t1 = d.posSec + (w - center) / pxPerSec

        // loop
        if (d.loopStart >= 0 && d.loopEnd > d.loopStart) {
            val x0 = (center + (d.loopStart - d.posSec) * pxPerSec).toFloat()
            val x1 = (center + (d.loopEnd - d.posSec) * pxPerSec).toFloat()
            drawRect(
                Pal.ok.copy(alpha = if (d.loopActive) 0.30f else 0.10f),
                Offset(x0.coerceIn(0f, w), 0f),
                Size((x1.coerceIn(0f, w) - x0.coerceIn(0f, w)).coerceAtLeast(0f), h)
            )
        }

        if (peaks != null) {
            val fallback = Color(0xFF1EA0F0)
            val cy = h / 2
            var x = 0f
            while (x < w) {
                val t = d.posSec + (x - center) / pxPerSec
                val idx = floor(t * PEAKS_PER_SEC).toInt()
                if (idx >= 1 && idx < peaks.size - 1) {
                    val dim = if (x < center) 0.55f else 1f
                    // envolvente suavizada (promedio de vecinos)
                    val pk = (peaks[idx - 1] * 0.25f + peaks[idx] * 0.5f + peaks[idx + 1] * 0.25f) / peakMax
                    val a = Math.pow(pk.coerceIn(0f, 1f).toDouble(), 1.1).toFloat().coerceAtLeast(0.02f) * 0.95f
                    val col = if (colors != null && idx < colors.size) Color(colors[idx]) else fallback
                    drawLine(col.copy(alpha = dim), Offset(x, cy - a * cy), Offset(x, cy + a * cy), strokeWidth = 2f)
                }
                x += 1.5f
            }
        }

        // rejilla: cada pulso = linea cian con triangulos grises arriba y abajo; cada compas = triangulos rojos grandes
        if (d.baseBpm > 0) {
            val beat = 60.0 / d.baseBpm
            var k = ceil((t0 - d.anchorSec) / beat).toLong()
            val line = Color(0xFF46C8FF)
            val red = Color(0xFFFF2D3F)
            val grey = Color(0xFFC8CDD8)
            while (true) {
                val t = d.anchorSec + k * beat
                if (t > t1) break
                val x = (center + (t - d.posSec) * pxPerSec).toFloat()
                val strong = Math.floorMod(k, 4L) == 0L
                drawLine(line.copy(alpha = if (strong) 0.95f else 0.75f), Offset(x, 0f), Offset(x, h), strokeWidth = if (strong) 3f else 2f)
                val tri = if (strong) 7f else 5f
                val up = androidx.compose.ui.graphics.Path().apply {
                    moveTo(x - tri, 0f); lineTo(x + tri, 0f); lineTo(x, tri * 1.5f); close()
                }
                val dn = androidx.compose.ui.graphics.Path().apply {
                    moveTo(x - tri, h); lineTo(x + tri, h); lineTo(x, h - tri * 1.5f); close()
                }
                drawPath(up, if (strong) red else grey)
                drawPath(dn, if (strong) red else grey)
                k++
            }
        }

        // hot cues y cue
        for (i in 0..3) {
            val hc = d.hotcues[i]
            if (hc >= 0 && hc in t0..t1) {
                val x = (center + (hc - d.posSec) * pxPerSec).toFloat()
                drawLine(Pal.hot[i], Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
                drawRect(Pal.hot[i], Offset(x, 0f), Size(10f, 10f))
            }
        }
        if (d.cuePoint in t0..t1) {
            val x = (center + (d.cuePoint - d.posSec) * pxPerSec).toFloat()
            drawLine(Pal.warn, Offset(x, h - 12f), Offset(x, h), strokeWidth = 3f)
        }

        // cabezal
        drawLine(Color.White.copy(alpha = 0.9f), Offset(center, 0f), Offset(center, h), strokeWidth = 2f)
    }
    if (barsLeft >= 0) {
        val bars = barsLeft.toInt()
        val beats = ((barsLeft - bars) * 4).toInt()
        androidx.compose.material3.Text(
            "$bars.${beats + 1} Bars", color = Color(0xFF2E8BFF), fontSize = 14.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd).padding(end = 4.dp, top = 8.dp)
        )
    }
    }
}

/**
 * Color "RGB" por pico: graves -> rojo, medios -> verde/cian, agudos -> azul. Cada banda se normaliza con su
 * propio percentil para que los colores salgan vivos en cualquier musica. Se calcula una vez por pista.
 */
private fun buildWaveColors(bd: FloatArray?, n: Int): IntArray? {
    if (bd == null || bd.size < 6 || n <= 0) return null
    val cnt = minOf(n, bd.size / 3)
    val sc = FloatArray(3)
    val tmp = FloatArray(cnt / 2 + 1)
    for (b in 0..2) {
        var m = 0
        var i = 0
        while (i < cnt && m < tmp.size) { tmp[m++] = bd[i * 3 + b]; i += 2 }
        java.util.Arrays.sort(tmp, 0, m)
        sc[b] = maxOf(1e-4f, tmp[(m * 0.985f).toInt().coerceIn(0, m - 1)])
    }
    val out = IntArray(cnt)
    for (i in 0 until cnt) {
        val lo = minOf(1f, bd[i * 3] / sc[0])
        val mi = minOf(1f, bd[i * 3 + 1] / sc[1])
        val hi = minOf(1f, bd[i * 3 + 2] / sc[2])
        val mx = maxOf(1e-6f, maxOf(lo, maxOf(mi, hi)))
        val f0 = Math.pow((lo / mx).toDouble(), 4.5).toFloat()
        val f1 = Math.pow((mi / mx).toDouble(), 4.5).toFloat()
        val f2 = Math.pow((hi / mx).toDouble(), 4.5).toFloat()
        var r = f0 * 1.00f + f1 * 0.15f + f2 * 0.10f
        var g = f0 * 0.20f + f1 * 0.80f + f2 * 0.40f
        var b = f0 * 0.10f + f1 * 0.50f + f2 * 1.00f
        val mn = minOf(r, minOf(g, b))
        r -= 0.55f * mn; g -= 0.55f * mn; b -= 0.55f * mn
        val top = maxOf(1e-6f, maxOf(r, maxOf(g, b)))
        val br = 0.55f + 0.45f * Math.sqrt(minOf(1f, mx).toDouble()).toFloat()
        val ri = (255f * minOf(1f, r / top * br)).toInt()
        val gi = (255f * minOf(1f, g / top * br)).toInt()
        val bi = (255f * minOf(1f, b / top * br)).toInt()
        out[i] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
    }
    return out
}
