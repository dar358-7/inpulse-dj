package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import app.inpulsedj.DeckUi
import app.inpulsedj.audio.PEAKS_PER_SEC
import kotlin.math.ceil
import kotlin.math.floor

/** Onda desplazable (ventana de 8 s) con rejilla de tiempos, hot cues, loop y cabezal central. */
@Composable
fun WaveStrip(d: DeckUi, color: Color, modifier: Modifier, window: Double = 6.0, onTap: () -> Unit = {}) {
    val peakMax = remember(d.peaks) {
        var m = 0.05f
        d.peaks?.let { for (v in it) if (v > m) m = v }
        m
    }
    val tap by rememberUpdatedState(onTap)
    val barsLeft = if (d.loaded && d.effBpm > 0) ((d.durSec - d.posSec) / (240.0 / d.effBpm)).coerceAtLeast(0.0) else -1.0
    androidx.compose.foundation.layout.Box(modifier.background(Color.Black)) {
    Canvas(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { tap() } }) {
        val w = size.width
        val h = size.height
        val peaks = d.peaks
        // la ventana va en tiempo REAL: con tempo distinto cada onda se estira igual y los golpes casan al empatar
        val pxPerSec = (w / window / d.tempo.coerceIn(0.5, 2.0)).toFloat()
        val center = w / 2f
        val t0 = d.posSec - center / pxPerSec
        val t1 = d.posSec + (w - center) / pxPerSec

        // loop
        if (d.loopStart >= 0 && d.loopEnd > d.loopStart) {
            val x0 = (center + (d.loopStart - d.posSec) * pxPerSec).toFloat()
            val x1 = (center + (d.loopEnd - d.posSec) * pxPerSec).toFloat()
            drawRect(
                Pal.ok.copy(alpha = if (d.loopActive) 0.30f else 0.10f),
                Offset(x0.coerceIn(0f, w), 0f),
                Size((x1.coerceIn(0f, w) - x0.coerceIn(0f, w)).coerceAtLeast(0f), h)
            )
        }

        if (peaks != null) {
            val bd = d.bands
            val hasBands = bd != null && bd.isNotEmpty()
            val cyan = Color(0xFF38C8F5)
            val green = Color(0xFF5BE08A)
            val blue = Color(0xFF2B6BFF)
            val red = Color(0xFFFF4D6A)
            val halo = Color(0xFF1B54C8)
            val cy = h / 2
            var x = 0f
            while (x < w) {
                val t = d.posSec + (x - center) / pxPerSec
                val idx = floor(t * PEAKS_PER_SEC).toInt()
                if (idx >= 1 && idx < peaks.size - 1) {
                    val dim = if (x < center) 0.6f else 1f
                    // envolvente suavizada (promedio de vecinos) para la forma de "mancha" continua
                    val pk = (peaks[idx - 1] * 0.25f + peaks[idx] * 0.5f + peaks[idx + 1] * 0.25f) / peakMax
                    val a = Math.pow(pk.coerceIn(0f, 1f).toDouble(), 0.7).toFloat().coerceAtLeast(0.02f) * 0.95f
                    var col = cyan
                    if (hasBands && bd != null && idx * 3 + 2 < bd.size) {
                        val lo = bd[idx * 3]
                        val mi = bd[idx * 3 + 1] * 1.8f
                        val hi = bd[idx * 3 + 2] * 2.4f
                        val sum = lo + mi + hi + 1e-6f
                        val fl = lo / sum
                        val fm = mi / sum
                        val fh = hi / sum
                        // medios -> verde, graves -> azul (rojo si son muy fuertes), agudos -> blanco
                        col = androidx.compose.ui.graphics.lerp(cyan, green, (fm * 1.6f).coerceIn(0f, 1f))
                        col = androidx.compose.ui.graphics.lerp(col, blue, (fl * 1.2f).coerceIn(0f, 1f))
                        if (fl > 0.8f && pk > 0.7f) col = androidx.compose.ui.graphics.lerp(col, red, 0.8f)
                        col = androidx.compose.ui.graphics.lerp(col, Color.White, (fh * 1.0f).coerceIn(0f, 0.7f))
                    }
                    // halo azul oscuro alrededor y relleno de color encima
                    drawLine(halo.copy(alpha = dim), Offset(x, cy - a * cy - 3f), Offset(x, cy + a * cy + 3f), strokeWidth = 2f)
                    drawLine(col.copy(alpha = dim), Offset(x, cy - a * cy), Offset(x, cy + a * cy), strokeWidth = 2f)
                }
                x += 1.5f
            }
        }

        // rejilla: cada pulso = linea gris fina con triangulos arriba y abajo; cada compas = linea blanca gruesa con marcas rojas
        if (d.baseBpm > 0) {
            val beat = 60.0 / d.baseBpm
            var k = ceil((t0 - d.anchorSec) / beat).toLong()
            val tri = 5f
            while (true) {
                val t = d.anchorSec + k * beat
                if (t > t1) break
                val x = (center + (t - d.posSec) * pxPerSec).toFloat()
                val strong = Math.floorMod(k, 4L) == 0L
                if (strong) {
                    drawLine(Color.White, Offset(x, 0f), Offset(x, h), strokeWidth = 3.5f)
                    val r = Color(0xFFFF2D3F)
                    drawRect(r, Offset(x - 4f, 0f), Size(8f, 8f))
                    drawRect(r, Offset(x - 4f, h - 8f), Size(8f, 8f))
                    drawRect(r, Offset(x - 3f, cy2(h) - 3f), Size(6f, 6f))
                } else {
                    drawLine(Color(0xFFD0D4DC).copy(alpha = 0.75f), Offset(x, 0f), Offset(x, h), strokeWidth = 1.5f)
                    val up = androidx.compose.ui.graphics.Path().apply {
                        moveTo(x - tri, 0f); lineTo(x + tri, 0f); lineTo(x, tri * 1.4f); close()
                    }
                    val dn = androidx.compose.ui.graphics.Path().apply {
                        moveTo(x - tri, h); lineTo(x + tri, h); lineTo(x, h - tri * 1.4f); close()
                    }
                    drawPath(up, Color.White)
                    drawPath(dn, Color.White)
                }
                k++
            }
        }

        // hot cues y cue
        for (i in 0..3) {
            val hc = d.hotcues[i]
            if (hc >= 0 && hc in t0..t1) {
                val x = (center + (hc - d.posSec) * pxPerSec).toFloat()
                drawLine(Pal.hot[i], Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
                drawRect(Pal.hot[i], Offset(x, 0f), Size(10f, 10f))
            }
        }
        if (d.cuePoint in t0..t1) {
            val x = (center + (d.cuePoint - d.posSec) * pxPerSec).toFloat()
            drawLine(Pal.warn, Offset(x, h - 12f), Offset(x, h), strokeWidth = 3f)
        }

        // cabezal
        drawLine(Color.White.copy(alpha = 0.9f), Offset(center, 0f), Offset(center, h), strokeWidth = 2f)
    }
    if (barsLeft >= 0) {
        val bars = barsLeft.toInt()
        val beats = ((barsLeft - bars) * 4).toInt()
        androidx.compose.material3.Text(
            "$bars.${beats + 1} Bars", color = Color(0xFF4DA3FF), fontSize = 10.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd).padding(end = 4.dp, top = 8.dp)
        )
    }
    }
}

private fun cy2(h: Float) = h / 2f
