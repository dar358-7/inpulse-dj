package app.inpulsedj

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Cache en disco de BPM y tonalidad por pista, para no volver a analizarlas. */
class AnalysisCache(ctx: Context) {
    class Entry(val bpm: Double, val key: String, val anchor: Double = -1.0)

    private val file = File(ctx.filesDir, "analysis_cache.json")
    private val map = HashMap<String, Entry>()

    init {
        try {
            if (file.exists()) {
                val o = JSONObject(file.readText())
                for (k in o.keys()) {
                    val e = o.getJSONObject(k)
                    map[k] = Entry(e.optDouble("b", 0.0), e.optString("k", ""), e.optDouble("a", -1.0))
                }
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized fun get(uri: String): Entry? = map[uri]

    @Synchronized fun put(uri: String, bpm: Double, key: String, anchor: Double = -1.0) {
        if (anchor < 0.0 && (map[uri]?.anchor ?: -1.0) >= 0.0) return   // no pisar un analisis completo
        map[uri] = Entry(bpm, key, anchor)
    }

    @Synchronized fun save() {
        try {
            val o = JSONObject()
            for ((k, v) in map) o.put(k, JSONObject().put("b", v.bpm).put("k", v.key).put("a", v.anchor))
            file.writeText(o.toString())
        } catch (_: Exception) {
        }
    }
}
