package app.inpulsedj.ui

import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DjViewModel

@Composable
fun LibrarySheet(
    vm: DjViewModel, onRescan: () -> Unit, onPickFiles: () -> Unit, onPickFolder: () -> Unit,
    onClose: () -> Unit, modifier: Modifier
) {
    val lib by vm.library.collectAsState()
    val sel by vm.selected.collectAsState()
    val mode by vm.libMode.collectAsState()
    val folder by vm.libFolder.collectAsState()
    val sort by vm.libSort.collectAsState()
    val status by vm.analysisStatus.collectAsState()
    val analyzing by vm.analyzing.collectAsState()
    val used by vm.usedTracks.collectAsState()
    var query by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val shown = remember(lib, mode, folder, query) { vm.visibleIndexes(lib, mode, folder, query) }
    val folders = remember(lib) { lib.groupBy { it.folder }.toSortedMap(compareBy<String> { it.lowercase() }) }
    val showFolderList = mode == 1 && folder == null

    LaunchedEffect(sel, shown) {
        val pos = shown.indexOf(sel)
        if (pos >= 0) listState.animateScrollToItem(pos)
    }
    Column(
        modifier.clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)).background(Pal.panel).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("BIBLIOTECA (${lib.size})", color = Pal.text, fontSize = 13.sp)
            PressButton("LIMPIAR USADAS (${used.size})", Modifier.width(130.dp).height(26.dp), color = Pal.warn,
                onPress = { vm.clearUsed() })
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Buscar...", fontSize = 11.sp) },
                modifier = Modifier.weight(1f).height(48.dp)
            )
            PressButton("CERRAR", Modifier.width(66.dp).height(34.dp), color = Pal.red, onPress = onClose)
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            PressButton("TODAS", Modifier.width(64.dp).height(30.dp), active = mode == 0, onPress = { vm.setLibMode(0) })
            PressButton("CARPETAS", Modifier.width(82.dp).height(30.dp), active = mode == 1, onPress = { vm.setLibMode(1) })
            Text("ORDEN", color = Pal.dim, fontSize = 9.sp, modifier = Modifier.padding(start = 6.dp))
            PressButton("TITULO", Modifier.width(62.dp).height(30.dp), active = sort == 0, color = Pal.ok, onPress = { vm.setSort(0) })
            PressButton("BPM", Modifier.width(48.dp).height(30.dp), active = sort == 1, color = Pal.ok, onPress = { vm.setSort(1) })
            PressButton("TONO", Modifier.width(52.dp).height(30.dp), active = sort == 2, color = Pal.ok, onPress = { vm.setSort(2) })
            PressButton(
                if (analyzing) "PARAR" else "ANALIZAR", Modifier.width(76.dp).height(30.dp),
                active = analyzing, color = Pal.warn, onPress = { vm.toggleAnalysis() }
            )
            PressButton("CARPETA...", Modifier.width(82.dp).height(30.dp), onPress = onPickFolder)
            PressButton("ARCHIVOS...", Modifier.width(88.dp).height(30.dp), onPress = onPickFiles)
            PressButton("ESCANEAR", Modifier.width(78.dp).height(30.dp), onPress = onRescan)
        }
        if (status.isNotEmpty()) {
            Text(status, color = Pal.warn, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (lib.isEmpty()) {
            Text(
                "No hay musica. Concede el permiso de audio y pulsa ESCANEAR, o usa CARPETA... / ARCHIVOS... para elegir tu musica.",
                color = Pal.dim, fontSize = 11.sp
            )
        }
        if (mode == 1 && folder != null) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PressButton("< CARPETAS", Modifier.width(92.dp).height(28.dp), onPress = { vm.libFolder.value = null })
                Text(folder ?: "", color = Pal.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        if (showFolderList) {
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(folders.entries.toList(), key = { i, e -> "$i|${e.key}" }) { _, e ->
                    Row(
                        Modifier.fillMaxWidth().height(40.dp).clickable { vm.libFolder.value = e.key }.padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.Folder, contentDescription = null, tint = Pal.warn, modifier = Modifier.size(22.dp))
                        Text(
                            e.key.ifEmpty { "(sin carpeta)" }, color = Pal.text, fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Text("${e.value.size} pistas", color = Pal.dim, fontSize = 10.sp)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Text("TITULO / ARTISTA", color = Pal.dim, fontSize = 8.sp, modifier = Modifier.weight(1f))
                Text("BPM", color = Pal.dim, fontSize = 8.sp, textAlign = TextAlign.End, modifier = Modifier.width(48.dp))
                Text("TONO", color = Pal.dim, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.width(66.dp))
                Text("TIEMPO", color = Pal.dim, fontSize = 8.sp, textAlign = TextAlign.End, modifier = Modifier.width(44.dp))
                Text("", modifier = Modifier.width(92.dp))
            }
            LazyColumn(Modifier.fillMaxSize(), state = listState) {
                itemsIndexed(shown, key = { _, i -> "$i|${lib[i].uri}" }) { pos, i ->
                    val t = lib[i]
                    val isUsed = t.uri.toString() in used
                    Row(
                        Modifier.fillMaxWidth().height(54.dp)
                            .background(
                                if (i == sel) Pal.deckA.copy(alpha = 0.22f).compositeOver(Pal.panel)
                                else if (isUsed) Pal.warn.copy(alpha = 0.10f).compositeOver(Pal.panel)
                                else if (pos % 2 == 0) Pal.panel
                                else Pal.panel2.copy(alpha = 0.55f).compositeOver(Pal.panel)
                            )
                            .drawBehind {
                                // filo fino entre filas y barra de color a la izquierda en la fila elegida / usada
                                drawLine(Color.White.copy(alpha = 0.06f), Offset(0f, size.height - 0.5f), Offset(size.width, size.height - 0.5f), strokeWidth = 1f)
                                if (i == sel) drawRect(Pal.deckA, Offset(0f, 0f), Size(5f, size.height))
                                else if (isUsed) drawRect(Pal.warn, Offset(0f, 0f), Size(5f, size.height))
                            }
                            .clickable { vm.selected.value = i }
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (isUsed) Badge("USADA", Pal.warn)
                                Text(
                                    t.title, color = if (isUsed) Pal.warn else Pal.text, fontSize = 14.sp, lineHeight = 18.sp,
                                    fontWeight = if (isUsed) FontWeight.Bold else FontWeight.Medium, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                                )
                            }
                            Text(t.artist, color = Pal.dim, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            if (t.bpm > 0) "%.1f".format(t.bpm) else "--", color = if (t.bpm > 0) Pal.text else Pal.dim,
                            fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.width(48.dp)
                        )
                        Row(Modifier.width(66.dp), horizontalArrangement = Arrangement.Center) {
                            KeyChip(t.key)
                        }
                        Text(
                            if (t.durationMs > 0) fmtTime(t.durationMs / 1000.0) else "--:--", color = Pal.dim,
                            fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.width(44.dp)
                        )
                        PressButton("A", Modifier.width(40.dp).height(34.dp), color = Pal.deckA,
                            onPress = { vm.selected.value = i; vm.loadTrack(0, t) })
                        PressButton("B", Modifier.width(40.dp).height(34.dp), color = Pal.deckB,
                            onPress = { vm.selected.value = i; vm.loadTrack(1, t) })
                    }
                }
            }
        }
    }
}
