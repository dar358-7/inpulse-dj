package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.inpulsedj.DeckUi
import app.inpulsedj.audio.KeyDetector

/** Color de la rueda Camelot: cada numero 1..12 tiene su tono, como en Rekordbox/Mixed In Key. */
fun camelotColor(key: String): Color {
    val n = key.dropLast(1).toIntOrNull() ?: return Pal.track
    return Color.hsv(((n - 1) * 30f + 170f) % 360f, 0.55f, 0.95f)
}

/** Version mas saturada del color Camelot para las ondas. */
fun camelotWave(key: String): Color {
    val n = key.dropLast(1).toIntOrNull() ?: return Pal.deckA
    return Color.hsv(((n - 1) * 30f + 170f) % 360f, 0.85f, 1.0f)
}

/** Etiqueta de tonalidad: "8A" con su color, y el nombre musical al lado ("Am"). */
@Composable
fun KeyChip(key: String, modifier: Modifier = Modifier, showName: Boolean = true) {
    if (key.length < 2) return
    val name = KeyDetector.name(key)
    Box(
        modifier.clip(RoundedCornerShape(4.dp)).background(camelotColor(key)).padding(horizontal = 4.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            if (showName && name.isNotEmpty()) "$key  $name" else key,
            color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

/** Color de una columna de la onda: graves en rojo-rosa, medios en verde, agudos en celeste (muy saturado). */
fun bandColor(lo: Float, mi: Float, hi: Float): Color {
    val wl = lo * 1.1f
    val wm = mi * 1.5f
    val wh = hi * 1.2f
    val s = wl + wm + wh
    if (s <= 1e-6f) return Color(0xFF2F6BFF)
    // graves azul, medios naranja, agudos blanco
    val r = (0.18f * wl + 1.00f * wm + 1.00f * wh) / s
    val g = (0.42f * wl + 0.60f * wm + 1.00f * wh) / s
    val b = (1.00f * wl + 0.12f * wm + 1.00f * wh) / s
    return Color(r.coerceIn(0f, 1f), g.coerceIn(0f, 1f), b.coerceIn(0f, 1f))
}

/** Vista general de toda la pista (como la franja superior de Rekordbox). Tocar = saltar ahi. */
@Composable
fun OverviewStrip(d: DeckUi, color: Color, onSeek: (Float) -> Unit, modifier: Modifier) {
    val seek by rememberUpdatedState(onSeek)
    Canvas(
        modifier.background(Color(0xFF07090D)).pointerInput(Unit) {
            detectTapGestures { o -> seek((o.x / size.width).coerceIn(0f, 1f)) }
        }
    ) {
        val w = size.width
        val h = size.height
        val peaks = d.peaks
        val dur = d.durSec
        if (peaks != null && peaks.isNotEmpty() && dur > 0) {
            val bands = d.bands
            val cols = w.toInt().coerceAtLeast(1)
            for (x in 0 until cols) {
                val i0 = (x.toLong() * peaks.size / cols).toInt()
                val i1 = (((x + 1).toLong() * peaks.size / cols).toInt()).coerceAtLeast(i0 + 1).coerceAtMost(peaks.size)
                var m = 0f
                var lo = 0f
                var mi = 0f
                var hi = 0f
                for (i in i0 until i1) {
                    if (peaks[i] > m) m = peaks[i]
                    if (bands != null && i * 3 + 2 < bands.size) {
                        if (bands[i * 3] > lo) lo = bands[i * 3]
                        if (bands[i * 3 + 1] > mi) mi = bands[i * 3 + 1]
                        if (bands[i * 3 + 2] > hi) hi = bands[i * 3 + 2]
                    }
                }
                val a = (m * 0.95f).coerceIn(0.03f, 1f)
                // color solido y moderno del deck; los picos fuertes se aclaran un poco
                val c = androidx.compose.ui.graphics.lerp(color, Color.White, (a * 0.30f).coerceIn(0f, 0.30f))
                val played = (x.toFloat() / cols) < (d.posSec / dur).toFloat()
                drawLine(
                    c.copy(alpha = if (played) 0.38f else 1f),
                    Offset(x + 0.5f, h / 2 - a * h / 2), Offset(x + 0.5f, h / 2 + a * h / 2), strokeWidth = 1f
                )
            }
            // loop
            if (d.loopStart >= 0 && d.loopEnd > d.loopStart) {
                val x0 = (d.loopStart / dur * w).toFloat()
                val x1 = (d.loopEnd / dur * w).toFloat()
                drawRect(Pal.ok.copy(alpha = 0.35f), Offset(x0, 0f), Size((x1 - x0).coerceAtLeast(1f), h))
            }
            // hot cues
            for (i in 0..3) {
                val hc = d.hotcues[i]
                if (hc >= 0) {
                    val x = (hc / dur * w).toFloat()
                    drawLine(Pal.hot[i], Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
                }
            }
            // cabezal
            val px = (d.posSec / dur * w).toFloat()
            drawLine(Color.White, Offset(px, 0f), Offset(px, h), strokeWidth = 2f)
        }
    }
}

/** Insignia pequena (SYNC, MASTER...). */
@Composable
fun Badge(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(3.dp)).background(color).padding(horizontal = 3.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

fun fmtTime1(sec: Double): String {
    val t = sec.coerceAtLeast(0.0)
    val m = (t / 60).toInt()
    val s = t - m * 60
    return "%d:%04.1f".format(m, s)
}
