package app.inpulsedj.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/** Hilo de audio: pide bloques al DjEngine y los escribe en un AudioTrack float de baja latencia. */
class AudioOutput(private val ctx: android.content.Context, private val engine: DjEngine, private val block: Int) {
    /** Descripcion de la salida activa, para mostrarla en Ajustes. */
    @Volatile var description = "Salida estereo"

    /** true si la pre-escucha sale por los auriculares del controlador (USB) */
    @Volatile var cueOnUsb = false
    private var commSet = false

    /** Destino de la musica elegido a mano (nombre del dispositivo); vacio = automatico (Bluetooth). */
    @Volatile var btPref = ""

    /** 0 = automatico; 1 = A, 2 = B, 3 = C, 4 = D, 5 = E (ver loop) */
    @Volatile var usbMode = 0

    /** Retardo (ms) de los audifonos cuando hay Bluetooth: iguala lo que oyes en el audifono con lo que suena en el altavoz. */
    @Volatile var cueDelayMs = 180

    private class StereoDelay(private val cap: Int) {
        private val l = FloatArray(cap)
        private val r = FloatArray(cap)
        private var wp = 0
        fun process(b: FloatArray, frames: Int, stride: Int, off: Int, delay: Int) {
            val d = if (delay < 0) 0 else if (delay > cap - 1) cap - 1 else delay
            for (i in 0 until frames) {
                val k = i * stride + off
                l[wp] = b[k]
                r[wp] = b[k + 1]
                var rp = wp - d
                if (rp < 0) rp += cap
                b[k] = l[rp]
                b[k + 1] = r[rp]
                wp = if (wp + 1 == cap) 0 else wp + 1
            }
        }
    }

    @Volatile private var cueTestFrames = 0
    @Volatile private var btTestFrames = 0
    private var tonePh = 0.0

    /** Pitido de prueba solo en los auriculares del controlador (1.5 s). */
    fun testCue() { cueTestFrames = (engine.sampleRate * 1.5).toInt() }

    /** Pitido de prueba solo en la salida Bluetooth (1.5 s). */
    fun testBt() { btTestFrames = (engine.sampleRate * 1.5).toInt() }

    private fun tone(b: FloatArray, frames: Int, stride: Int, off: Int) {
        val w = 2 * PI * 660.0 / engine.sampleRate
        for (i in 0 until frames) {
            val v = (0.3 * sin(tonePh)).toFloat()
            tonePh += w
            b[i * stride + off] = v
            b[i * stride + off + 1] = v
        }
    }

    private fun isUsb(d: android.media.AudioDeviceInfo) =
        d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET

    private fun typeName(t: Int): String = when (t) {
        1 -> "auricular tel."
        2 -> "altavoz del telefono"
        3, 4 -> "auriculares con cable"
        7 -> "Bluetooth SCO"
        8 -> "Bluetooth A2DP"
        11 -> "USB"
        22 -> "USB audifonos"
        23 -> "audifono medico"
        26 -> "Bluetooth LE"
        27 -> "Bluetooth LE altavoz"
        29 -> "Bluetooth LE difusion"
        else -> "tipo $t"
    }

    private fun outputs(): List<android.media.AudioDeviceInfo> {
        if (Build.VERSION.SDK_INT < 23) return emptyList()
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return emptyList()
        return am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS).toList()
    }

    private fun devName(d: android.media.AudioDeviceInfo) = d.productName?.toString()?.ifBlank { null } ?: typeName(d.type)

    /** Lista de todo lo que Android ofrece como salida de audio (para diagnostico). */
    fun outputsReport(): String {
        val l = outputs()
        if (l.isEmpty()) return "Android no informa salidas de audio."
        return l.joinToString("\n") { d ->
            "- ${devName(d)} [${typeName(d.type)}] canales: ${d.channelCounts.joinToString(",").ifEmpty { "?" }}"
        }
    }

    /** Dispositivos que se pueden elegir como destino de la musica (todo menos el USB del controlador). */
    fun outputNames(): List<String> = outputs().filter { !isUsb(it) }.map { devName(it) }.distinct()

    /** Reinicia la salida de audio (tras cambiar la eleccion). */
    fun restart() {
        main.removeCallbacks(restartTask)
        main.postDelayed(restartTask, 150)
    }

    /** El controlador puede declarar sus 4 canales de varias formas (cuentas, mascaras posicionales o por indice) o solo por su nombre. */
    private fun supportsQuad(d: android.media.AudioDeviceInfo): Boolean {
        if (d.channelCounts.any { it >= 4 }) return true
        if (d.channelMasks.any { Integer.bitCount(it) >= 4 }) return true
        if (d.channelIndexMasks.any { Integer.bitCount(it) >= 4 }) return true
        val n = d.productName?.toString()?.lowercase() ?: ""
        return n.contains("inpulse") || n.contains("hercules")
    }

    private fun findMultiChannelUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            val usb = d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE ||
                d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
            if (usb && supportsQuad(d)) return d
        }
        return null
    }

    private fun findBluetooth(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        val pref = btPref
        if (pref.isNotEmpty()) {
            for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
                if (!isUsb(d) && devName(d) == pref) return d
            }
        }
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET) ||
                (Build.VERSION.SDK_INT >= 31 && d.type == android.media.AudioDeviceInfo.TYPE_BLE_SPEAKER)
            ) return d
        }
        return null
    }

    private fun findAnyUsb(): android.media.AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < 23) return null
        val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return null
        for (d in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            if (d.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || d.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET) return d
        }
        return null
    }

    private fun buildTrack(sr: Int, quad: Boolean, dev: android.media.AudioDeviceInfo?, lowLatency: Boolean = true, extraBlocks: Int = 3, indexMask: Boolean = false, usage: Int = AudioAttributes.USAGE_MEDIA): AudioTrack {
        val mask = if (quad) AudioFormat.CHANNEL_OUT_QUAD else AudioFormat.CHANNEL_OUT_STEREO
        val ch = if (quad) 4 else 2
        val minBuf = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_FLOAT)
        val bufBytes = max(minBuf, block * ch * 4 * extraBlocks)
        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .also { if (indexMask && Build.VERSION.SDK_INT >= 23) it.setChannelIndexMask((1 shl ch) - 1) else it.setChannelMask(mask) }
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
        if (Build.VERSION.SDK_INT >= 26) {
            builder.setPerformanceMode(if (lowLatency) AudioTrack.PERFORMANCE_MODE_LOW_LATENCY else AudioTrack.PERFORMANCE_MODE_NONE)
        }
        val t = builder.build()
        if (dev != null && Build.VERSION.SDK_INT >= 23) t.setPreferredDevice(dev)
        return t
    }

    @Volatile private var running = false
    private var thread: Thread? = null

    private var devCb: android.media.AudioDeviceCallback? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var startedAt = 0L
    private val restartTask = Runnable {
        if (running) {
            stopThread()
            startThread()
        }
    }

    @Volatile private var gen = 0
    private fun alive(g: Int) = running && gen == g

    private fun startThread() {
        running = true
        val g = ++gen
        val t = Thread({ loop(g) }, "dj-audio")
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    private fun stopThread() {
        running = false
        thread?.join(1200)
        thread = null
    }

    fun start() {
        if (running) return
        startedAt = System.currentTimeMillis()
        startThread()
        // si se conecta o desconecta Bluetooth / USB, se vuelve a elegir la salida
        if (Build.VERSION.SDK_INT >= 23 && devCb == null) {
            val am = ctx.getSystemService(android.media.AudioManager::class.java)
            val cb = object : android.media.AudioDeviceCallback() {
                private fun changed() {
                    if (System.currentTimeMillis() - startedAt < 2500) return
                    main.removeCallbacks(restartTask)
                    main.postDelayed(restartTask, 900)
                }
                override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
                override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) = changed()
            }
            devCb = cb
            am?.registerAudioDeviceCallback(cb, main)
        }
    }

    fun stop() {
        main.removeCallbacks(restartTask)
        if (Build.VERSION.SDK_INT >= 23) {
            devCb?.let { ctx.getSystemService(android.media.AudioManager::class.java)?.unregisterAudioDeviceCallback(it) }
        }
        devCb = null
        stopThread()
    }

    /**
     * Copia del master hacia el altavoz Bluetooth en su propio hilo. El Bluetooth y el USB tienen relojes distintos:
     * un buffer circular con remuestreo muy suave (menos de 0,4 %) los mantiene a la par sin cortes ni saltos.
     */
    private inner class BtMirror(sr: Int, private val dev: android.media.AudioDeviceInfo, private val g: Int) {
        private val track: AudioTrack = buildTrack(sr, false, dev, lowLatency = false, extraBlocks = 12)
        private val cap = block * 64
        private val ring = FloatArray(cap * 2)
        @Volatile private var wp = 0L
        @Volatile private var rpFloor = 0L
        private val tmp = FloatArray(block * 2)
        private val th: Thread

        init {
            th = Thread({
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val target = block * 6
                val out = FloatArray(block * 2)
                var pos = 0.0
                var rs = 1.0
                var primed = false
                var blocksOut = 0
                while (alive(g)) {
                    val w = wp
                    if (!primed) {
                        if (w < target) {
                            try { Thread.sleep(2) } catch (_: InterruptedException) {}
                            continue
                        }
                        primed = true
                        pos = (w - target).toDouble()
                    }
                    val fill = w - pos
                    val tr = (1.0 + 0.004 * ((fill - target) / target)).coerceIn(0.996, 1.004)
                    rs += 0.05 * (tr - rs)
                    var l0 = 0f
                    var l1 = 0f
                    for (i in 0 until block) {
                        val i0 = pos.toLong()
                        if (i0 + 1 >= wp) {
                            out[i * 2] = l0
                            out[i * 2 + 1] = l1
                        } else {
                            val fr = (pos - i0).toFloat()
                            val ka = ((i0 % cap) * 2).toInt()
                            val kb = (((i0 + 1) % cap) * 2).toInt()
                            out[i * 2] = ring[ka] + (ring[kb] - ring[ka]) * fr
                            out[i * 2 + 1] = ring[ka + 1] + (ring[kb + 1] - ring[ka + 1]) * fr
                            pos += rs
                        }
                        l0 = out[i * 2]
                        l1 = out[i * 2 + 1]
                    }
                    rpFloor = pos.toLong()
                    if (track.write(out, 0, out.size, AudioTrack.WRITE_BLOCKING) < 0) break
                    blocksOut++
                    if (blocksOut == 3) {
                        try { track.play() } catch (_: Exception) { break }
                    }
                }
            }, "dj-bt")
            th.start()
        }

        /** Se llama justo despues de mezclar un bloque (desde el hilo de audio principal). */
        fun push(src: FloatArray? = null) {
            val s: FloatArray = src ?: run { engine.copyMaster(tmp, block); tmp }
            val w = wp
            if (w + block - rpFloor > cap - 16) return
            for (i in 0 until block) {
                val k = (((w + i) % cap) * 2).toInt()
                ring[k] = s[i * 2]
                ring[k + 1] = s[i * 2 + 1]
            }
            wp = w + block
        }

        /** Nombre del dispositivo por donde sale la copia; si Android la desvio, vuelve a pedir el Bluetooth. */
        fun routeName(): String {
            return try {
                val r = track.routedDevice
                if (r != null && r.type != dev.type) track.setPreferredDevice(dev)
                r?.productName?.toString() ?: "sin ruta"
            } catch (_: Exception) {
                "?"
            }
        }

        fun close() {
            try { th.join(500) } catch (_: InterruptedException) {}
            try { track.stop() } catch (_: IllegalStateException) {}
            track.release()
        }
    }

    /** Escribe silencio unos bloques y mira si Android esta sacando el audio por el dispositivo USB pedido. */
    private fun routedToUsb(t: AudioTrack, dev: android.media.AudioDeviceInfo, ch: Int): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        val z = FloatArray(block * ch)
        repeat(8) { if (t.write(z, 0, z.size, AudioTrack.WRITE_BLOCKING) < 0) return false }
        try { Thread.sleep(200) } catch (_: InterruptedException) {}
        val r = t.routedDevice ?: return false
        return r.id == dev.id || r.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || r.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
    }

    /** Comprueba por donde sale realmente el audio; si Android lo desvio del USB, vuelve a pedir el USB. */
    private fun checkRoute(tk: AudioTrack, usb: android.media.AudioDeviceInfo?, usbUsed: Boolean, label: String) {
        try {
            val r = tk.routedDevice
            val name = r?.productName?.toString() ?: "?"
            val isUsb = r != null && (r.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || r.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET)
            if (usbUsed && usb != null && !isUsb) tk.setPreferredDevice(usb)
            description = "$label [sale por: $name]"
        } catch (_: Exception) {
        }
    }

    private fun clearComm() {
        if (commSet && Build.VERSION.SDK_INT >= 31) {
            try { ctx.getSystemService(android.media.AudioManager::class.java)?.clearCommunicationDevice() } catch (_: Exception) {}
        }
        commSet = false
    }

    private fun loop(g: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val sr = engine.sampleRate
        val quadDev = findMultiChannelUsb()
        val usbDev = quadDev ?: findAnyUsb()
        val btDev = findBluetooth()
        val mode = usbMode
        val forced = mode in 1..5
        var quad = false
        var usbUsed = false
        var track: AudioTrack? = null
        var label = "Salida estereo"

        // Abre el controlador USB de una forma concreta. A: 4 canales; B: 4 canales por indice; C: estereo;
        // D: estereo por el canal de comunicacion (Android 12+); E: 4 canales sin forzar la ruta (la del sistema).
        fun open(tag: String): Boolean {
            var t: AudioTrack? = null
            try {
                val q = tag != "C" && tag != "D"
                val dev: android.media.AudioDeviceInfo = (if (q) quadDev else usbDev) ?: return false
                if (tag == "D") {
                    if (Build.VERSION.SDK_INT < 31) return false
                    val am = ctx.getSystemService(android.media.AudioManager::class.java) ?: return false
                    val cd = am.availableCommunicationDevices.firstOrNull {
                        it.id == dev.id || it.type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE || it.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
                    } ?: return false
                    if (!am.setCommunicationDevice(cd)) return false
                    commSet = true
                }
                t = buildTrack(
                    sr, q, if (tag == "E") null else dev, indexMask = tag == "B",
                    usage = if (tag == "D") AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA
                )
                t.play()
                val ok = forced || routedToUsb(t, dev, if (q) 4 else 2)
                if (ok) {
                    track = t
                    quad = q
                    usbUsed = true
                    label = if (q) "USB 4 canales: master 1-2, auriculares 3-4 ($tag)" else "USB estereo ($tag)"
                    return true
                }
                t.release()
                if (tag == "D") clearComm()
                return false
            } catch (_: Exception) {
                try { t?.release() } catch (_: Exception) {}
                if (tag == "D") clearComm()
                return false
            }
        }

        if (usbDev != null) {
            val order = when (mode) {
                1 -> listOf("A")
                2 -> listOf("B")
                3 -> listOf("C")
                4 -> listOf("D")
                5 -> listOf("E")
                else -> if (quadDev != null) listOf("A", "B", "C") + (if (btDev != null) listOf("D") else emptyList()) else listOf("C")
            }
            for (tag in order) {
                if (open(tag)) break
            }
            if (track == null && !forced) {
                // no se pudo confirmar la ruta: se usa la primera opcion tal cual, como antes
                try {
                    val q = quadDev != null
                    val t = buildTrack(sr, q, quadDev ?: usbDev)
                    t.play()
                    track = t
                    quad = q
                    usbUsed = true
                    label = (if (q) "USB 4 canales: master 1-2, auriculares 3-4" else "USB estereo") + " (sin confirmar)"
                } catch (_: Exception) {
                    track = null
                }
            }
        }
        if (track == null) {
            track = buildTrack(sr, false, null)
            track.play()
            if (usbDev != null) label = "Salida estereo (no se pudo abrir el controlador en el modo elegido)"
        }
        // Bluetooth: musica (master). Si el USB solo tiene 2 canales, el USB lleva la pre-escucha.
        var mirror: BtMirror? = null
        if (usbUsed && btDev != null) {
            try {
                mirror = BtMirror(sr, btDev, g)
            } catch (_: Exception) {
                mirror = null
            }
        }
        val stereoCue = mirror != null && !quad
        label = when {
            mirror == null -> label
            stereoCue -> "Bluetooth: musica | controlador USB: pre-escucha ($label)"
            else -> "$label + Bluetooth (copia del master)"
        }
        cueOnUsb = usbUsed && (quad || stereoCue)
        description = label
        val tk: AudioTrack = track!!
        val buf = FloatArray(block * (if (quad) 4 else 2))
        val mb = FloatArray(block * 2)
        val cb = FloatArray(block * 2)
        val cueDelay = StereoDelay(sr)
        var n = 0
        while (alive(g)) {
            if ((++n == 60 || n == 400) && Build.VERSION.SDK_INT >= 23) {
                checkRoute(tk, usbDev, usbUsed && !forced, label)
                val mr = mirror
                if (mr != null) description = description + " [Bluetooth -> " + mr.routeName() + "]"
            }
            if (stereoCue) {
                engine.renderSplit(mb, cb, block)
                cueDelay.process(cb, block, 2, 0, (cueDelayMs * sr / 1000))
                if (cueTestFrames > 0) { tone(cb, block, 2, 0); cueTestFrames -= block }
                if (btTestFrames > 0) { tone(mb, block, 2, 0); btTestFrames -= block }
                mirror!!.push(mb)
            } else {
                if (quad) engine.renderBlock4(buf, block) else engine.renderBlock(buf, block)
                if (quad && mirror != null) cueDelay.process(buf, block, 4, 2, (cueDelayMs * sr / 1000))
                if (cueTestFrames > 0) { tone(buf, block, if (quad) 4 else 2, if (quad) 2 else 0); cueTestFrames -= block }
                if (mirror != null) {
                    if (btTestFrames > 0) {
                        tone(mb, block, 2, 0)
                        btTestFrames -= block
                        mirror.push(mb)
                    } else {
                        mirror.push()
                    }
                }
            }
            val w = if (stereoCue) tk.write(cb, 0, cb.size, AudioTrack.WRITE_BLOCKING) else tk.write(buf, 0, buf.size, AudioTrack.WRITE_BLOCKING)
            if (w < 0) break
        }
        mirror?.close()
        cueOnUsb = false
        try {
            tk.stop()
        } catch (_: IllegalStateException) {
        }
        tk.release()
        clearComm()
    }
}
