package app.inpulsedj.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.max

/** Decodifica cualquier audio soportado por Android (mp3, aac, flac, wav, ogg...) a PCM en memoria. */
object TrackDecoder {
    private const val MAX_SECONDS = 600 // 10 min por pista (~106 MB a 44.1 kHz)

    class Analysis(val bpm: Double, val key: String)

    /** Analisis rapido para la biblioteca: solo los primeros ~110 s, sin onda. */
    fun analyze(ctx: Context, uri: Uri): Analysis {
        val t = decode(ctx, uri, uri.toString(), "", "", { }, maxSeconds = 110, analysisOnly = true)
        return Analysis(t.bpm, t.key)
    }

    /**
     * Completa el analisis de una pista ya cargada, usando varios hilos a la vez.
     * Si la cache ya trae BPM y compas, se salta la deteccion de tempo.
     */
    fun analyzeFull(t: Track, cached: app.inpulsedj.AnalysisCache.Entry?) {
        // hilos de baja prioridad: el analisis no debe quitarle CPU al hilo de audio (si no, se oyen cortes)
        val pool = java.util.concurrent.Executors.newFixedThreadPool(2) { r ->
            Thread {
                try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Exception) {}
                r.run()
            }
        }
        try {
            val pcm = t.pcm
            val fr = t.frames
            val sr = t.sampleRate
            val fBands = if (t.bands.isEmpty()) pool.submit(java.util.concurrent.Callable { Track.buildBands(pcm, fr, sr) }) else null
            val fOnset = pool.submit(java.util.concurrent.Callable { Track.buildOnset(pcm, fr, sr) })
            val haveGrid = cached != null && cached.bpm > 0.0 && cached.anchor >= 0.0
            val fBpm = if (haveGrid) null else pool.submit(java.util.concurrent.Callable { BpmDetector.analyze(pcm, fr, sr) })
            val needKey = cached == null || cached.key.isEmpty()
            val fKey = if (needKey) pool.submit(java.util.concurrent.Callable {
                try { KeyDetector.analyze(pcm, fr, sr) ?: "" } catch (_: Exception) { "" }
            }) else null
            if (haveGrid) {
                t.bpm = cached!!.bpm
                t.anchorSec = cached.anchor
            } else {
                val r = fBpm?.get()
                t.bpm = r?.bpm ?: 0.0
                t.anchorSec = r?.anchorSec ?: 0.0
            }
            t.key = fKey?.get() ?: (cached?.key ?: "")
            t.onset = fOnset.get()
            if (fBands != null) t.bands = fBands.get()
        } finally {
            pool.shutdown()
        }
    }

    private class Wav(val sr: Int, val frames: Int, val pcm: ShortArray)

    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
    private fun le32(b: ByteArray, o: Int) = le16(b, o) or (le16(b, o + 2) shl 16)

    /** Lector propio de WAV (PCM 8/16/24/32 bits y float32, mono o multicanal). Devuelve null si no es un WAV que sepa leer. */
    private fun readWav(ctx: Context, uri: Uri, maxSeconds: Int, onProgress: (Float) -> Unit, isCancelled: () -> Boolean): Wav? {
        val raw = ctx.contentResolver.openInputStream(uri) ?: return null
        return raw.use<java.io.InputStream, Wav?> { r ->
            val ins = java.io.BufferedInputStream(r, 1 shl 16)
            fun readFully(b: ByteArray, n: Int): Boolean {
                var got = 0
                while (got < n) {
                    val k = ins.read(b, got, n - got)
                    if (k < 0) return false
                    got += k
                }
                return true
            }
            val hd = ByteArray(12)
            if (!readFully(hd, 12)) return null
            if (String(hd, 0, 4, Charsets.US_ASCII) != "RIFF" || String(hd, 8, 4, Charsets.US_ASCII) != "WAVE") return null
            var tag = 0; var ch = 0; var sr = 0; var bits = 0; var align = 0
            var haveFmt = false
            val ch8 = ByteArray(8)
            while (true) {
                if (!readFully(ch8, 8)) return null
                val id = String(ch8, 0, 4, Charsets.US_ASCII)
                val sz = le32(ch8, 4).toLong() and 0xFFFFFFFFL
                if (id == "fmt ") {
                    val n = sz.toInt().coerceIn(16, 4096)
                    val f = ByteArray(n)
                    if (!readFully(f, n)) return null
                    tag = le16(f, 0); ch = le16(f, 2); sr = le32(f, 4); align = le16(f, 12); bits = le16(f, 14)
                    if (tag == 0xFFFE && n >= 26) tag = le16(f, 24)
                    haveFmt = true
                    val pad = (sz - n) + (sz and 1L)
                    if (pad > 0) ins.skip(pad)
                } else if (id == "data") {
                    if (!haveFmt) return null
                    val okFmt = (tag == 1 && (bits == 8 || bits == 16 || bits == 24 || bits == 32)) || (tag == 3 && bits == 32)
                    if (!okFmt || ch < 1 || sr < 8000 || align < 1) return null
                    val maxFrames = maxSeconds.toLong() * sr
                    val known = if (sz in 1..0xFFFFFFF0L) sz / align else 0L
                    var pcm = ShortArray((minOf(if (known > 0) known else 180L * sr, maxFrames) * 2 + 8192).toInt())
                    var frames = 0
                    val buf = ByteArray(align * 8192)
                    var left = if (known > 0) known * align else Long.MAX_VALUE
                    var lastP = 0L
                    while (frames < maxFrames && left > 0) {
                        if (isCancelled()) throw IllegalStateException("cancelado")
                        val want = minOf(buf.size.toLong(), left).toInt() / align * align
                        if (want <= 0) break
                        var got = 0
                        while (got < want) {
                            val k = ins.read(buf, got, want - got)
                            if (k < 0) break
                            got += k
                        }
                        val nFr = got / align
                        if (nFr <= 0) break
                        if ((frames + nFr) * 2 > pcm.size) pcm = pcm.copyOf(max(pcm.size / 4 * 5, (frames + nFr) * 2 + 8192))
                        val bps = bits / 8
                        for (i in 0 until nFr) {
                            val o = i * align
                            var l = 0f; var rr = 0f
                            for (c in 0..1) {
                                if (c >= ch && c == 1) { rr = l; break }
                                val q = o + c * bps
                                val v: Float = when {
                                    tag == 3 -> java.lang.Float.intBitsToFloat(le32(buf, q))
                                    bits == 8 -> ((buf[q].toInt() and 255) - 128) / 128f
                                    bits == 16 -> ((buf[q].toInt() and 255) or (buf[q + 1].toInt() shl 8)).toShort() / 32768f
                                    bits == 24 -> (((buf[q].toInt() and 255) shl 8) or ((buf[q + 1].toInt() and 255) shl 16) or (buf[q + 2].toInt() shl 24)) / 2147483648f
                                    else -> le32(buf, q) / 2147483648f
                                }
                                if (c == 0) l = v else rr = v
                            }
                            if (ch == 1) rr = l
                            pcm[(frames + i) * 2] = (l.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                            pcm[(frames + i) * 2 + 1] = (rr.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                        }
                        frames += nFr
                        left -= got.toLong()
                        if (got < want) break
                        val now = System.nanoTime()
                        if (known > 0 && now - lastP > 40_000_000L) {
                            lastP = now
                            onProgress((frames.toFloat() / known).coerceIn(0f, 1f))
                        }
                    }
                    if (frames < sr) return null
                    return Wav(sr, frames, if (pcm.size == frames * 2) pcm else pcm.copyOf(frames * 2))
                } else {
                    var skip = sz + (sz and 1L)
                    while (skip > 0) {
                        val k = ins.skip(skip)
                        if (k <= 0) { if (ins.read() < 0) return null else skip-- } else skip -= k
                    }
                }
            }
            @Suppress("UNREACHABLE_CODE")
            null
        }
    }

    private fun finish(
        id: String, title: String, artist: String, sr: Int, frames: Int, out: ShortArray,
        fast: Boolean, analysisOnly: Boolean
    ): Track {
        if (fast && !analysisOnly) {
            return Track(id, title, artist, sr, frames, out, Track.buildPeaks(out, frames, sr), 0.0, 0.0, Track.buildBands(out, frames, sr))
        }
        val res = BpmDetector.analyze(out, frames, sr)
        val key = try { KeyDetector.analyze(out, frames, sr) ?: "" } catch (_: Exception) { "" }
        if (analysisOnly) {
            return Track(id, title, artist, sr, frames, out, FloatArray(0), res?.bpm ?: 0.0, res?.anchorSec ?: 0.0, key = key)
        }
        val peaks = Track.buildPeaks(out, frames, sr)
        val bands = Track.buildBands(out, frames, sr)
        return Track(id, title, artist, sr, frames, out, peaks, res?.bpm ?: 0.0, res?.anchorSec ?: 0.0, bands, key)
            .also { it.onset = Track.buildOnset(out, frames, sr) }
    }

    fun decode(
        ctx: Context, uri: Uri, id: String, title: String, artist: String,
        onProgress: (Float) -> Unit, maxSeconds: Int = MAX_SECONDS, analysisOnly: Boolean = false,
        fast: Boolean = false,
        /** se llama en cuanto estan decodificados los primeros segundos: el deck ya puede sonar */
        onHead: ((Track) -> Unit)? = null, headSeconds: Int = 20,
        isCancelled: () -> Boolean = { false }
    ): Track {
        val wav = try { readWav(ctx, uri, maxSeconds, onProgress, isCancelled) } catch (e: IllegalStateException) { throw e } catch (_: Exception) { null }
        if (wav != null) return finish(id, title, artist, wav.sr, wav.frames, wav.pcm, fast, analysisOnly)
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var ti = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                ti = i
                fmt = f
                break
            }
        }
        if (ti < 0 || fmt == null) {
            ex.release()
            throw IllegalStateException("El archivo no contiene audio")
        }
        ex.selectTrack(ti)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        val maxFrames = maxSeconds * sr
        val estFrames = if (durUs > 0) (durUs / 1e6 * sr).toInt() else 180 * sr
        var pcm = ShortArray(minOf(estFrames, maxFrames) * 2 + 8192)

        // decodificar lo mas rapido posible (no en tiempo real)
        try {
            fmt.setInteger(MediaFormat.KEY_PRIORITY, 1)
            fmt.setInteger(MediaFormat.KEY_OPERATING_RATE, Short.MAX_VALUE.toInt())
        } catch (_: Exception) {
        }
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        var frames = 0
        var tmp = ShortArray(0)
        var lastProgress = 0L
        var headSent = onHead == null || analysisOnly || (durUs > 0 && durUs / 1e6 < headSeconds + 5)
        try {
            while (!outDone) {
                if (isCancelled()) throw IllegalStateException("cancelado")
                // 1) se le da al codec todo lo que acepte de una vez
                var fed = 0
                while (!inDone && fed < 16) {
                    val ii = codec.dequeueInputBuffer(0)
                    if (ii < 0) break
                    val ib = codec.getInputBuffer(ii)!!
                    val size = ex.readSampleData(ib, 0)
                    if (size < 0) {
                        codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        codec.queueInputBuffer(ii, 0, size, ex.sampleTime, 0)
                        ex.advance()
                    }
                    fed++
                }
                // 2) se vacia todo lo que ya este decodificado (solo se espera si no hubo nada que alimentar)
                var wait = if (fed == 0) 4000L else 0L
                while (!outDone) {
                    val oi = codec.dequeueOutputBuffer(info, wait)
                    wait = 0L
                    if (oi >= 0) {
                        if (info.size > 0) {
                            val ob = codec.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val nShorts = sb.remaining()
                            val c = max(1, ch)
                            val nFr = nShorts / c
                            if ((frames + nFr) * 2 > pcm.size) {
                                pcm = pcm.copyOf(max(pcm.size / 4 * 5, (frames + nFr) * 2 + 8192))
                            }
                            if (c == 2) {
                                sb.get(pcm, frames * 2, nFr * 2)
                            } else {
                                if (tmp.size < nShorts) tmp = ShortArray(nShorts)
                                sb.get(tmp, 0, nShorts)
                                for (f in 0 until nFr) {
                                    val l = tmp[f * c]
                                    val r = if (c > 1) tmp[f * c + 1] else l
                                    pcm[(frames + f) * 2] = l
                                    pcm[(frames + f) * 2 + 1] = r
                                }
                            }
                            frames += nFr
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                        if (frames >= maxFrames) outDone = true
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val nf = codec.outputFormat
                        ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    }
                }
                if (!headSent && frames >= headSeconds * sr) {
                    headSent = true
                    val hf = headSeconds * sr
                    val hp = pcm.copyOf(hf * 2)
                    onHead!!.invoke(Track(id, title, artist, sr, hf, hp, Track.buildPeaks(hp, hf, sr), 0.0, 0.0, Track.buildBands(hp, hf, sr)))
                }
                val now = System.nanoTime()
                if (durUs > 0 && now - lastProgress > 40_000_000L) {
                    lastProgress = now
                    onProgress((frames.toDouble() / (durUs / 1e6 * sr)).toFloat().coerceIn(0f, 1f))
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            ex.release()
        }
        if (frames < sr) throw IllegalStateException("No se pudo decodificar el archivo")
        val out = if (pcm.size == frames * 2) pcm else pcm.copyOf(frames * 2)
        return finish(id, title, artist, sr, frames, out, fast, analysisOnly)
    }
}
