package app.inpulsedj.audio

import java.util.Arrays
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max

/** Mezclador de 2 decks + samplers. `renderBlock` lo llama el hilo de audio. */
class DjEngine(val sampleRate: Int, val maxBlock: Int) {
    val decks = arrayOf(Deck(0, sampleRate), Deck(1, sampleRate))
    val sampler = SamplerBank(sampleRate)

    @Volatile var crossfader = 0.5f   // 0 = A, 1 = B
    @Volatile var master = 0.7f   // 0..1 -> ganancia 0..1.4 (0.7 = unidad)
    @Volatile var cueSplit = false
    @Volatile var cueVolume = 0.8f
    @Volatile var masterLevel = 0f

    private val commands = ConcurrentLinkedQueue<Runnable>()
    private val bufA = FloatArray(maxBlock * 2)
    private val bufB = FloatArray(maxBlock * 2)
    private val bufS = FloatArray(maxBlock * 2)
    private var gA = 0f
    private var gB = 0f

    /** Ejecuta [r] en el hilo de audio, antes del siguiente bloque. */
    fun post(r: () -> Unit) {
        commands.add(Runnable { r() })
    }

    private val wasPlaying = BooleanArray(2)
    private val snapPending = BooleanArray(2)
    private val startedNow = BooleanArray(2)
    private val bias = DoubleArray(2)
    private val biasValid = BooleanArray(2)
    private val hold = BooleanArray(2)        // el usuario fijo la fase a mano: se conserva su desfase
    private val holdRef = DoubleArray(2)
    private val holdRefValid = BooleanArray(2)
    private val wasNudged = BooleanArray(2)
    private val measureIn = DoubleArray(2)
    private val xl = FloatArray(1800)
    private val xf = FloatArray(1800)

    private fun onsetAt(t: Track, srcSec: Double): Float {
        val o = t.onset
        val x = srcSec * t.onsetRate
        if (x < 0.0) return 0f
        val i = x.toInt()
        if (i + 1 >= o.size) return 0f
        val fr = (x - i).toFloat()
        return o[i] + (o[i + 1] - o[i]) * fr
    }

    /**
     * Compara los ataques (bombos) reales de las dos pistas y devuelve cuantos segundos reales
     * debe adelantarse el seguidor para sonar alineado con el lider, o null si no hay certeza.
     */
    private fun measureOffset(f: Deck, l: Deck, per: Double): Double? {
        val tf = f.track ?: return null
        val tl = l.track ?: return null
        if (tf.onset.isEmpty() || tl.onset.isEmpty()) return null
        val dt = 0.004
        val s = Math.ceil(per / 2.0 / 0.004).toInt().coerceIn(25, 140)   // +- medio pulso
        val n = 1500                     // 6 s: 2 s pasados + 4 s futuros
        val pl = l.pos / tl.sampleRate
        val pf = f.pos / tf.sampleRate
        val rl = l.tempo
        val rf = f.tempo
        for (k in 0 until n) {
            val tau = (k - 500) * dt
            xl[k] = onsetAt(tl, pl + tau * rl)
        }
        for (k in 0 until n + 2 * s) {
            val tau = (k - s - 500) * dt
            xf[k] = onsetAt(tf, pf + tau * rf)
        }
        var el = 0.0
        for (k in 0 until n) el += xl[k] * xl[k]
        var ef = 0.0
        for (k in 0 until n + 2 * s) ef += xf[k] * xf[k]
        if (el < 1e-6 || ef < 1e-6) return null
        var best = -1.0
        var bm = 0
        var prev = 0.0
        var next = 0.0
        val c = DoubleArray(2 * s + 1)
        for (m in -s..s) {
            var acc = 0.0
            for (k in 0 until n) acc += xl[k] * xf[k + s + m]
            c[m + s] = acc
            if (acc > best) { best = acc; bm = m }
        }
        if (bm == -s || bm == s) return null
        val conf = best / Math.sqrt(el * (ef * n / (n + 2 * s)))
        if (conf < 0.2) return null
        prev = c[bm + s - 1]
        next = c[bm + s + 1]
        val den = prev - 2 * best + next
        val off = if (abs(den) > 1e-12) 0.5 * (prev - next) / den else 0.0
        return (bm + off.coerceIn(-1.0, 1.0)) * dt
    }

    fun setSync(i: Int, on: Boolean) = post {
        val d = decks[i]
        val o = decks[1 - i]
        d.sync = on
        if (!on) {
            d.leader = false
            d.nudge = 1.0
            snapPending[i] = false
        } else {
            // el deck que ya estaba sincronizado manda; el recien pulsado sigue
            if (o.sync && !d.leader) o.leader = true
            // al sincronizar se mantiene el tono (key lock) en ambos discos: mezcla limpia
            d.keyLock = true
            o.keyLock = true
            updateSync()
            // si los dos suenan, se alinea el tiempo al instante
            snapPending[i] = d.playing && o.playing
        }
    }

    fun setLeader(i: Int) = post {
        val d = decks[i]
        val o = decks[1 - i]
        d.sync = true
        d.leader = true
        o.leader = false
        updateSync()
        snapPending[1 - i] = o.sync && d.playing && o.playing
    }

    private fun wrap(x: Double, p: Double): Double {
        var y = x % p
        if (y > p / 2) y -= p
        if (y < -p / 2) y += p
        return y
    }

    private fun alignPhase(f: Deck, l: Deck) {
        val pf = f.phase() ?: return
        val pl = l.phase() ?: return
        var d = pl - pf
        if (d > 0.5) d -= 1.0
        if (d < -0.5) d += 1.0
        f.cmdShiftBeats(d)
    }

    /**
     * Mantiene el seguidor en fase con el lider: salto de tiempo al enganchar o al arrancar,
     * y despues una correccion suave de velocidad (PLL) para que no se desfasen.
     */
    private fun lockPhase(frames: Int) {
        val a = decks[0]
        val b = decks[1]
        val both = a.sync && b.sync
        val leaderIdx = if (both) (if (b.leader && !a.leader) 1 else 0) else -1
        for (d in decks) {
            val i = d.index
            val o = decks[1 - i]
            startedNow[i] = d.playing && !wasPlaying[i]
            if (startedNow[i] && o.playing) snapPending[i] = true
            wasPlaying[i] = d.playing
            if (!d.sync || (both && i == leaderIdx) || !d.playing || !o.playing ||
                d.track == null || o.track == null
            ) {
                d.nudge = 1.0
                biasValid[i] = false
                hold[i] = false
                wasNudged[i] = false
                continue
            }
            if (d.scratching || o.scratching) {
                d.nudge = 1.0
                if (d.scratching) wasNudged[i] = true
                continue
            }
            val pf = d.phase()
            val pl = o.phase()
            if (pf == null || pl == null) {
                d.nudge = 1.0
                continue
            }
            // periodos de tiempo en segundos reales y tiempo desde el ultimo pulso de cada deck
            val tl = 60.0 / (o.bpm * o.tempo)
            val tf = 60.0 / (d.bpm * d.tempo)
            val sinceL = pl * tl
            val sinceF = pf * tf
            // si un deck va al doble de tiempo que el otro, se comparan en la rejilla mas rapida
            val per = if (tf >= tl * 0.75) tl else tf
            val errTime = if (tf >= tl * 0.75) wrap(sinceL - sinceF % tl, tl) else wrap(sinceL % tf - sinceF, tf)
            val lat = d.latencySec - o.latencySec   // el key lock retrasa el audio de ese deck
            val errT = errTime + lat
            val err = errT / tf   // en pulsos del seguidor
            val soft = d.keyLock && o.keyLock
            // si el usuario movio el disco a mano, esa nueva posicion pasa a ser la referencia
            if (d.isNudged()) wasNudged[i] = true
            else if (wasNudged[i]) {
                wasNudged[i] = false
                bias[i] = errT
                biasValid[i] = true
                hold[i] = true
                holdRefValid[i] = false
                measureIn[i] = 0.35
                snapPending[i] = false
            }
            if (snapPending[i] && !(soft && !startedNow[i])) {
                snapPending[i] = false
                d.cmdShiftBeats(err)
                d.nudge = 1.0
                biasValid[i] = false
                measureIn[i] = 0.35
                continue
            }
            measureIn[i] -= frames.toDouble() / sampleRate
            if (measureIn[i] <= 0.0 && !d.isNudged()) {
                measureIn[i] = if (biasValid[i] && (!hold[i] || holdRefValid[i])) 1.0 else 0.25
                val dl = measureOffset(d, o, per)
                if (dl != null) {
                    if (hold[i]) {
                        // ajuste manual: se conserva el desfase que dejo el usuario, pero se sigue vigilando el audio real.
                        // Si el BPM detectado tiene un pequeno error, la rejilla sigue cuadrada pero el audio se va
                        // corriendo; aqui se corrige esa deriva sin deshacer el ajuste del usuario.
                        if (!holdRefValid[i]) {
                            holdRef[i] = dl
                            holdRefValid[i] = true
                        } else {
                            val want = errT - dl + holdRef[i]
                            bias[i] += 0.5 * wrap(want - bias[i], per)
                        }
                    } else {
                        val nb = errTime - dl
                        if (!biasValid[i]) {
                            bias[i] = nb
                            biasValid[i] = true
                        } else {
                            bias[i] += 0.5 * wrap(nb - bias[i], per)
                        }
                    }
                }
            }
            if (d.isNudged()) {
                d.nudge = 1.0
                continue
            }
            // zona muerta de 0,7 ms para no oscilar; corrige mas fuerte si el error es grande
            snapPending[i] = false
            val lim = if (soft) 0.08 else 0.05
            val eT = if (biasValid[i]) wrap(errT - bias[i], per) else errT
            val e2 = eT / per
            d.nudge = if (abs(eT) < 0.0007) 1.0
            else 1.0 + (e2 * (if (abs(e2) > 0.15) 0.8 else 0.5)).coerceIn(-lim, lim)
        }
    }

    /**
     * Desfase real entre los dos decks en ms (medido con los golpes del audio, no solo con la rejilla).
     * Positivo = el deck B suena por detras de A; negativo = por delante. NaN si no se puede medir.
     */
    @Volatile var phaseMs = Double.NaN
    private var phaseIn = 0.0
    private var phaseSm = Double.NaN

    private fun updatePhaseMeter(frames: Int) {
        val a = decks[0]
        val b = decks[1]
        if (a.track == null || b.track == null || !a.playing || !b.playing || a.scratching || b.scratching ||
            a.bpm <= 0.0 || b.bpm <= 0.0
        ) {
            phaseMs = Double.NaN
            phaseSm = Double.NaN
            return
        }
        phaseIn -= frames.toDouble() / sampleRate
        if (phaseIn > 0.0) return
        phaseIn = 0.3
        val tl = 60.0 / (a.bpm * a.tempo)
        val tf = 60.0 / (b.bpm * b.tempo)
        val per = if (tf >= tl * 0.75) tl else tf
        val dl = measureOffset(b, a, per)
        if (dl == null) {
            phaseMs = Double.NaN
            return
        }
        // el key lock retrasa el audio de ese deck
        val v = dl + (b.latencySec - a.latencySec)
        phaseSm = if (phaseSm.isNaN()) v else phaseSm + 0.6 * wrap(v - phaseSm, per)
        phaseMs = phaseSm * 1000.0
    }

    private fun updateSync() {
        val a = decks[0]
        val b = decks[1]
        val both = a.sync && b.sync
        val leaderIdx = if (both) (if (b.leader && !a.leader) 1 else 0) else -1
        for (d in decks) {
            if (!d.sync) continue
            if (both && d.index == leaderIdx) continue
            val o = decks[1 - d.index]
            if (o.track == null || d.track == null) continue
            val ob = o.bpm
            val db = d.bpm
            if (ob <= 0.0 || db <= 0.0) continue
            var t = ob * o.tempo / db
            while (t > 1.4142) t /= 2.0   // 140 vs 70 BPM: el seguidor va a mitad de tiempo
            while (t < 0.7071) t *= 2.0
            d.tempo = t.coerceIn(0.5, 2.0)
        }
    }

    private val mL = FloatArray(maxBlock)
    private val mR = FloatArray(maxBlock)
    private val cL = FloatArray(maxBlock)
    private val cR = FloatArray(maxBlock)
    private var anyPfl = false
    private val limiter = Limiter(sampleRate)

    /** true si hay alguna pista en pre-escucha (PFL) */
    val cueActive: Boolean get() = anyPfl

    /** Salida estereo (2 canales). Con cue dividido: izquierda = pre-escucha, derecha = master. */
    fun renderBlock(out: FloatArray, frames: Int) {
        mix(frames)
        val split = cueSplit && anyPfl
        for (i in 0 until frames) {
            val j = i * 2
            if (split) {
                out[j] = softClip((cL[i] + cR[i]) * 0.5f)
                out[j + 1] = softClip((mL[i] + mR[i]) * 0.5f)
            } else {
                out[j] = mL[i]
                out[j + 1] = mR[i]
            }
        }
    }

    /** Copia el master (ya mezclado en el ultimo bloque) a un buffer estereo intercalado. */
    fun copyMaster(dst: FloatArray, frames: Int) {
        for (i in 0 until frames) {
            dst[i * 2] = mL[i]
            dst[i * 2 + 1] = mR[i]
        }
    }

    /** Master y pre-escucha en buffers estereo separados (para enviarlos a dos dispositivos distintos). */
    fun renderSplit(m: FloatArray, c: FloatArray, frames: Int) {
        mix(frames)
        for (i in 0 until frames) {
            val j = i * 2
            m[j] = mL[i]
            m[j + 1] = mR[i]
            c[j] = softClip(cL[i])
            c[j + 1] = softClip(cR[i])
        }
    }

    /** Salida de 4 canales (tarjeta USB tipo Inpulse): 1-2 = master, 3-4 = auriculares (pre-escucha). */
    fun renderBlock4(out: FloatArray, frames: Int) {
        mix(frames)
        for (i in 0 until frames) {
            val j = i * 4
            out[j] = mL[i]
            out[j + 1] = mR[i]
            out[j + 2] = softClip(cL[i])
            out[j + 3] = softClip(cR[i])
        }
    }

    private fun mix(frames: Int) {
        while (true) {
            val c = commands.poll() ?: break
            c.run()
        }
        updateSync()
        lockPhase(frames)
        updatePhaseMeter(frames)

        val a = decks[0]
        val b = decks[1]
        a.render(bufA, frames)
        b.render(bufB, frames)
        Arrays.fill(bufS, 0, frames * 2, 0f)
        sampler.render(bufS, frames)

        // curva de potencia constante con meseta en los extremos: al centro cada disco queda a -1.4 dB
        // (antes los dos iban a tope y la suma saturaba el limitador, distorsionando el audio)
        val xf = crossfader.coerceIn(0f, 1f)
        val pi = PI.toFloat()
        val cA = minOf(1f, 1.2f * cos(xf * pi / 2f))
        val cB = minOf(1f, 1.2f * cos((1f - xf) * pi / 2f))
        val tA = cA * a.volume
        val tB = cB * b.volume
        val pa = a.pfl
        val pb = b.pfl
        anyPfl = pa || pb
        val m = master * 1.4f
        val cv = cueVolume
        val autoA = if (anyPfl || !a.playing) 0f else (1f - tA / 0.05f).coerceIn(0f, 1f)
        val autoB = if (anyPfl || !b.playing) 0f else (1f - tB / 0.05f).coerceIn(0f, 1f)
        var pk = 0f
        for (i in 0 until frames) {
            val f = (i + 1).toFloat() / frames
            val ga = gA + (tA - gA) * f
            val gb = gB + (tB - gB) * f
            val j = i * 2
            val al = bufA[j]
            val ar = bufA[j + 1]
            val bl = bufB[j]
            val br = bufB[j + 1]
            mL[i] = (al * ga + bl * gb + bufS[j]) * m
            mR[i] = (ar * ga + br * gb + bufS[j + 1]) * m
            if (anyPfl) {
                var xl = 0f
                var xr = 0f
                if (pa) { xl += al; xr += ar }
                if (pb) { xl += bl; xr += br }
                cL[i] = xl * cv
                cR[i] = xr * cv
            }
        }
        limiter.process(mL, mR, frames)
        for (i in 0 until frames) {
            val l = mL[i]
            val r = mR[i]
            if (!anyPfl) {
                // sin PFL: el audifono oye el master; un disco con el fader abajo se oye solo (pre-escucha automatica)
                val j = i * 2
                cL[i] = (l + bufA[j] * autoA + bufB[j] * autoB) * cv
                cR[i] = (r + bufA[j + 1] * autoA + bufB[j + 1] * autoB) * cv
            }
            val ab = max(abs(l), abs(r))
            if (ab > pk) pk = ab
        }
        gA = tA
        gB = tB
        masterLevel = max(pk, masterLevel * 0.97f)
    }
}
