package app.inpulsedj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import app.inpulsedj.DeckUi
import app.inpulsedj.audio.PEAKS_PER_SEC
import kotlin.math.ceil
import kotlin.math.floor

/** Onda desplazable (ventana de 8 s) con rejilla de tiempos, hot cues, loop y cabezal central. */
@Composable
fun WaveStrip(d: DeckUi, color: Color, modifier: Modifier, window: Double = 6.0, onTap: () -> Unit = {}) {
    val peakMax = remember(d.peaks) {
        var m = 0.05f
        d.peaks?.let { for (v in it) if (v > m) m = v }
        m
    }
    val tap by rememberUpdatedState(onTap)
    Canvas(modifier.background(Color.Black).pointerInput(Unit) { detectTapGestures { tap() } }) {
        val w = size.width
        val h = size.height
        val peaks = d.peaks
        // la ventana va en tiempo REAL: con tempo distinto cada onda se estira igual y los golpes casan al empatar
        val pxPerSec = (w / window / d.tempo.coerceIn(0.5, 2.0)).toFloat()
        val center = w / 2f
        val t0 = d.posSec - center / pxPerSec
        val t1 = d.posSec + (w - center) / pxPerSec

        // loop
        if (d.loopStart >= 0 && d.loopEnd > d.loopStart) {
            val x0 = (center + (d.loopStart - d.posSec) * pxPerSec).toFloat()
            val x1 = (center + (d.loopEnd - d.posSec) * pxPerSec).toFloat()
            drawRect(
                Pal.ok.copy(alpha = if (d.loopActive) 0.30f else 0.10f),
                Offset(x0.coerceIn(0f, w), 0f),
                Size((x1.coerceIn(0f, w) - x0.coerceIn(0f, w)).coerceAtLeast(0f), h)
            )
        }

        if (peaks != null) {
            val bd = d.bands
            val hasBands = bd != null && bd.isNotEmpty()
            // estilo 3 bandas (como Rekordbox): graves azul, medios naranja, agudos blanco; sobre fondo negro
            val lowC = Color(0xFF2F6BFF)
            val midC = Color(0xFFFF9A1F)
            val hiC = Color(0xFFFFFFFF)
            var x = 0f
            while (x < w) {
                val t = d.posSec + (x - center) / pxPerSec
                val idx = floor(t * PEAKS_PER_SEC).toInt()
                if (idx >= 0 && idx < peaks.size) {
                    val dim = if (x < center) 0.55f else 1f
                    val cy = h / 2
                    if (hasBands && bd != null && idx * 3 + 2 < bd.size) {
                        val k = 0.9f / peakMax
                        val lo = Math.pow((bd[idx * 3] * k * 1.1f).coerceIn(0f, 1f).toDouble(), 0.8).toFloat()
                        val mi = Math.pow((bd[idx * 3 + 1] * k * 1.4f).coerceIn(0f, 1f).toDouble(), 0.8).toFloat()
                        val hi = Math.pow((bd[idx * 3 + 2] * k * 1.8f).coerceIn(0f, 1f).toDouble(), 0.8).toFloat()
                        // golpe de bombo: subida brusca de graves, marca blanca arriba
                        if (idx >= 4) {
                            val cur = bd[idx * 3]
                            val before = maxOf(bd[(idx - 3) * 3], bd[(idx - 4) * 3])
                            if (cur > 0.12f * peakMax && cur > before * 1.6f && bd[(idx - 1) * 3] <= before * 1.6f) {
                                drawRect(Color.White, Offset(x - 1f, 0f), Size(3f, h * 0.14f))
                            }
                        }
                        // capas de atras hacia adelante: graves (mas altos) -> medios -> agudos (mas cortos)
                        val sw = 2f
                        if (lo > 0.01f) drawLine(lowC.copy(alpha = dim), Offset(x, cy - lo * cy * 0.95f), Offset(x, cy + lo * cy * 0.95f), strokeWidth = sw)
                        val mh = minOf(mi, maxOf(lo * 0.85f, 0.05f)) // los medios nunca tapan por completo a los graves
                        if (mi > 0.01f) drawLine(midC.copy(alpha = dim), Offset(x, cy - mh * cy * 0.95f), Offset(x, cy + mh * cy * 0.95f), strokeWidth = sw)
                        val hh = minOf(hi, maxOf(mh * 0.8f, 0.04f))
                        if (hi > 0.01f) drawLine(hiC.copy(alpha = dim), Offset(x, cy - hh * cy * 0.95f), Offset(x, cy + hh * cy * 0.95f), strokeWidth = sw)
                    } else {
                        val a = (peaks[idx] * 0.95f).coerceIn(0.02f, 1f)
                        drawLine(color.copy(alpha = dim), Offset(x, cy - a * cy), Offset(x, cy + a * cy), strokeWidth = 2f)
                    }
                }
                x += 1.5f
            }
        }

        // rejilla
        if (d.baseBpm > 0) {
            val beat = 60.0 / d.baseBpm
            var k = ceil((t0 - d.anchorSec) / beat).toLong()
            while (true) {
                val t = d.anchorSec + k * beat
                if (t > t1) break
                val x = (center + (t - d.posSec) * pxPerSec).toFloat()
                val strong = Math.floorMod(k, 4L) == 0L
                drawLine(
                    Color.White.copy(alpha = if (strong) 0.95f else 0.6f),
                    Offset(x, 0f), Offset(x, h), strokeWidth = if (strong) 3f else 1.5f
                )
                k++
            }
        }

        // hot cues y cue
        for (i in 0..3) {
            val hc = d.hotcues[i]
            if (hc >= 0 && hc in t0..t1) {
                val x = (center + (hc - d.posSec) * pxPerSec).toFloat()
                drawLine(Pal.hot[i], Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
                drawRect(Pal.hot[i], Offset(x, 0f), Size(10f, 10f))
            }
        }
        if (d.cuePoint in t0..t1) {
            val x = (center + (d.cuePoint - d.posSec) * pxPerSec).toFloat()
            drawLine(Pal.warn, Offset(x, h - 12f), Offset(x, h), strokeWidth = 3f)
        }

        // cabezal
        drawLine(Color.White, Offset(center, 0f), Offset(center, h), strokeWidth = 2f)
    }
}
